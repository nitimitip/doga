/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - REVIEW AND TEST BEFORE ANY DEPLOYMENT
  Batch V3-03 (2026-11-02) - requisition page SPs
  Table : dbo.MT_EQP_REQUESTLINES  (3,642,236 rows per clustered IndexRows;
          clustered PK_MT_EQP_REQUESTLINES_1 on Eqprel_ID (identity),
          292.31 MB ~= 37,416 pages)
  Index : IX_MT_EQP_REQUESTLINES_Eqprel_Eqpreh_ID ON (Eqprel_Eqpreh_ID)

  EVIDENCE (Index/slowrunningSP.xlsx + Index/index_size.xlsx, production,
  captured BEFORE the phase-1/2 deploy; this table was not touched by it)
    - The clustered PK is the only index. Eqprel_Eqpreh_ID (int NOT NULL,
      the requisition header id) has no index, so every "lines of this
      requisition" read is a clustered scan: 1,336 scans / 13 seeks on the
      PK in the window.
    - SP_GET_LIST_BY_REQ_NO (8 execs, avg 534 ms, CPU 345 ms, 39,279 reads)
      = one statement: MT_EQP_REQUESTLINES join MT_EQP_REQUESTS on
      Eqprel_Eqpreh_ID = Eqpreh_ID, Eqpreh_ID = @RequisitionNo (PK seek
      on the header). The lines side is the scan: 37,416 pages = 95.3% of
      39,279; the rest is the per-line MT_EQP_EQUIP_CFS_V lookups (77-page
      heap) and the header seek.
    - SP_CREATE_REQUISITION_V5 (30 x 2.8 s): DELETE MT_EQP_REQUESTLINES
      WHERE Eqprel_Eqpreh_ID IN (headers of this TUL) = one scan per
      successful call (37.4k of its 264.8k reads; most of the rest was
      indexes 04 + 31, already live).
    - PRC_RPT_TIEquipListReport_V2 (4 x 620 ms, 29,340 reads): reads the
      lines of each requisition inside a cursor (WHERE Eqprel_Eqpreh_ID =
      @p_RequisitionNumber AND Eqprel_delete = 'N'). Not closed
      arithmetically (29k < one full scan; plan shape unknown).
    - SP_INSERT_EQUIP_IN_REQ_LINE: TOP 1 Eqprel_ExpenDate ... WHERE
      Eqprel_Eqpreh_ID = @ReqNo ORDER BY Eqprel_ID DESC (backward clustered
      walk until the first match; long for old requisitions). Not in the
      stats file.
    - Other readers in QPID_SP: sp_get_EqpRequests / p_get_EqpRequests,
      SP_ADD_ASSEMBLY_TO_REQUISITION, SP_PREAUTHORISE_REQUISITION(_V2),
      SP_MIGRATE_ACTIVITY_v1 and the old SP_CREATE_REQUISITION* copies (no
      stats = not called in the window).

  DESIGN
    - Key Eqprel_Eqpreh_ID only; the clustered key Eqprel_ID is carried as
      the row locator, so (Eqprel_Eqpreh_ID, Eqprel_ID) is ordered and the
      INSERT_EQUIP TOP 1 ... ORDER BY Eqprel_ID DESC becomes a backward
      seek of one row.
    - No INCLUDE: ~5.9 lines per requisition (3.64M lines / 615.5k
      headers), so a handful of key lookups per call; a covering index
      would cost ~2.5x the space for a few reads.
    - All callers compare it with int (header id) or a varchar parameter
      (SP_GET_LIST_BY_REQ_NO / INSERT_EQUIP: @RequisitionNo / @ReqNo
      varchar(20) -> converted to int once; int has the higher precedence,
      so the column side is not converted and the seek is possible).

  SIZE / WRITE OVERHEAD
    - ~3.64M rows x ~17 bytes (4 key + 4 locator + overhead) ~= 62 MB,
      ~70 MB at FILLFACTOR 90.
    - index read_write_operation.xlsx: 5,353 leaf inserts, 110 updates,
      1,710 ghost deletes in the window. Header ids grow with the identity
      of MT_EQP_REQUESTS, so inserts land at the end of the index. Low.

  OVERLAP CHECK
    - No index on the table has Eqprel_Eqpreh_ID in any position.

  CONFIDENCE: high for SP_GET_LIST_BY_REQ_NO (95.3% closure) and the V5
    DELETE (same predicate); medium for the report (cursor, not closed).
  CHECK AFTER: V3-03.3 in validation/v3_03_validation.sql.
******************************************************************************/

-- P1. Pre-check (read-only): confirm no equivalent index exists now.
-- SELECT i.name, ic.key_ordinal, c.name AS col, ic.is_included_column
-- FROM sys.indexes i
-- JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
-- JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
-- WHERE i.object_id = OBJECT_ID('dbo.MT_EQP_REQUESTLINES')
-- ORDER BY i.name, ic.key_ordinal;

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID('dbo.MT_EQP_REQUESTLINES')
                 AND name = 'IX_MT_EQP_REQUESTLINES_Eqprel_Eqpreh_ID')
BEGIN
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    CREATE NONCLUSTERED INDEX IX_MT_EQP_REQUESTLINES_Eqprel_Eqpreh_ID
        ON dbo.MT_EQP_REQUESTLINES (Eqprel_Eqpreh_ID)
        WITH (ONLINE = ON, SORT_IN_TEMPDB = ON, FILLFACTOR = 90);
END
GO

/* ROLLBACK
DROP INDEX IX_MT_EQP_REQUESTLINES_Eqprel_Eqpreh_ID ON dbo.MT_EQP_REQUESTLINES;
*/
