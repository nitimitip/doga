/******************************************************************************
  BUG FIX BF02 - PENDING VALIDATION - DO NOT DEPLOY UNTESTED
  Procedure : [dbo].[usp_addHistory]
  Base      : QPID_SP/usp_addHistory.sql (production original)
  Fix       : BF02 (2026-10-21)
  Generated : bugfix/tools/gen_bugfix.py (inverse transform = base, checked)

  WHY (BF02, user report 2026-10-21: records missing in BT_ACT_HIST):
    HIST_HISTID is the clustered PK (PK_BT_ACT_HIST_1) and NOT an identity.
    Every writer takes MAX(HIST_HISTID)+1 with an ordinary read. Two
    concurrent writers read the same MAX; the second INSERT fails with
    2627 (duplicate key) and that history row is lost. The ~30
    sp_ACT_addHIST_* wrappers have no error handling, and
    sp_ACT_PLABulkBillingQuery_UPDATE swallows the error in its CATCH.

  THE FIX (same as Batch 34, PLA_addEnquiry): WITH (UPDLOCK, HOLDLOCK) on
  the MAX() read. U is incompatible with U, so a second writer waits at its
  MAX() read until the first commits, then reads the new MAX (no 2627, no
  conversion deadlock). Outside a transaction the lock lasts for the one
  INSERT statement only. Ids stay gap-free and in the same sequence.
  Writers without the hint can still collide: deploy all five BF02
  procedures together and check other writers (bf02_validation BF02.2).

  WHAT CHANGED (and nothing else):
    1. Line 83: (Select max(HIST_HISTID)+1 from BT_ACT_HIST)
       -> (Select max(HIST_HISTID)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK))
    2. CREATE -> ALTER.

  VALIDATION: bugfix/validation/bf02_validation.sql
  ROLLBACK  : bugfix/rollback/usp_addHistory_ORIGINAL.sql
******************************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		TCS: Sumanta Dhara
-- Create date: 26-Nov-2019
-- Description:	Add history 
-- Modified By : TCS:Sandeep Singh
-- Modified Date : 02-Dec-2020
-- =============================================
ALTER   PROCEDURE [dbo].[usp_addHistory] 
	@HIST_AEID INT,
	@HIST_internalRef VARCHAR(50) = NULL,
	@HIST_metaModelType2 INT = NULL,
	@HIST_fieldType VARCHAR(50),
	@HIST_fieldName VARCHAR(50),
	@HIST_tableName VARCHAR(50),
	@HIST_columnName VARCHAR(50),
	@HIST_valueInt INT,
	@HIST_valueChar VARCHAR(50),
	@HIST_descr VARCHAR(150),
	@HIST_dateTime SMALLDATETIME,
	@HIST_createdBy INT,
	@HIST_createdByDescr VARCHAR(200),
	@HIST_foreignKeyId int = null
	
AS

BEGIN
DECLARE @HIST_lastChange INT
DECLARE @iHist_HISTID INT
Select @iHist_HISTID=max(HIST_HISTID) from BT_ACT_HIST
IF @HIST_internalRef IS NULL OR @HIST_metaModelType2 IS NULL
BEGIN
	SELECT 
		@HIST_internalRef = CASE WHEN @HIST_internalRef IS NOT NULL 
								THEN @HIST_internalRef 
								ELSE AE_internalRef END,
		@HIST_metaModelType2 = CASE WHEN @HIST_metaModelType2 IS NOT NULL 
								THEN @HIST_metaModelType2 
								ELSE AE_metaModelType2 END
	FROM dbo.BT_CTK_HEADER 
	WHERE AE_AEID = @HIST_AEID
END

if @HIST_tableName = 'BT_ACT_STANDARDS' AND (@HIST_columnName = 'sta_target_date' OR @HIST_columnName = 'sta_achieved_date') AND @HIST_dateTime = '1900-01-01 00:00:00' --if target date is passed as 1900-01-01 00:00:00 then no target date has been set
BEGIN 
	set @HIST_dateTime = null
END

SELECT TOP 1 @HIST_lastChange = HIST_HISTID
FROM BT_ACT_HIST
WHERE HIST_AEID = @HIST_AEID
AND HIST_fieldName = @HIST_fieldName
ORDER BY HIST_dateCreated DESC

	INSERT BT_ACT_HIST(
	HIST_HISTID,
	HIST_AEID,
	HIST_lastChange,
	HIST_internalRef,
	HIST_metaModelType2,
	HIST_fieldType,
	HIST_fieldName,
	HIST_tableName,
	HIST_columnName,
	HIST_valueInt,
	HIST_valueChar,
	HIST_descr,
	HIST_dateTime,
	HIST_dateCreated,
	HIST_createdBy,
	HIST_createdByDescr,
	HIST_foreignKeyId
	)
	VALUES(
	--@iHist_HISTID+1,
	(Select max(HIST_HISTID)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK)),
	@HIST_AEID,
	@HIST_lastChange,
	@HIST_internalRef,
	@HIST_metaModelType2,
	@HIST_fieldType,
	@HIST_fieldName,
	@HIST_tableName,
	@HIST_columnName,
	@HIST_valueInt,
	@HIST_valueChar,
	@HIST_descr,
	@HIST_dateTime,
	getDate(),
	@HIST_createdBy,
	@HIST_createdByDescr,
	@HIST_foreignKeyId
	)
END
GO
