/******************************************************************************
  V3-01 - OPTIMIZED PROCEDURE - NOT EXECUTED - REVIEW AND TEST BEFORE DEPLOYMENT
  Procedure : [dbo].[PRC_Standard_Letter_KeyValues_V1]  (letter generation)
  Original  : QPID_SP/PRC_Standard_Letter_KeyValues_V1.sql (analysed in B24-2,
              not changed in phase 1 or phase 2)
  Batch     : V3-01 (2026-10-29)
  Generated : optimization_v3/tools/gen_v3_01.py (inverse transform ==
              original; parameter predicate token-checked)
  Depends on: nothing new. Guards G1-G2 below REFUSE loudly (error 16 +
              NOEXEC); the last batch prints DEPLOYED / NOT DEPLOYED.

  WHY:
    Production baseline: 2,299 execs, avg 629.25 ms, CPU 222.24 ms,
    12,035 reads, 24.1 min total = 98% of the SQL time of the three
    letter SPs (PRC_STL_GenLetter_ADD_V2 9.9 ms, usp_updateLetterAfterSave
    11.2 ms). ~407 ms per call is waiting. Per call it TRUNCATEs two shared
    permanent tables (Sch-M lock: concurrent letters queue) and compiles
    one or two ad hoc UNION ALL statements with the reference as a
    literal (no plan reuse).

  WHAT CHANGED:
    1. Answers: table variable with the column types of
       tmp_letter_response (same conversions as the old INSERT ... SELECT
       *). The shared tables are only truncated / filled / read when stored
       SQL mentions tmp_letter (checked per call; legacy path = original).
    2. Reference: a parameter of sp_executesql (@qpid_v3_RefNo
       varchar(50) = @RefNo) where the fragment end is provably plain code;
       the original literal everywhere else. Same text per letter
       template -> one cached plan per template instead of one compile
       per call.
    3. Free-text answers: quotes doubled.
    4. Pound literals as CHAR(163) (ASCII file). CREATE -> ALTER.
    Not changed: placeholder / VAT / GROUP BY logic, YESNO lookups, the
    FORMULA path (still replaces ACTIVITYID with the literal), the BOM
    child, the PRINTs, result set shapes.

  WHY IT IS EQUIVALENT (single caller):
    - The cursor read exactly the rows the call had just inserted; it now
      reads the same rows, typed the same, from the table variable.
    - Literal '<ref>' (varchar) and a varchar(50) parameter holding the
      same value give the same comparisons, concatenations and
      conversions; collation coercibility is the same (coercible-
      default). The parameter is used only after = < > + or LIKE, with
      the fragment ending outside any string / comment / identifier.
    - The UNION ALL structure (and so its result typing) is unchanged.

  BEHAVIOUR DIFFERENCES (sign-off):
    a. Concurrent letters no longer see each other's answers (bug fix).
    b. An apostrophe in a free-text answer or in the reference no longer
       fails the letter / injects SQL (bug fix; FORMULA path excepted).
    c. Row order of the key/value result has no ORDER BY in either
       version; a different cursor plan can order rows differently.
       The harness (validation/v3_01_validation.sql H) compares as a
       multiset and reports order separately.

  EXPECTED: an estimate, not measured: the TRUNCATE queueing and most of
    the per-call compile CPU go. Reads inside the placeholder SQL and the
    BOM child (SP_GET_BOM_EstimateSummary_letter, 3.8 s on 86 calls) are
    unchanged.

  ROLLBACK: optimization_v3/rollback/PRC_Standard_Letter_KeyValues_V1_ORIGINAL.sql
******************************************************************************/
-- Guards (V3-01). A failure raises error 16 AND sets NOEXEC ON, so the
-- ALTER below is compiled but NOT executed. The last batch switches NOEXEC
-- off and prints whether V3-01 is live.
-- G1: the pound sign is written as CHAR(163); that is the same character
--     as the original literal only under code page 1252.
IF COLLATIONPROPERTY(CONVERT(sysname, DATABASEPROPERTYEX(DB_NAME(), 'Collation')), 'CodePage') <> 1252
BEGIN
    RAISERROR('REFUSED (G1): database code page is not 1252; CHAR(163) is not the pound sign here.', 16, 1);
    SET NOEXEC ON;
END
GO
-- G2: the per-call legacy check covers stored fragments and formulas, not
--     functions / views they might call. Refuse if one reads tmp_letter_*.
IF EXISTS (SELECT 1 FROM sys.sql_modules m JOIN sys.objects o ON o.object_id = m.object_id
           WHERE o.type IN ('FN', 'IF', 'TF', 'V') AND UPPER(m.definition) LIKE '%TMP_LETTER%')
   OR EXISTS (SELECT 1 FROM sys.synonyms WHERE UPPER(base_object_name) LIKE '%TMP_LETTER%')
BEGIN
    RAISERROR('REFUSED (G2): a function / view / synonym references tmp_letter_* (V3-01.1 lists it).', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROC [dbo].[PRC_Standard_Letter_KeyValues_V1]
@sLetter_ID int,
@RefNo varchar(50),
@TbType_SL_QueAns Type_SL_QueAns READONLY
AS
Begin

declare @vqustr as nvarchar(max)
declare @vMergeName as varchar(MAX)
declare @vDesc as nvarchar(max)
declare @AEID int
-- QPID_OPT V3-01 (2026-10-29): see optimization_v3/OPTIMIZATION_SUMMARY_V3.md
declare @v3_legacy bit
declare @v3_pre nvarchar(max), @v3_rev nvarchar(max), @v3_arg nvarchar(max)
declare @v3_k bigint
declare @v3_ws varchar(10)
declare @v3_resp as table (question_id int NOT NULL, response int NULL, responsetext varchar(max) NULL)
set @v3_legacy = 0
set @v3_ws = '%[^ ' + char(9) + char(10) + char(13) + ']%'
set @vqustr=''

Declare @tb As Table
(
	id int primary key identity(1,1),
	MergeName Varchar(MAX),
	[Desc] varchar(max),
	[Values] varchar(max) 
)

Declare @tb_final As Table
(
	MergeName Varchar(MAX),
	[Desc] varchar(max)
)

if @RefNo like '%ph%'
Begin
Select @AEID=AE_AEID 
from BT_PROJ_HEADER WHERE AE_internalRef=@RefNo 
Select @RefNo=WAY_WAYID FROM BT_ACT_WAYLEAVES  WHERE WAY_AEID=@AEID
End

-- V3-01: the shared work tables are used only when stored SQL reads them
if exists (select 1 from MT_TEM_STL_PLACEHOLDER where upper([Desc]) like '%TMP_LETTER%')
   or exists (select 1 from MT_LETTER_BOOKMARK where upper(ResponseText1) like '%TMP_LETTER%')
	set @v3_legacy = 1
if @v3_legacy = 1
begin
truncate table tmp_letter_query
truncate table tmp_letter_response
INSERT INTO tmp_letter_response SELECT * FROM @TbType_SL_QueAns
end
else
	INSERT INTO @v3_resp SELECT * FROM @TbType_SL_QueAns

Insert into @tb(MergeName,[Desc])
Select C.MergeName,c.[Desc] from MT_TEM_STL_PLC_MAPPING A
inner Join [MT_TEM_STANDARDLETTER] B On A.sLetter_ID=B.sLetter_ID
inner JOIN MT_TEM_STL_PLACEHOLDER C on A.ID_PLACEHOLDER=C.ID_PLACEHOLDER
inner join MT_TEM_MERGETEMPLATE D on B.sLetter_MergeTemID=D.MergeTem_ID
Where A.sLetter_ID=@sLetter_ID
Order by C.ID_PLACEHOLDER asc

DECLARE curmerge_query CURSOR FOR
Select C.MergeName,c.[Desc] from MT_TEM_STL_PLC_MAPPING A
inner Join [MT_TEM_STANDARDLETTER] B On A.sLetter_ID=B.sLetter_ID
inner JOIN MT_TEM_STL_PLACEHOLDER C on A.ID_PLACEHOLDER=C.ID_PLACEHOLDER
inner join MT_TEM_MERGETEMPLATE D on B.sLetter_MergeTemID=D.MergeTem_ID
Where A.sLetter_ID=@sLetter_ID and C.MergeName not like 'PLACEHOLDER%'
Order by C.ID_PLACEHOLDER asc

OPEN curmerge_query

----	Get All Template activities
FETCH NEXT FROM curmerge_query INTO @vMergeName, @vDesc
WHILE @@FETCH_STATUS = 0
BEGIN
	---- Insert New Activity
	--set @vqustr=@vqustr + ' union all ' + 'select '''+ @vMergeName + ''',(' +  @vDesc + '''' + @RefNo + ''' )'

	--Added by Jaydeep
	Declare @RemovedStr varchar(max);
	DECLARE @StartIndex smallint, @EndIndex smallint

	SET @StartIndex = CHARINDEX('GROUP BY', Upper(@vDesc))
	if(@StartIndex>0)
	Begin
		SET @EndIndex = LEN(@vDesc)
		Set @RemovedStr= SUBSTRING(@vDesc, @StartIndex , @EndIndex)

		Set @vDesc=SUBSTRING(@vDesc, 1 , @StartIndex-1)

		-- Insert New Activit
		-- V3-01: reference as a parameter when the fragment end is provably plain code
		set @v3_pre = @vDesc
		set @v3_rev = reverse(@v3_pre)
		set @v3_k = patindex(@v3_ws, @v3_rev)
		set @v3_arg = case when @RefNo is not null and @v3_k > 0
			and charindex('--', @v3_pre) = 0 and charindex('/*', @v3_pre) = 0
			and charindex('[', @v3_pre) = 0 and charindex('"', @v3_pre) = 0
			and (datalength(@v3_pre) - datalength(replace(@v3_pre, '''', ''))) % 4 = 0
			and (substring(@v3_rev, @v3_k, 1) in ('=', '<', '>', '+')
				or (upper(substring(@v3_rev, @v3_k, 4)) = 'EKIL'
					and substring(@v3_rev, @v3_k + 4, 1) in (' ', char(9), char(10), char(13), ')')))
			then ' @qpid_v3_RefNo' else '''' + @RefNo + '''' end
		set @vqustr=@vqustr + ' union all ' + 'select '''+ @vMergeName + ''',(' +  @vDesc + @v3_arg +' '+ @RemovedStr + ' )'
	End
	Else
	Begin
		--set @vqustr=@vqustr + ' union all ' + 'select '''+ @vMergeName + ''',(' +  @vDesc + '''' + @RefNo + ''' )'
		IF @vDesc NOT IN (SELECT [desc] FROM MT_TEM_STL_PLACEHOLDER WHERE MergeName in ('VatRate0Percent','VatRate5Percent','VatRate10Percent','VatRate15Percent','VatRate17Point5Percent','VatRate20Percent'))
		BEGIN
			-- V3-01: reference as a parameter when the fragment end is provably plain code
			set @v3_pre = @vDesc
			set @v3_rev = reverse(@v3_pre)
			set @v3_k = patindex(@v3_ws, @v3_rev)
			set @v3_arg = case when @RefNo is not null and @v3_k > 0
				and charindex('--', @v3_pre) = 0 and charindex('/*', @v3_pre) = 0
				and charindex('[', @v3_pre) = 0 and charindex('"', @v3_pre) = 0
				and (datalength(@v3_pre) - datalength(replace(@v3_pre, '''', ''))) % 4 = 0
				and (substring(@v3_rev, @v3_k, 1) in ('=', '<', '>', '+')
					or (upper(substring(@v3_rev, @v3_k, 4)) = 'EKIL'
						and substring(@v3_rev, @v3_k + 4, 1) in (' ', char(9), char(10), char(13), ')')))
				then ' @qpid_v3_RefNo' else '''' + @RefNo + '''' end
			set @vqustr=@vqustr + ' union all ' + 'select '''+ @vMergeName + ''',(' +  @vDesc + @v3_arg + ' )'
		END
		ELSE 
		BEGIN 
			set @vqustr=@vqustr + ' union all ' + 'select '''+ @vMergeName + ''',(' +  @vDesc + ' )'
		END
	End
	--End Added by Jaydeep

	FETCH NEXT FROM curmerge_query INTO @vMergeName, @vDesc

END

CLOSE curmerge_query
DEALLOCATE curmerge_query
declare @finalquery as nvarchar(max)
set @finalquery=substring(@vqustr,11,len(@vqustr));
print @finalquery
-- V3-01: same text, run with the reference parameter (NULL text: EXEC, a no-op as before)
if @finalquery is null
begin
	insert into @tb_final
	exec (@finalquery)
end
else
begin
	insert into @tb_final
	exec sp_executesql @finalquery, N'@qpid_v3_RefNo varchar(50)', @qpid_v3_RefNo = @RefNo
end


declare @vquestion_id as int
declare @vresponse as int
declare @vresponsetext as varchar(max)
declare @vques_type as varchar(50)
declare @vResponseText1 as nvarchar(max)
declare @vResponseYes as varchar(50)
declare @vResponseNo as varchar(50)
declare @vBOOKMARKNAME as varchar(50)
DECLARE @VBOOKMARKTYPE AS VARCHAR(50)
set @vqustr=''
-- V3-01: the cursor reads this call's answers (table variable); legacy path = original
if @v3_legacy = 1
begin
DECLARE curquestionYesNo_query CURSOR FOR
select question_id,response,responsetext,mastertab.ques_type,ResponseYes,ResponseNo,ResponseText1,BOOKMARKNAME,BOOKMARKTYPE
from MT_LETTER_QUES_MAPPING maptab,tmp_letter_response responsetab,mt_question_set_master mastertab,MT_LETTER_BOOKMARK bookmark
where responsetab.question_id=mastertab.ques_id 
and maptab.ques_id=mastertab.ques_id 
and bookmark.ques_id=question_id 
and letterid=@sLetter_ID --@sLetter_ID
end
else
begin
DECLARE curquestionYesNo_query CURSOR FOR
select question_id,response,responsetext,mastertab.ques_type,ResponseYes,ResponseNo,ResponseText1,BOOKMARKNAME,BOOKMARKTYPE
from MT_LETTER_QUES_MAPPING maptab,@v3_resp responsetab,mt_question_set_master mastertab,MT_LETTER_BOOKMARK bookmark
where responsetab.question_id=mastertab.ques_id 
and maptab.ques_id=mastertab.ques_id 
and bookmark.ques_id=question_id 
and letterid=@sLetter_ID --@sLetter_ID
end

OPEN curquestionYesNo_query

----	Get All Template activities
FETCH NEXT FROM curquestionYesNo_query INTO @vquestion_id,@vresponse,@vresponsetext,@vques_type,@vResponseYes,@vResponseNo,@vResponseText1,@vBOOKMARKNAME,@VBOOKMARKTYPE
WHILE @@FETCH_STATUS = 0
BEGIN
-- Insert New Activity

if @vques_type='YESNO'
BEGIN
	if @vresponse=1
	BEGIN
	print 'IN1'
		select @vDesc=[desc] from MT_TEM_STL_PLACEHOLDER where mergename=@vResponseYes
		-- V3-01: reference as a parameter when the fragment end is provably plain code
		set @v3_pre = @vDesc
		set @v3_rev = reverse(@v3_pre)
		set @v3_k = patindex(@v3_ws, @v3_rev)
		set @v3_arg = case when @RefNo is not null and @v3_k > 0
			and charindex('--', @v3_pre) = 0 and charindex('/*', @v3_pre) = 0
			and charindex('[', @v3_pre) = 0 and charindex('"', @v3_pre) = 0
			and (datalength(@v3_pre) - datalength(replace(@v3_pre, '''', ''))) % 4 = 0
			and (substring(@v3_rev, @v3_k, 1) in ('=', '<', '>', '+')
				or (upper(substring(@v3_rev, @v3_k, 4)) = 'EKIL'
					and substring(@v3_rev, @v3_k + 4, 1) in (' ', char(9), char(10), char(13), ')')))
			then ' @qpid_v3_RefNo' else '''' + @RefNo + '''' end
		set @vqustr=@vqustr + ' union all ' + 'select '''+ @vBOOKMARKNAME + ''',(' +  @vDesc + @v3_arg + ' )'
	END
	ELSE
	BEGIN
	print 'IN2'
		select @vDesc=[desc] from MT_TEM_STL_PLACEHOLDER where mergename=@vResponseNo
		-- V3-01: reference as a parameter when the fragment end is provably plain code
		set @v3_pre = @vDesc
		set @v3_rev = reverse(@v3_pre)
		set @v3_k = patindex(@v3_ws, @v3_rev)
		set @v3_arg = case when @RefNo is not null and @v3_k > 0
			and charindex('--', @v3_pre) = 0 and charindex('/*', @v3_pre) = 0
			and charindex('[', @v3_pre) = 0 and charindex('"', @v3_pre) = 0
			and (datalength(@v3_pre) - datalength(replace(@v3_pre, '''', ''))) % 4 = 0
			and (substring(@v3_rev, @v3_k, 1) in ('=', '<', '>', '+')
				or (upper(substring(@v3_rev, @v3_k, 4)) = 'EKIL'
					and substring(@v3_rev, @v3_k + 4, 1) in (' ', char(9), char(10), char(13), ')')))
			then ' @qpid_v3_RefNo' else '''' + @RefNo + '''' end
		set @vqustr=@vqustr + ' union all ' + 'select '''+ @vBOOKMARKNAME + ''',(' +  @vDesc + @v3_arg + ' )'
	END	
END
ELSE
BEGIN
print 'IN3'
--insert into tmp_letter_query values(@VBOOKMARKTYPE)
--insert into tmp_letter_query values('@VBOOKMARKTYPE')
	IF @VBOOKMARKTYPE='FORMULA'
		BEGIN
		PRINT 'TEST'
		PRINT @vResponseText1
		declare @vtmp as nvarchar(max)
		print @vtmp
		PRINT 'vtmp'
		set @vtmp=replace(@vResponseText1,'ACTIVITYID',@RefNo)
		print @vtmp
--		insert into tmp_letter_query values(@vResponseText1)
--insert into tmp_letter_query values('@@vResponseText1')
			set @vqustr=@vqustr + ' union all ' + @vtmp + ' '
			
		END
	ELSE
	BEGIN

	--select @vDesc=[desc] from MT_TEM_STL_PLACEHOLDER where mergename=@vResponseText1
		-- V3-01: quotes in the answer are doubled (an apostrophe used to break the letter)
		set @vqustr=@vqustr + ' union all ' + 'select '''+ @vBOOKMARKNAME + ''',''' + replace(CAse 
		When @vBOOKMARKNAME ='VAT'				Then Concat(@vresponsetext,'%')
		When @vBOOKMARKNAME ='VATPRO'				Then Concat(@vresponsetext,'%') 
		When @vBOOKMARKNAME ='COSTEXCVAT'		Then Concat(CHAR(163),FORMAT(cast(@vresponsetext as money),'N2'))
		When @vBOOKMARKNAME ='COST_EXC_VAT'		Then Concat(CHAR(163),FORMAT(cast(@vresponsetext as money),'N2'))
		When @vBOOKMARKNAME ='IMPORT_CAPACITY'	Then Concat(FORMAT(cast(@vresponsetext as money),'N0'),'kVA')
	    When @vBOOKMARKNAME ='EXPORT_CAPACITY'	Then Concat(FORMAT(cast(@vresponsetext as money),'N0'),'kVA')
		When @vBOOKMARKNAME ='SUPPLY_CAPACITY'	Then Concat(FORMAT(cast(@vresponsetext as money),'N0'),'kVA') 
	--  When @vBOOKMARKNAME ='DIV_LOAD'			Then Concat(FORMAT(cast(@@vresponsetext,'N0'),'kVA') 
        When @vBOOKMARKNAME ='DISCOUNTEDCOST75' Then FORMAT(cast(@vresponsetext as money),'N2')
		When @vBOOKMARKNAME ='PREVIOUSLY_PAID'	Then FORMAT(cast(@vresponsetext as money),'N2') 
		When @vBOOKMARKNAME ='MATERIALC'		Then Concat(CHAR(163),FORMAT(cast(@vresponsetext as money),'N2'))
		When @vBOOKMARKNAME ='DIRECTLABC'		Then Concat(CHAR(163),FORMAT(cast(@vresponsetext as money),'N2'))
		When @vBOOKMARKNAME ='CONTRACTEDLABC'	Then Concat(CHAR(163),FORMAT(cast(@vresponsetext as money),'N2'))
		When @vBOOKMARKNAME ='PAYMENT_DUE'		Then FORMAT(cast(@vresponsetext as money),'N2')
		
		ELSE @vresponsetext END, '''', '''''') + ''''

	END
END
	FETCH NEXT FROM curquestionYesNo_query INTO @vquestion_id,@vresponse,@vresponsetext,@vques_type,@vResponseYes,@vResponseNo,@vResponseText1,@vBOOKMARKNAME,@VBOOKMARKTYPE

END

CLOSE curquestionYesNo_query
DEALLOCATE curquestionYesNo_query
--insert into tmp_letter_query values(@finalquery)
--insert into tmp_letter_query values('@@@finalquery')

set @finalquery=substring(@vqustr,11,len(@vqustr))
--insert into tmp_letter_query values(@finalquery)
--insert into tmp_letter_query values('@@@finalquery')
-- V3-01: same text, run with the reference parameter (NULL text: EXEC, a no-op as before)
if @finalquery is null
begin
	insert into @tb_final
	exec (@finalquery);
end
else
begin
	insert into @tb_final
	exec sp_executesql @finalquery, N'@qpid_v3_RefNo varchar(50)', @qpid_v3_RefNo = @RefNo;
end

select MergeName,isnull([DESC],'') from @tb_final
--exec (@finalquery)
declare @cnt as int
declare @estref as varchar(20)
Select @cnt=count(*) from MT_TEM_STL_PLC_MAPPING A
inner Join [MT_TEM_STANDARDLETTER] B On A.sLetter_ID=B.sLetter_ID
inner JOIN MT_TEM_STL_PLACEHOLDER C on A.ID_PLACEHOLDER=C.ID_PLACEHOLDER
inner join MT_TEM_MERGETEMPLATE D on B.sLetter_MergeTemID=D.MergeTem_ID
Where A.sLetter_ID=@sLetter_ID and C.MergeName like 'PLACEHOLDER%';

if @cnt>0
begin
select top 1 @estref=AE_internalRef  from BT_ESTIMATE_MASTER where AE_ParentID in (
select ae_aeid from BT_QUOTE_MASTER where AE_internalRef=@RefNo) and AE_deleted='N'

if coalesce(@estref,'')<>''
begin
exec [SP_GET_BOM_EstimateSummary_letter] @estref,10003719
end
end

END
--Select * from MT_TEM_STL_PLC_MAPPING
-- delete from MT_TEM_STL_PLC_MAPPING where ID_MAPPING=24
-- Select * from MT_TEM_STL_PLACEHOLDER
-- Select * from [MT_TEM_STANDARDLETTER]


GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID('dbo.PRC_Standard_Letter_KeyValues_V1')) LIKE '%QPID_OPT V3-01%'
    PRINT 'DEPLOYED: V3-01 is live.';
ELSE
    RAISERROR('NOT DEPLOYED: the original PRC_Standard_Letter_KeyValues_V1 is still live (see the REFUSED message above).', 16, 1);
GO
