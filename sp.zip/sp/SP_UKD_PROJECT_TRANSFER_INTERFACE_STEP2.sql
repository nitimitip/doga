USE [QPID_PROD]
GO
/****** Object:  StoredProcedure [dbo].[SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP2]    Script Date: 12/10/2026 10:48:12 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP2]
-- [AR-BEGIN change note]
-- 2026-11-02 AR: before every INSERT INTO OPENQUERY(CFSPROD, ...) the same
--   rows are copied into AR_<CFS table> (kept 4 months), and each section
--   is logged in AR_UKD_PROJECT_TRANSFER_STEP2_LOG. Business logic is unchanged:
--   the CFS INSERT statements are the originals; all added code is between
--   the AR-BEGIN / AR-END markers and can never stop the transfer.
-- [AR-END]
ALTER PROCEDURE [dbo].[SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP2]  
AS  
declare @G_ERROR_PLACE     varchar(60)  
declare @G_ERROR_MSG       varchar(200)  
declare @G_ERROR_CODE      int  
declare @l_exit_flag       int   
declare @l_bud_id          int  
declare @l_task            int  
declare @l_proj            int  
declare @l_version         int  
declare @l_costType        varchar(30)  
declare @l_ExpenType       varchar(30)  
declare @l_budCost         numeric  
declare @l_bud_delete_flag varchar(1)  
declare @canConnect  varchar(1) 
declare @maximumNumberOfProjectsPerCFSBatch int 
begin   
   
declare @l_MainBatchID  varchar(30), @l_StatusBatchID varchar(30)  
declare @agentCDMS_CFSID VARCHAR(50)   
-- [AR-BEGIN archive variables]
declare @l_ar_run_id    uniqueidentifier = NEWID()
declare @l_ar_run_date  datetime = GETDATE()
declare @l_ar_nocount   bit = CASE WHEN (@@OPTIONS & 512) = 512 THEN 1 ELSE 0 END
declare @l_ar_rows      int
declare @l_ar_msg       nvarchar(2000)
declare @l_ar_log_id    int
declare @l_ar_cfs_rows  int
declare @l_ar_cfs_err   int
-- [AR-END]
--CFSDBTEST
--PROJECTS

-- [AR-BEGIN archive PROJECTS -> AR_XX_PROJECTS_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_PROJECTS_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_PROJECTS_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             PM_PROJECT_REFERENCE, PROJECT_NUMBER, PROJECT_NAME, DESCRIPTION, START_DATE, COMPLETION_DATE, CUSTOMER_NUMBER, COPY_TEMPLATE_TASKS_FLAG, TEMPLATE_NUMBER, PROJECT_ORGANIZATION, RECORD_VERSION, BATCH_NAME, PM_PRODUCT_CODE, ORG_ID, STATUS_FLAG, PROJECT_RELATIONSHIP_CODE, CONTRIBUTION_PERCENT, DEFAULT_TOP_TASK_CUSTOMER)
        SELECT @l_ar_run_id, @l_ar_run_date, 'PROJECTS',  
        	ProjTaskRef as PM_PROJECT_REFERENCE, 
        	ProjTaskNum as PROJECT_NUMBER, 
        	LEFT(LTRIM(RTRIM(ProjTaskName)),29) ProjName,
                	ProjTaskDesc ProjDescr,
         --       	NULL template,  
        	--ProjStatus,
                	replace(convert(varchar,StartDate,106),' ','-') StartDate, 
        	replace(convert(varchar, CompletionDate,106),' ','-') CompletionDate, 
                	CustomerID, 
        	'Y' CopyTasksFlag,
         --       	ProjType ProjectCategory, 
        	--ProjCategory ClassCode, 
         --       	ProjCategory2, ProjClassCode2,
        	ProjBillingOption,  --for go-live replace default value with this.
        	ProjOrganisation, --for go-live replace default value with this.
                	Version ,BatchName,
        	'CDMS' as PM_PRODUCT_CODE ,
        	103, --5000, --ORG_ID, added by SJ 
        	'P' as STATUS_FLAG ,
        	'PRIMARY' as PROJECT_RELATIONSHIP_CODE,
        	null as CONTRIBUTION_PERCENT,	
        	'Y' as DEFAULT_TOP_TASK_CUSTOMER

        FROM xt_xface_projects_task
        WHERE ProjectTaskType = 'P' ;
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_PROJECTS_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'PROJECTS', 'CDALINK.XX_PROJECTS_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
INSERT INTO OPENQUERY (CFSPROD,'SELECT PM_PROJECT_REFERENCE,
PROJECT_NUMBER,
PROJECT_NAME,
DESCRIPTION,
START_DATE,
COMPLETION_DATE,
CUSTOMER_NUMBER,
COPY_TEMPLATE_TASKS_FLAG,
TEMPLATE_NUMBER,
PROJECT_ORGANIZATION,
RECORD_VERSION,
BATCH_NAME,
PM_PRODUCT_CODE,
ORG_ID,
STATUS_FLAG,
PROJECT_RELATIONSHIP_CODE,
CONTRIBUTION_PERCENT,          
DEFAULT_TOP_TASK_CUSTOMER FROM CDALINK.XX_PROJECTS_XFACE')
SELECT  
	ProjTaskRef as PM_PROJECT_REFERENCE, 
	ProjTaskNum as PROJECT_NUMBER, 
	LEFT(LTRIM(RTRIM(ProjTaskName)),29) ProjName,
        	ProjTaskDesc ProjDescr,
 --       	NULL template,  
	--ProjStatus,
        	replace(convert(varchar,StartDate,106),' ','-') StartDate, 
	replace(convert(varchar, CompletionDate,106),' ','-') CompletionDate, 
        	CustomerID, 
	'Y' CopyTasksFlag,
 --       	ProjType ProjectCategory, 
	--ProjCategory ClassCode, 
 --       	ProjCategory2, ProjClassCode2,
	ProjBillingOption,  --for go-live replace default value with this.
	ProjOrganisation, --for go-live replace default value with this.
        	Version ,BatchName,
	'CDMS' as PM_PRODUCT_CODE ,
	103, --5000, --ORG_ID, added by SJ 
	'P' as STATUS_FLAG ,
	'PRIMARY' as PROJECT_RELATIONSHIP_CODE,
	null as CONTRIBUTION_PERCENT,	
	'Y' as DEFAULT_TOP_TASK_CUSTOMER

FROM xt_xface_projects_task
WHERE ProjectTaskType = 'P' ;
-- [AR-BEGIN result of CFS insert PROJECTS]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

--TASKS
-- [AR-BEGIN archive TASKS -> AR_XX_TASKS_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_TASKS_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_TASKS_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             BATCH_NAME, TASK_NUMBER, PM_TASK_REFERENCE, TASK_NAME, TASK_DESCRIPTION, TASK_START_DATE, TASK_COMPLETION_DATE, PM_PARENT_TASK_REFERENCE, SERVICE_TYPE_CODE, RECORD_VERSION, PM_PRODUCT_CODE, ORG_ID, STATUS_FLAG, PM_PROJECT_REFERENCE, PROJECT_NUMBER, RECEIVER_TASK, TASK_CUSTOMER)
        select distinct @l_ar_run_id, @l_ar_run_date, 'TASKS', t.BatchName, 
        	--t.ParentProj, 
        	t.ProjTaskNum TaskNum , 
        	t.ProjTaskRef TaskRef,
        	LEFT(LTRIM(RTRIM(t.ProjTaskName)),20) TaskName ,
        	replace(coalesce(t.ProjTaskDesc,''),char(13),'') TaskDesc,
                t.StartDate, 
        	t.CompletionDate, 
        	NULL,--dbo.[f_get_parent_task_V1](t.ProjTaskRef) ParentTask, 
                t.TaskServiceType,
              --  NULL BilableFlag, 
        	--NULL ChargeableFlag, 
        	t.Version,
        	'CDMS' as PM_PRODUCT_CODE ,
        	103,--5000,-- t.ORG_ID, --CEES ORG ID
        	'P' as STATUS_FLAG,
        	t.ParentProj as PM_PROJECT_REFERENCE  ,
        	t.ProjIntRef as PROJECT_NUMBER,
        	'N' as RECEIVER_TASK,
        	t.CustomerID

           from   xt_xface_projects_task t, xt_xface_projects_task p 
        	where t.ParentProj = p.ProjTaskRef and p.ProjectTaskType = 'P' 
           and t.ProjectTaskType = 'T' ;
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_TASKS_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'TASKS', 'CDALINK.XX_TASKS_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
INSERT INTO OPENQUERY(CFSPROD, 'SELECT BATCH_NAME,
TASK_NUMBER,
PM_TASK_REFERENCE,
TASK_NAME,
TASK_DESCRIPTION,
TASK_START_DATE,
TASK_COMPLETION_DATE,
PM_PARENT_TASK_REFERENCE,
SERVICE_TYPE_CODE,
RECORD_VERSION,
PM_PRODUCT_CODE,
ORG_ID,
STATUS_FLAG,
PM_PROJECT_REFERENCE,
PROJECT_NUMBER,
RECEIVER_TASK,
TASK_CUSTOMER FROM CDALINK.XX_TASKS_XFACE')
select distinct t.BatchName, 
	--t.ParentProj, 
	t.ProjTaskNum TaskNum , 
	t.ProjTaskRef TaskRef,
	LEFT(LTRIM(RTRIM(t.ProjTaskName)),20) TaskName ,
	replace(coalesce(t.ProjTaskDesc,''),char(13),'') TaskDesc,
        t.StartDate, 
	t.CompletionDate, 
	NULL,--dbo.[f_get_parent_task_V1](t.ProjTaskRef) ParentTask, 
        t.TaskServiceType,
      --  NULL BilableFlag, 
	--NULL ChargeableFlag, 
	t.Version,
	'CDMS' as PM_PRODUCT_CODE ,
	103,--5000,-- t.ORG_ID, --CEES ORG ID
	'P' as STATUS_FLAG,
	t.ParentProj as PM_PROJECT_REFERENCE  ,
	t.ProjIntRef as PROJECT_NUMBER,
	'N' as RECEIVER_TASK,
	t.CustomerID

   from   xt_xface_projects_task t, xt_xface_projects_task p 
	where t.ParentProj = p.ProjTaskRef and p.ProjectTaskType = 'P' 
   and t.ProjectTaskType = 'T' ;
-- [AR-BEGIN result of CFS insert TASKS]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

   --KEY MEMBERS

-- [AR-BEGIN archive KEY MEMBERS -> AR_XX_KEY_MEMBERS_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_KEY_MEMBERS_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_KEY_MEMBERS_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             BATCH_NAME, PM_PROJECT_REFERENCE, PROJECT_ROLE_TYPE, EMPLOYEE_NUMBER, START_DATE, RECORD_VERSION, PM_PRODUCT_CODE, ORG_ID, STATUS_FLAG, PROJECT_NUMBER)
             select @l_ar_run_id, @l_ar_run_date, 'KEY MEMBERS', BatchName, 
        	ProjTaskRef as PM_PROJECT_REFERENCE, 
        	KeyPersonRole, 
        	KeyPerson, 
        	replace(convert(varchar,StartDate,106),' ','-') StartDate, --Key members need to have the same start date as the project
        	--NULL EndDate,
        	Version,
        	'CDMS' as PM_PRODUCT_CODE ,
        	103,--5000, --ORG_ID, --CEES ORG ID
        	'P' as STATUS_FLAG,
        	ProjTaskNum as PROJECT_NUMBER  
           from   dbo.xt_xface_projects_task
           where  ProjectTaskType = 'P' 
           and    Version > -1 
           and KeyPerson is not null;
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_KEY_MEMBERS_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'KEY MEMBERS', 'CDALINK.XX_KEY_MEMBERS_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
   INSERT INTO OPENQUERY(CFSPROD, 'SELECT BATCH_NAME,
PM_PROJECT_REFERENCE,
PROJECT_ROLE_TYPE,
EMPLOYEE_NUMBER,
START_DATE,
RECORD_VERSION,
PM_PRODUCT_CODE,
ORG_ID,
STATUS_FLAG,
PROJECT_NUMBER FROM CDALINK.XX_KEY_MEMBERS_XFACE')
     select BatchName, 
	ProjTaskRef as PM_PROJECT_REFERENCE, 
	KeyPersonRole, 
	KeyPerson, 
	replace(convert(varchar,StartDate,106),' ','-') StartDate, --Key members need to have the same start date as the project
	--NULL EndDate,
	Version,
	'CDMS' as PM_PRODUCT_CODE ,
	103,--5000, --ORG_ID, --CEES ORG ID
	'P' as STATUS_FLAG,
	ProjTaskNum as PROJECT_NUMBER  
   from   dbo.xt_xface_projects_task
   where  ProjectTaskType = 'P' 
   and    Version > -1 
   and KeyPerson is not null;
-- [AR-BEGIN result of CFS insert KEY MEMBERS]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

   --BILLING CONTACTS

-- [AR-BEGIN archive BILLING CONTACTS -> AR_XX_CUST_CONTACTS_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_CUST_CONTACTS_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_CUST_CONTACTS_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             BATCH_NAME, CUSTOMER_NUMBER, BILL_TO_ADDRESS_ID, SHIP_TO_ADDRESS_ID, PROJECT_CONTACT_ID, RECORD_VERSION, PM_PRODUCT_CODE, ORG_ID, STATUS_FLAG, PM_PROJECT_REFERENCE, PROJECT_NUMBER, PROJECT_CONTACT, CONTACT_ROLE)
          select @l_ar_run_id, @l_ar_run_date, 'BILLING CONTACTS', 
        	BatchName, 
                CustomerID, 
        	ProjBillAddrID as BILL_TO_ADDRESS_ID, 
        	ProjBillAddrID as SHIP_TO_ADDRESS_ID,
        	ProjBillContact as PRODUCT_CONTACT_ID,
                version ,
        	'CDMS' as PM_PRODUCT_CODE ,
        	103,--5000,--ORG_ID , --CEES ORG ID
        	'P' as STATUS_FLAG,
        	ProjTaskRef as PM_PROJECT_REFERENCE,
        	ProjTaskNum as PROJECT_NUMBER,
        	PROJECT_CONTACT,
        	'Billing' as CONTACT_ROLE     
          from   dbo.xt_xface_projects_task
          where  ProjectTaskType = 'P'
          and    Version > -1 ;
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_CUST_CONTACTS_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'BILLING CONTACTS', 'CDALINK.XX_CUST_CONTACTS_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
   INSERT INTO OPENQUERY(CFSPROD, 'SELECT BATCH_NAME,
CUSTOMER_NUMBER,
BILL_TO_ADDRESS_ID,
SHIP_TO_ADDRESS_ID,
PROJECT_CONTACT_ID,
RECORD_VERSION,
PM_PRODUCT_CODE,
ORG_ID,
STATUS_FLAG,
PM_PROJECT_REFERENCE,
PROJECT_NUMBER,
PROJECT_CONTACT,
CONTACT_ROLE FROM CDALINK.XX_CUST_CONTACTS_XFACE')
  select 
	BatchName, 
        CustomerID, 
	ProjBillAddrID as BILL_TO_ADDRESS_ID, 
	ProjBillAddrID as SHIP_TO_ADDRESS_ID,
	ProjBillContact as PRODUCT_CONTACT_ID,
        version ,
	'CDMS' as PM_PRODUCT_CODE ,
	103,--5000,--ORG_ID , --CEES ORG ID
	'P' as STATUS_FLAG,
	ProjTaskRef as PM_PROJECT_REFERENCE,
	ProjTaskNum as PROJECT_NUMBER,
	PROJECT_CONTACT,
	'Billing' as CONTACT_ROLE     
  from   dbo.xt_xface_projects_task
  where  ProjectTaskType = 'P'
  and    Version > -1 ;
-- [AR-BEGIN result of CFS insert BILLING CONTACTS]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

  --BUDGET LINES

-- [AR-BEGIN archive BUDGET LINES -> AR_XX_BUDGET_LINES_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_BUDGET_LINES_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_BUDGET_LINES_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             PM_BUDGET_REFERENCE, BUDGET_TYPE, RESOURCE_ALIAS, REVENUE, BATCH_NAME, RECORD_VERSION, PM_PRODUCT_CODE, ORG_ID, STATUS_FLAG, PM_PROJECT_REFERENCE, PROJECT_NUMBER, PM_TASK_REFERENCE, PM_BUDGET_LINE_REFERENCE, BUDGET_TYPE_CODE, BUDGET_START_DATE, RAW_COST, BURDENED_COST)
           select @l_ar_run_id, @l_ar_run_date, 'BUDGET LINES', 

        	b.BudgetReference, 
        	b.BudgetType, 
        	b.ExpenType, 
        	b.CostAmount, 
        	b.BatchName, 
        	b.Version ,
        	b.ProductCode as PM_PRODUCT_CODE ,
        	103,--5000,--b.ORG_ID, 
        	b.StatusFlag as STATUS_FLAG,
        	b.ProjectReference as PM_PROJECT_REFERENCE,
        	b.ProjectNumber as PROJECT_NUMBER,
        	b.TaskReference as PM_TASK_REFERENCE,
        	LEFT(convert(varchar,b.BudgetLineReference),20) as PM_BUDGET_LINE_REFERENCE,
        	b.BudgetTypeCode as BUDGET_TYPE_CODE,
        	b.StartDate as START_DATE,
        	b.Raw_Cost as RAW_COST,
        	b.Raw_Cost as BURDENED_COST

          from  xt_XFACE_TASK_BUDGET_LINES b --inner join CDMS_XFACE_PROJECTS_TASK p on b.ProjID = p.ProjTaskRef
        --inner join CDMS_XFACE_PROJECTS_TASK t on b.TaskID = t.ProjTaskRef
        --WHERE TaskID in (SELECT TASK_REFERENCE FROM CDMSLIVE..CDALINK.NE_CDA_TASKS) --removed for testing restore for live
          order by 1,2,5;
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_BUDGET_LINES_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'BUDGET LINES', 'CDALINK.XX_BUDGET_LINES_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
  INSERT INTO OPENQUERY(CFSPROD, 'SELECT PM_BUDGET_REFERENCE,
BUDGET_TYPE,
RESOURCE_ALIAS,
REVENUE,
BATCH_NAME,
RECORD_VERSION,
PM_PRODUCT_CODE,
ORG_ID,
STATUS_FLAG,
PM_PROJECT_REFERENCE,
PROJECT_NUMBER,
PM_TASK_REFERENCE,
PM_BUDGET_LINE_REFERENCE,
BUDGET_TYPE_CODE,
BUDGET_START_DATE,
RAW_COST,
BURDENED_COST FROM CDALINK.XX_BUDGET_LINES_XFACE')
   select 

	b.BudgetReference, 
	b.BudgetType, 
	b.ExpenType, 
	b.CostAmount, 
	b.BatchName, 
	b.Version ,
	b.ProductCode as PM_PRODUCT_CODE ,
	103,--5000,--b.ORG_ID, 
	b.StatusFlag as STATUS_FLAG,
	b.ProjectReference as PM_PROJECT_REFERENCE,
	b.ProjectNumber as PROJECT_NUMBER,
	b.TaskReference as PM_TASK_REFERENCE,
	LEFT(convert(varchar,b.BudgetLineReference),20) as PM_BUDGET_LINE_REFERENCE,
	b.BudgetTypeCode as BUDGET_TYPE_CODE,
	b.StartDate as START_DATE,
	b.Raw_Cost as RAW_COST,
	b.Raw_Cost as BURDENED_COST

  from  xt_XFACE_TASK_BUDGET_LINES b --inner join CDMS_XFACE_PROJECTS_TASK p on b.ProjID = p.ProjTaskRef
--inner join CDMS_XFACE_PROJECTS_TASK t on b.TaskID = t.ProjTaskRef
--WHERE TaskID in (SELECT TASK_REFERENCE FROM CDMSLIVE..CDALINK.NE_CDA_TASKS) --removed for testing restore for live
  order by 1,2,5;
-- [AR-BEGIN result of CFS insert BUDGET LINES]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

  --AGREEMENTS

-- [AR-BEGIN archive AGREEMENTS -> AR_XX_AGREEMENTS_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_AGREEMENTS_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_AGREEMENTS_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             AGREEMENT_NUMBER, PM_AGREEMENT_REFERENCE, BATCH_NAME, RECORD_VERSION, PM_PRODUCT_CODE, ORG_ID, STATUS_FLAG, AGREEMENT_TYPE, REVENUE_LIMIT_FLAG, AMOUNT, CUSTOMER_NUMBER, TERM_NAME)
          select distinct @l_ar_run_id, @l_ar_run_date, 'AGREEMENTS', 
        	AgreementNum, 
        	AgreementRef, 
        	BatchName, 
        	Version ,
        	ProductCode as PM_PRODUCT_CODE ,
        	103,--5000,--ORG_ID, 
        	STATUS_FLAG,
        	AGREEMENT_TYPE,
        	REVENUE_LIMIT_FLAG,
        	CostAmount as AMOUNT,
        	CUSTOMER_NUMBER,
        	TERM_NAME
          from   XT_XFACE_AGREEMENTS 
        --WHERE TaskID in (SELECT TASK_REFERENCE FROM CDMSLIVE..CDALINK.NE_CDA_TASKS) --removed for testing restore for live

          order by 1,2,5;
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_AGREEMENTS_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'AGREEMENTS', 'CDALINK.XX_AGREEMENTS_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
  INSERT INTO OPENQUERY(CFSPROD, 'SELECT AGREEMENT_NUMBER,
PM_AGREEMENT_REFERENCE,
BATCH_NAME,
RECORD_VERSION,
PM_PRODUCT_CODE,
ORG_ID,
STATUS_FLAG,
AGREEMENT_TYPE,
REVENUE_LIMIT_FLAG,
AMOUNT,
CUSTOMER_NUMBER,
TERM_NAME FROM CDALINK.XX_AGREEMENTS_XFACE')
  select distinct 
	AgreementNum, 
	AgreementRef, 
	BatchName, 
	Version ,
	ProductCode as PM_PRODUCT_CODE ,
	103,--5000,--ORG_ID, 
	STATUS_FLAG,
	AGREEMENT_TYPE,
	REVENUE_LIMIT_FLAG,
	CostAmount as AMOUNT,
	CUSTOMER_NUMBER,
	TERM_NAME
  from   XT_XFACE_AGREEMENTS 
--WHERE TaskID in (SELECT TASK_REFERENCE FROM CDMSLIVE..CDALINK.NE_CDA_TASKS) --removed for testing restore for live

  order by 1,2,5;
-- [AR-BEGIN result of CFS insert AGREEMENTS]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

  --FUNDINGS

-- [AR-BEGIN archive FUNDINGS -> AR_XX_FUNDINGS_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_FUNDINGS_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_FUNDINGS_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             PM_TASK_REFERENCE, AGREEMENT_NUMBER, PM_AGREEMENT_REFERENCE, ALLOCATED_AMOUNT, BATCH_NAME, RECORD_VERSION, PM_PRODUCT_CODE, ORG_ID, STATUS_FLAG, PM_PROJECT_REFERENCE, PROJECT_NUMBER, DATE_ALLOCATED, PM_FUNDING_REFERENCE, FUNDING_CATEGORY, CUSTOMER_NUMBER)

        SELECT distinct @l_ar_run_id, @l_ar_run_date, 'FUNDINGS',
        	--f.ProjID, 
        	f.TaskRef as PM_TASK_REFERENCE, 
        	f.AgreementNum as AGREEMENT_NUMBER, 
        	f.AgreementRef as PM_AGREEMENT_REFERENCE, 
        	f.CostAmount as ALLOCATED_AMOUNT, 
        	f.BatchName as BATCH_NAME, 
        	f.Version as RECORD_VERSION,
        	'CDMS' as PM_PRODUCT_CODE ,
        	103,--5000,--f.ORG_ID, 
        	'P' as STATUS_FLAG,
        	f.ProjectReference as PM_PROJECT_REFERENCE,
        	f.ProjectNumber as PROJECT_NUMBER,
        	getdate() as DATE_ALLOCATED ,
        	f.FundingRef as PM_FUNDING_REFERENCE,
        	f.FundingCategory as FUNDING_CATEGORY,
        	f.CustomerNumber as CUSTOMER_NUMBER
        FROM XT_XFACE_FUNDINGS f 
          order by 1,2,5;
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_FUNDINGS_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'FUNDINGS', 'CDALINK.XX_FUNDINGS_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
  INSERT INTO OPENQUERY(CFSPROD, 'SELECT PM_TASK_REFERENCE,
AGREEMENT_NUMBER,
PM_AGREEMENT_REFERENCE,
ALLOCATED_AMOUNT,
BATCH_NAME,
RECORD_VERSION,
PM_PRODUCT_CODE,
ORG_ID,
STATUS_FLAG,
PM_PROJECT_REFERENCE,
PROJECT_NUMBER,
DATE_ALLOCATED,
PM_FUNDING_REFERENCE,
FUNDING_CATEGORY,
CUSTOMER_NUMBER FROM CDALINK.XX_FUNDINGS_XFACE')

SELECT distinct
	--f.ProjID, 
	f.TaskRef as PM_TASK_REFERENCE, 
	f.AgreementNum as AGREEMENT_NUMBER, 
	f.AgreementRef as PM_AGREEMENT_REFERENCE, 
	f.CostAmount as ALLOCATED_AMOUNT, 
	f.BatchName as BATCH_NAME, 
	f.Version as RECORD_VERSION,
	'CDMS' as PM_PRODUCT_CODE ,
	103,--5000,--f.ORG_ID, 
	'P' as STATUS_FLAG,
	f.ProjectReference as PM_PROJECT_REFERENCE,
	f.ProjectNumber as PROJECT_NUMBER,
	getdate() as DATE_ALLOCATED ,
	f.FundingRef as PM_FUNDING_REFERENCE,
	f.FundingCategory as FUNDING_CATEGORY,
	f.CustomerNumber as CUSTOMER_NUMBER
FROM XT_XFACE_FUNDINGS f 
  order by 1,2,5;
-- [AR-BEGIN result of CFS insert FUNDINGS]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

  --INVESTMENT DRIVER

-- [AR-BEGIN archive INVESTMENT DRIVER -> AR_XX_PROJECT_CLASSES_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_PROJECT_CLASSES_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_PROJECT_CLASSES_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             PM_PRODUCT_CODE, PM_PROJECT_REFERENCE, PROJECT_NUMBER, CLASS_CATEGORY, CLASS_CODE, CODE_PERCENTAGE, ORG_ID, BATCH_NAME, STATUS_FLAG, RECORD_VERSION)
        SELECT @l_ar_run_id, @l_ar_run_date, 'INVESTMENT DRIVER',  PM_PRODUCT_CODE,
        	PM_PROJECT_REFERENCE,
        	PROJECT_NUMBER, 
        	CLASS_CATEGORY, 
        	CLASS_CODE, 
        	CODE_PERCENTAGE, 
        	103,--5000,--ORG_ID,
        	BATCH_NAME, 
        	STATUS_FLAG, 
        	VERSION 
        FROM XT_XFACE_PROJECTS_CLASSES
        WHERE CLASS_CATEGORY = 'Investment Driver';
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_PROJECT_CLASSES_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'INVESTMENT DRIVER', 'CDALINK.XX_PROJECT_CLASSES_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
  INSERT INTO OPENQUERY(CFSPROD, 'SELECT PM_PRODUCT_CODE,
PM_PROJECT_REFERENCE,
PROJECT_NUMBER,
CLASS_CATEGORY,
CLASS_CODE,
CODE_PERCENTAGE,
ORG_ID,
BATCH_NAME,
STATUS_FLAG,
RECORD_VERSION FROM CDALINK.XX_PROJECT_CLASSES_XFACE')
SELECT  PM_PRODUCT_CODE,
	PM_PROJECT_REFERENCE,
	PROJECT_NUMBER, 
	CLASS_CATEGORY, 
	CLASS_CODE, 
	CODE_PERCENTAGE, 
	103,--5000,--ORG_ID,
	BATCH_NAME, 
	STATUS_FLAG, 
	VERSION 
FROM XT_XFACE_PROJECTS_CLASSES
WHERE CLASS_CATEGORY = 'Investment Driver';
-- [AR-BEGIN result of CFS insert INVESTMENT DRIVER]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

--BUDGET HEADERS

-- [AR-BEGIN archive BUDGET HEADERS -> AR_XX_BUDGETS_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_BUDGETS_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_BUDGETS_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             BUDGET_TYPE, BATCH_NAME, RECORD_VERSION, PM_PRODUCT_CODE, ORG_ID, STATUS_FLAG, PM_PROJECT_REFERENCE, PROJECT_NUMBER, PM_BUDGET_REFERENCE, BUDGET_ENTRY_METHOD_CODE, RESOURCE_LIST_NAME, BUDGET_TYPE_CODE, BASELINE_FLAG)
         select distinct @l_ar_run_id, @l_ar_run_date, 'BUDGET HEADERS',
        	--b.BudgetReference, 
        	b.BudgetType, 
        	b.BatchName, 
        	b.Version ,
        	b.ProductCode as PM_PRODUCT_CODE ,
        	103,--5000,--b.ORG_ID, 
        	b.StatusFlag as STATUS_FLAG,
        	b.ProjectReference as PM_PROJECT_REFERENCE,
        	b.ProjectNumber as PROJECT_NUMBER,
        	b.BudgetReference as PM_BUDGET_REFERENCE,
        	b.BUDGET_ENTRY_METHOD_CODE,
        	b.RESOURCE_LIST_NAME,
        	b.BudgetTypeCode as BUDGET_TYPE_CODE,
        	b.BASELINE_FLAG

          from   XT_XFACE_TASK_BUDGET_HEADERS b
        --WHERE TaskID in (SELECT TASK_REFERENCE FROM CDMSLIVE..CDALINK.NE_CDA_TASKS) --removed for testing restore for live
          order by 1,2,5;
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_BUDGETS_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'BUDGET HEADERS', 'CDALINK.XX_BUDGETS_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
INSERT INTO OPENQUERY(CFSPROD, 'SELECT BUDGET_TYPE,
BATCH_NAME,
RECORD_VERSION,
PM_PRODUCT_CODE,
ORG_ID,
STATUS_FLAG,
PM_PROJECT_REFERENCE,
PROJECT_NUMBER,
PM_BUDGET_REFERENCE,
BUDGET_ENTRY_METHOD_CODE,
RESOURCE_LIST_NAME,
BUDGET_TYPE_CODE,
BASELINE_FLAG FROM CDALINK.XX_BUDGETS_XFACE')
 select distinct
	--b.BudgetReference, 
	b.BudgetType, 
	b.BatchName, 
	b.Version ,
	b.ProductCode as PM_PRODUCT_CODE ,
	103,--5000,--b.ORG_ID, 
	b.StatusFlag as STATUS_FLAG,
	b.ProjectReference as PM_PROJECT_REFERENCE,
	b.ProjectNumber as PROJECT_NUMBER,
	b.BudgetReference as PM_BUDGET_REFERENCE,
	b.BUDGET_ENTRY_METHOD_CODE,
	b.RESOURCE_LIST_NAME,
	b.BudgetTypeCode as BUDGET_TYPE_CODE,
	b.BASELINE_FLAG

  from   XT_XFACE_TASK_BUDGET_HEADERS b
--WHERE TaskID in (SELECT TASK_REFERENCE FROM CDMSLIVE..CDALINK.NE_CDA_TASKS) --removed for testing restore for live
  order by 1,2,5;
-- [AR-BEGIN result of CFS insert BUDGET HEADERS]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]

  --PRICEBOOKS
  
-- [AR-BEGIN archive PRICEBOOKS -> AR_XX_PROJECT_CLASSES_XFACE]
SET NOCOUNT ON;
SELECT @l_ar_rows = NULL, @l_ar_msg = NULL, @l_ar_log_id = NULL;
IF OBJECT_ID(N'dbo.AR_XX_PROJECT_CLASSES_XFACE', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_XX_PROJECT_CLASSES_XFACE
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION,
             PM_PRODUCT_CODE, PM_PROJECT_REFERENCE, PROJECT_NUMBER, CLASS_CATEGORY, CLASS_CODE, ORG_ID, BATCH_NAME, STATUS_FLAG, RECORD_VERSION)
        SELECT @l_ar_run_id, @l_ar_run_date, 'PRICEBOOKS',  PM_PRODUCT_CODE,
        	PM_PROJECT_REFERENCE,
        	PROJECT_NUMBER, 
        	CLASS_CATEGORY, 
        	CLASS_CODE, 
        	103,--5000,--ORG_ID,
        	BATCH_NAME, 
        	STATUS_FLAG, 
        	VERSION 
        FROM XT_XFACE_PROJECTS_CLASSES
        WHERE CLASS_CATEGORY = 'Price Book';
        SET @l_ar_rows = @@ROWCOUNT;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = LEFT(CONCAT('Archive failed ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()), 2000);
    END CATCH
END
ELSE
    SET @l_ar_msg = N'Archive table dbo.AR_XX_PROJECT_CLASSES_XFACE does not exist';
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NOT NULL
BEGIN
    BEGIN TRY
        INSERT INTO dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
            (AR_RUN_ID, AR_RUN_DATE, AR_SECTION, CFS_TABLE, ARCHIVED_ROWS, ARCHIVE_ERROR, CFS_STATUS, STARTED_ON)
        VALUES (@l_ar_run_id, @l_ar_run_date, 'PRICEBOOKS', 'CDALINK.XX_PROJECT_CLASSES_XFACE', @l_ar_rows, @l_ar_msg, 'PENDING', GETDATE());
        SET @l_ar_log_id = SCOPE_IDENTITY();
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
  INSERT INTO OPENQUERY(CFSPROD, 'SELECT PM_PRODUCT_CODE,
PM_PROJECT_REFERENCE,
PROJECT_NUMBER, 
CLASS_CATEGORY, 
CLASS_CODE, 
ORG_ID,
BATCH_NAME, 
STATUS_FLAG, 
RECORD_VERSION FROM CDALINK.XX_PROJECT_CLASSES_XFACE
')
SELECT  PM_PRODUCT_CODE,
	PM_PROJECT_REFERENCE,
	PROJECT_NUMBER, 
	CLASS_CATEGORY, 
	CLASS_CODE, 
	103,--5000,--ORG_ID,
	BATCH_NAME, 
	STATUS_FLAG, 
	VERSION 
FROM XT_XFACE_PROJECTS_CLASSES
WHERE CLASS_CATEGORY = 'Price Book';
-- [AR-BEGIN result of CFS insert PRICEBOOKS]
SELECT @l_ar_cfs_rows = @@ROWCOUNT, @l_ar_cfs_err = @@ERROR;
SET NOCOUNT ON;
IF @l_ar_log_id IS NOT NULL
BEGIN
    BEGIN TRY
        UPDATE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG
           SET CFS_STATUS  = CASE WHEN @l_ar_cfs_err = 0 THEN 'SENT' ELSE 'FAILED' END,
               CFS_ROWS    = @l_ar_cfs_rows,
               CFS_ERROR   = NULLIF(@l_ar_cfs_err, 0),
               FINISHED_ON = GETDATE()
         WHERE LOG_ID = @l_ar_log_id;
    END TRY
    BEGIN CATCH
        SET @l_ar_log_id = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]


-- [AR-BEGIN purge archive rows older than 4 months]
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.SP_UKD_PROJECT_TRANSFER_ARCHIVE_PURGE', N'P') IS NOT NULL
BEGIN
    BEGIN TRY
        EXEC dbo.SP_UKD_PROJECT_TRANSFER_ARCHIVE_PURGE @p_months = 4;
    END TRY
    BEGIN CATCH
        SET @l_ar_msg = NULL;
    END CATCH
END
IF @l_ar_nocount = 0 SET NOCOUNT OFF;
-- [AR-END]
END 



GO
