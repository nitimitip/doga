/******************************************************************************
  BUG FIX BF03 - PENDING VALIDATION - DO NOT DEPLOY UNTESTED
  Procedure : [dbo].[USP_INSERTDOCUMENT]
  Base      : QPID_SP/USP_INSERTDOCUMENT.sql (production original)
  Fix       : BF03 (2026-10-21)
  Generated : bugfix/tools/gen_bugfix.py (inverse transform = base, checked)
  Depends on: optimization/table_index/08_BT_ACT_DOCUMENTS_CDMSRef.sql
              (phase 1, already on UAT) - THAT index is the fix for the
              reported symptom; this procedure change is the integrity part.

  WHY (BF03, user report 2026-10-21: a document is not saved on the first
  attempt; the retry works). Cause SUSPECTED, not proven:
    The 'ACT' (upload) branch first runs COUNT(LettersID) on
    BT_ACT_DOCUMENTS WHERE CDMSRef = ... AND two varchar(max) columns. In
    production there is no index on CDMSRef (Batch 03), so every upload
    scans the whole table (2,938,603 rows, ~889 MB). Cold cache, or a
    concurrent writer's row lock (READ COMMITTED), can push the first call
    past the application command timeout; the retry finds the pages in
    memory and succeeds. The branch has no transaction: a timeout between
    the document INSERT and the audit INSERT leaves a document without
    its audit row, and the retry then skips the save (@countfile = 1).
    Confirm with bf03_validation BF03.2 / BF03.3 and the application's
    error text ('Timeout expired').

  WHAT CHANGED (and nothing else):
    1. 'ACT' branch: SET XACT_ABORT ON; BEGIN TRAN ... COMMIT TRAN around
       the COUNT and the two INSERTs. A failure or client timeout now
       leaves nothing behind, and the retry saves both rows.
    2. CREATE -> ALTER.
  SET XACT_ABORT ON lasts until the procedure returns. The other branches
  (AUD, RENAME, REFOL, DELFOL, DELFILE, COPYFOL, COPYFILE, MOVEFILE,
  MOVEFOL, DATAMOD, ENQCOPY) are byte for byte unchanged.

  BEHAVIOUR: a successful upload inserts the same two rows with the same
  values. On an error the call now fails as a whole: no document row and
  no audit row (before: the document row could stay without an audit row).

  UNCHANGED (inherited, NOT fixed): COUNT-then-INSERT is not race-proof (a
  double click can insert two rows; a lock hint needs index 08 first);
  the same no-transaction pattern in COPYFILE / MOVEFILE / RENAME.

  VALIDATION: bugfix/validation/bf03_validation.sql
  ROLLBACK  : bugfix/rollback/USP_INSERTDOCUMENT_ORIGINAL.sql
******************************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_INSERTDOCUMENT]
(
	 @str_UplodedLetters varchar(500),
	 @str_FilePath varchar(Max),
	 @str_UplodedBy varchar(200),
	 @str_cdmsRef varchar(100),
	 @str_FileName varchar(Max),
	 @str_DBOP varchar(10),
	 @i_LetrID int,
	 @i_fileVersion int,
	 @Doc_Type varchar(50)='DEFAULT'
 )
AS 

	BEGIN
	DECLARE @i_IsDeleted VARCHAR(1) ='N';
	DECLARE @i_LetterID INT=0;
	DECLARE @countfile int ;
	DECLARE @str_LetterVersion VARCHAR(10)='1';
			IF(@str_DBOP='ACT')
			BEGIN
			--BF03: the document row and its audit row are saved together. XACT_ABORT ON
			--rolls the transaction back if the call fails or the client times out.
			SET XACT_ABORT ON;
			BEGIN TRAN
			select @countfile=count(LettersID) from BT_ACT_DOCUMENTS where CDMSRef=@str_cdmsRef
			 and Letters_Name=@str_FileName and Letters_Path=@str_FilePath and Deleted='N'
			  IF @countfile = 0
			  BEGIN
				INSERT INTO BT_ACT_DOCUMENTS(
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Updated_By,
							Updated_Date,
							Doc_Type,
							ENQNUM)
				VALUES(
							@str_FileName,
							@str_FilePath,
							@str_UplodedBy,
							getdate(),
							@i_IsDeleted,
							@str_cdmsRef,
							@str_UplodedLetters,
							@str_UplodedBy,
							Getdate(),
							@Doc_Type,
							@str_cdmsRef)

				SET @i_LetterID= SCOPE_IDENTITY();

				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date)
				VALUES(@i_LetterID,
							@str_FileName,
							@str_FilePath,
							@str_UplodedBy,
							getdate(),
							@i_IsDeleted,
							@str_cdmsRef,
							'File Uploaded',
							@str_LetterVersion,
							@str_UplodedBy,
							Getdate())
			  END
			COMMIT TRAN
			END

			ELSE IF(@str_DBOP='AUD')
			BEGIN
				UPDATE BT_ACT_DOCUMENTS 
					SET Letters_Name=@str_FileName, 
						Letters_Path=@str_FilePath,
						--Created_By= @str_UplodedBy,
						--[Timestamp]=Getdate(),
						Deleted= @i_IsDeleted,
						CDMSRef=@str_cdmsRef,
						Comments=@str_UplodedLetters,
						Updated_By=@str_UplodedBy,
						Updated_Date=Getdate()
				WHERE LettersID=@i_LetrID
				
				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date
				)
				VALUES(
							@i_LetrID,
							@str_FileName,
							@str_FilePath,
							@str_UplodedBy,
							getdate(),
							@i_IsDeleted,
							@str_cdmsRef,
							@str_UplodedLetters,
							@i_fileVersion,
							@str_UplodedBy,
							Getdate())
			END

			ELSE IF(@str_DBOP='RENAME')
			BEGIN
			select @countfile=count(LettersID) from BT_ACT_DOCUMENTS where CDMSRef=@str_cdmsRef
			 and Letters_Name=@str_UplodedLetters and Letters_Path=@str_FilePath and Deleted='N'
			  IF @countfile = 0
			  BEGIN
				UPDATE BT_ACT_DOCUMENTS 
					SET Letters_Name=@str_UplodedLetters, 
						--Letters_Path=@str_FilePath,
						--Comments='File Rename from: '+@str_FileName + ' to: '+ @str_UplodedLetters,
						Updated_By=@str_UplodedBy,
						Updated_Date=Getdate()
				WHERE CDMSRef=@str_cdmsRef and Letters_Name=@str_FileName  and Letters_Path=@str_FilePath  and Deleted='N'

				--update BT_ALL_NOTE set
				--Note_Text='Document saved as: '+@str_FilePath+@str_UplodedLetters,
				--Note_DateUpdated=getdate(),
				--Note_Updatedby=@str_UplodedBy
				--where Note_Text='Document saved as: '+@str_FilePath+ @str_FileName and Note_ParentID=(select AE_AEID from BT_ENQUIRY_MASTER where ae_internalref=@str_cdmsRef)

				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date
				)
				VALUES(
							(select max(lettersid) from BT_ACT_DOCUMENTS where CDMSRef=@str_cdmsRef and Letters_Name=@str_UplodedLetters and Letters_Path=@str_FilePath and Deleted='N' ),
							@str_UplodedLetters,
							@str_FilePath,
							@str_UplodedBy,
							getdate(),
							@i_IsDeleted,
							@str_cdmsRef,
							'File Renamed',-- from: '+@str_FileName + ' to: '+ @str_UplodedLetters,
							(select max(Letter_Version)+1 from BT_Audit_Documents where LettersID=(select max(lettersid) from BT_ACT_DOCUMENTS where CDMSRef=@str_cdmsRef and Letters_Name=@str_FileName and Letters_Path=@str_FilePath and Deleted='N')),
							@str_UplodedBy,
							Getdate())
			  END
			END

			ELSE IF(@str_DBOP='REFOL')
			BEGIN
			select @countfile=count(LettersID) from BT_ACT_DOCUMENTS where CDMSRef=@str_cdmsRef
			 and Letters_Path like @str_FilePath+@str_UplodedLetters+'%'  and Deleted='N'
			  IF @countfile = 0
				UPDATE BT_ACT_DOCUMENTS 
					SET --Letters_Name=@str_UplodedLetters, 
						Letters_Path=Replace(Letters_Path,@str_FileName,@str_UplodedLetters),
				       --Comments='Folder Rename from: '+ @str_FileName + ' to: '+ @str_UplodedLetters,
						Updated_By=@str_UplodedBy,
						Updated_Date=Getdate()
				WHERE CDMSRef=@str_cdmsRef and Letters_Path like @str_FilePath+@str_FileName+'%'  and Deleted='N'

				--update BT_ALL_NOTE set
				--Note_Text=Replace(Note_Text,@str_FileName,@str_UplodedLetters),
				--Note_DateUpdated=getdate(),
				--Note_Updatedby=@str_UplodedBy
				--where Note_Text like 'Document saved as: '+@str_FilePath+'%' and Note_ParentID=(select AE_AEID from BT_ENQUIRY_MASTER where ae_internalref=@str_cdmsRef)

				--INSERT INTO BT_Audit_Documents(
				--			LettersID,
				--			Letters_Name,
				--			Letters_Path,
				--			Created_By,
				--			[Timestamp],
				--			Deleted,
				--			CDMSRef,
				--			Comments,
				--			Letter_Version,
				--			Updated_By,
				--			Updated_Date
				--)
				--VALUES(
				--			(select max(lettersid) from BT_ACT_DOCUMENTS where CDMSRef=@str_cdmsRef  and Letters_Path like @str_FileName+'%'  and Deleted='N'),
				--			@str_FileName,
				--			@str_FilePath,
				--			@str_UplodedBy,
				--			getdate(),
				--			@i_IsDeleted,
				--			@str_cdmsRef,
				--			'Folder Rename from: '+@str_FileName + ' to: '+ @str_UplodedLetters,
				--			@i_fileVersion,
				--			@str_UplodedBy,
				--			Getdate())
			END

			ELSE IF(@str_DBOP='DELFOL')
			BEGIN
				UPDATE BT_ACT_DOCUMENTS 
					SET Deleted='Y',
						Comments=CONCAT(@str_UplodedLetters, ' by ',(select USER_FIRSTNAME+ ' '+USER_LASTNAME from MT_USERS where int_usr_Id=@str_UplodedBy)),
						Updated_By=@str_UplodedBy,
						Updated_Date=Getdate()
				WHERE CDMSRef=@str_cdmsRef and Letters_Path like @str_FilePath+'%' and Deleted='N'	
			END

			ELSE IF(@str_DBOP='DELFILE')
			BEGIN
				UPDATE BT_ACT_DOCUMENTS 
					SET Deleted='Y',
						Comments=CONCAT(@str_UplodedLetters, ' by ',(select USER_FIRSTNAME+ ' '+USER_LASTNAME from MT_USERS where int_usr_Id=@str_UplodedBy)),
						Updated_By=@str_UplodedBy,
						Updated_Date=Getdate()
				WHERE CDMSRef=@str_cdmsRef and Letters_Name=@str_FileName and Letters_Path = @str_FilePath  and Deleted='N'
            END

			ELSE IF(@str_DBOP='COPYFOL')
			BEGIN

			      
			DECLARE @tb AS TABLE (ID int)		
	INSERT INTO  @tb select LettersID from BT_ACT_DOCUMENTS   
	where Letters_Path like @str_FileName+'%' and CDMSREF=@str_cdmsRef	 and Deleted='N'		
	
				INSERT INTO BT_ACT_DOCUMENTS(
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
						--	Comments,
							Updated_By,
							Updated_Date,
							Doc_Type,
							ENQNUM)
				Select 
							Letters_Name,
							REPLACE(Letters_Path,@str_FileName,@str_FilePath),
							@str_UplodedBy,
							getdate(),
							'N',
							@str_cdmsRef,
						--	@str_UplodedLetters,
							@str_UplodedBy,
							Getdate(),
							@Doc_Type,
							@str_cdmsRef
							FROM BT_ACT_DOCUMENTS
							where LettersID in (SELECT ID from @tb)		

				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date)
							Select 
							d.LettersID,
							d.Letters_Name,
							REPLACE(d.Letters_Path,@str_FileName,@str_FilePath),
							@str_UplodedBy,
							getdate(),
							'N',
							@str_cdmsRef,
							'Folder Copied',--@str_UplodedLetters,
							(select max(ad.Letter_Version)+1 from BT_Audit_Documents ad where ad.LettersID=d.LettersID),
							@str_UplodedBy,
							Getdate()
							FROM BT_ACT_DOCUMENTS  d
							where d.LettersID in (SELECT ID from @tb)	

				
			END

			ELSE IF(@str_DBOP='COPYFILE')
			BEGIN
			select @countfile=count(LettersID) from BT_ACT_DOCUMENTS where CDMSRef=@str_cdmsRef
			 and Letters_Name=@str_FileName and Letters_Path=@str_FilePath and Deleted='N'
			  IF @countfile = 0
			  BEGIN
				INSERT INTO BT_ACT_DOCUMENTS(
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							--Comments,
							Updated_By,
							Updated_Date,
							Doc_Type,
							ENQNUM)
				VALUES(
							@str_FileName,
							@str_FilePath,
							@str_UplodedBy,
							getdate(),
							@i_IsDeleted,
							@str_cdmsRef,
							--@str_UplodedLetters,
							@str_UplodedBy,
							Getdate(),
							@Doc_Type,
							@str_cdmsRef)

				SET @i_LetterID= SCOPE_IDENTITY();

				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date)
				VALUES(@i_LetterID,
							@str_FileName,
							@str_FilePath,
							@str_UplodedBy,
							getdate(),
							@i_IsDeleted,
							@str_cdmsRef,
							'File Copied',
							@str_LetterVersion,
							@str_UplodedBy,
							Getdate())
			  END
			END

			ELSE IF(@str_DBOP='MOVEFILE')
			BEGIN

			DECLARE @vLetterId int;
			SELECT @vLetterId = LettersID from BT_ACT_DOCUMENTS WHERE CDMSRef=@str_cdmsRef 
			and Letters_Name=@str_FileName and Letters_Path=@str_FilePath

				UPDATE BT_ACT_DOCUMENTS 
					SET Letters_Path=@str_UplodedLetters,
						--Comments='File Moved from: ' + @str_FilePath,
						Updated_By=@str_UplodedBy,
						Updated_Date=Getdate()
				WHERE CDMSRef=@str_cdmsRef and Letters_Name=@str_FileName and Letters_Path=@str_FilePath  and Deleted='N'



				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date)
				VALUES( @vLetterId ,
							@str_FileName,
							@str_UplodedLetters,
							@str_UplodedBy,
							getdate(),
							'N',
							@str_cdmsRef,
							'File Moved',--'File Moved from : ' + @str_FilePath,
							(select max(Letter_Version)+1 from BT_Audit_Documents where LettersId=@vLetterId),
							@str_UplodedBy,
							Getdate())
			END

			ELSE IF(@str_DBOP='MOVEFOL')
			BEGIN
			      
			DECLARE @tb1 AS TABLE (ID int)
					
			INSERT INTO  @tb1 select LettersID from BT_ACT_DOCUMENTS   
			where Letters_Path like @str_FileName+'%' and CDMSREF=@str_cdmsRef	 and Deleted='N'		

				UPDATE BT_ACT_DOCUMENTS 
					SET Letters_Path=REPLACE(Letters_Path,@str_FileName,@str_FilePath),
						--Comments=@str_UplodedLetters,
						Updated_By=@str_UplodedBy,
						Updated_Date=Getdate()
				WHERE CDMSRef=@str_cdmsRef and LettersID in (select ID from @tb1)


				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date)
							Select 
							d.LettersID,
							d.Letters_Name,
							REPLACE(d.Letters_Path,@str_FileName,@str_FilePath),
							@str_UplodedBy,
							getdate(),
							'N',
							@str_cdmsRef,
							'Folder Moved',--@str_UplodedLetters,
							(select max(ad.Letter_Version)+1 from BT_Audit_Documents ad where ad.LettersID=d.LettersID),
							--@i_fileVersion,
							@str_UplodedBy,
							Getdate()
							FROM BT_ACT_DOCUMENTS d
							where d.LettersID in (SELECT ID from @tb1)	

				
			END

			ELSE IF(@str_DBOP='DATAMOD')
			BEGIN
				UPDATE BT_ACT_DOCUMENTS 
					SET --Comments=@str_UplodedLetters,
						Updated_By=@str_UplodedBy,
						Updated_Date=Getdate()
				WHERE CDMSRef=@str_cdmsRef and Letters_Name=@str_FileName  and CONCAT(Letters_Path,@str_FileName)=@str_FilePath and Deleted='N'

				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date
				)
				VALUES(
							(select max(lettersid) from BT_ACT_DOCUMENTS WHERE CDMSRef=@str_cdmsRef and Letters_Name=@str_FileName  and CONCAT(Letters_Path,@str_FileName)=@str_FilePath and Deleted='N' ),
							@str_FileName,
							@str_FilePath,
							@str_UplodedBy,
							getdate(),
							@i_IsDeleted,
							@str_cdmsRef,
							@str_UplodedLetters,
							(select max(Letter_Version)+1 from BT_Audit_Documents where LettersID=(select max(lettersid) from BT_ACT_DOCUMENTS WHERE CDMSRef=@str_cdmsRef and Letters_Name=@str_FileName  and CONCAT(Letters_Path,@str_FileName)=@str_FilePath and Deleted='N')),
							@str_UplodedBy,
							Getdate())
			END

			ELSE IF(@str_DBOP='ENQCOPY')
			BEGIN
				INSERT INTO BT_ACT_DOCUMENTS(
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Updated_By,
							Updated_Date,
							Doc_Type,
							ENQNUM)
				SELECT 
							Letters_Name,
							--REPLACE(REPLACE(Letters_Path,@str_UplodedLetters,@str_cdmsRef+'\'+@str_UplodedLetters),'\\sv300607\D$\QPID\Documents\','\\Sv300608\C$\Documents_Letters\'),
							REPLACE(Letters_Path,@str_UplodedLetters,@str_cdmsRef+'\'+@str_UplodedLetters),
							@str_UplodedBy,
							getdate(),
							'N',
							@str_cdmsRef,
							'Folder\Files copied from ENQ - '+@str_UplodedLetters,
							@str_UplodedBy,
							Getdate(),
							Doc_Type,
							@str_cdmsRef
							
				FROM BT_ACT_DOCUMENTS where CDMSRef=@str_UplodedLetters and Deleted='N'

			

				INSERT INTO BT_Audit_Documents(
							LettersID,
							Letters_Name,
							Letters_Path,
							Created_By,
							[Timestamp],
							Deleted,
							CDMSRef,
							Comments,
							Letter_Version,
							Updated_By,
							Updated_Date)
				SELECT
							LettersId, 
							Letters_Name,
							Letters_Path,
							@str_UplodedBy,
							getdate(),
							'N',
							@str_cdmsRef,
							'Folder\Files copied from ENQ - '+@str_UplodedLetters,
							1,
							@str_UplodedBy,
							Getdate()
							
				FROM BT_ACT_DOCUMENTS where CDMSRef=@str_cdmsRef and Deleted='N' and Comments = 'Folder\Files copied from ENQ - '+@str_UplodedLetters
				
			END
	END

GO
