/******************************************************************************
  BUG FIX BF02 - PENDING VALIDATION - DO NOT DEPLOY UNTESTED
  Procedure : [dbo].[sp_ACT_addHistory]
  Base      : QPID_SP/sp_ACT_addHistory.sql (production original)
  Fix       : BF02 (2026-10-21)
  Generated : bugfix/tools/gen_bugfix.py (inverse transform = base, checked)

  WHY (BF02, user report 2026-10-21: records missing in BT_ACT_HIST):
    HIST_HISTID is the clustered PK (PK_BT_ACT_HIST_1) and NOT an identity.
    Every writer takes MAX(HIST_HISTID)+1 with an ordinary read. Two
    concurrent writers read the same MAX; the second INSERT fails with
    2627 (duplicate key) and that history row is lost. The ~30
    sp_ACT_addHIST_* wrappers have no error handling, and
    sp_ACT_PLABulkBillingQuery_UPDATE swallows the error in its CATCH.

  THE FIX (same as Batch 34, PLA_addEnquiry): WITH (UPDLOCK, HOLDLOCK) on
  the MAX() read. U is incompatible with U, so a second writer waits at its
  MAX() read until the first commits, then reads the new MAX (no 2627, no
  conversion deadlock). Outside a transaction the lock lasts for the one
  INSERT statement only. Ids stay gap-free and in the same sequence.
  Writers without the hint can still collide: deploy all five BF02
  procedures together and check other writers (bf02_validation BF02.2).

  WHAT CHANGED (and nothing else):
    1. Line 88: (Select max(HIST_HISTID)+1 from BT_ACT_HIST)
       -> (Select max(HIST_HISTID)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK))
    2. CREATE -> ALTER.

  VALIDATION: bugfix/validation/bf02_validation.sql
  ROLLBACK  : bugfix/rollback/sp_ACT_addHistory_ORIGINAL.sql
******************************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
----------------------------------------------------------------
-- Added By	  :	Anirban Dhara
-- Added date : 09-May-2023
-- Description:	New procedure created name as sp_ACT_addHistory
----------------------------------------------------------------


ALTER   PROCEDURE [dbo].[sp_ACT_addHistory] 

	@iHIST_AEID INT,
	@iHIST_internalRef VARCHAR(50) = NULL,
	@iHIST_metaModelType2 INT = NULL,
	@iHIST_fieldType VARCHAR(50),
	@iHIST_fieldName VARCHAR(50),
	@iHIST_tableName VARCHAR(50),
	@iHIST_columnName VARCHAR(50),
	@iHIST_valueInt INT,
	@iHIST_valueChar VARCHAR(50),
	@iHIST_descr VARCHAR(150),
	@iHIST_dateTime SMALLDATETIME,
	@iHIST_createdBy INT,
	@iHIST_createdByDescr VARCHAR(200),
	@iHIST_foreignKeyId int = null,
	@HIST_dateCreated SMALLDATETIME = NULL
	
AS

BEGIN
DECLARE @iHIST_lastChange INT
DECLARE @iHist_HISTID INT

DECLARE @HIST_dateCreatedCheck SMALLDATETIME

   -- IF @HIST_dateCreated IS NULL THEN GETDATE() ELSE DATE PASSED THROUGH SCALER PARAMETER
      SET @HIST_dateCreatedCheck = ISNULL(@HIST_dateCreated, GETDATE()) 

IF @iHIST_internalRef IS NULL OR @iHIST_metaModelType2 IS NULL
BEGIN
	SELECT 
		@iHIST_internalRef = CASE WHEN @iHIST_internalRef IS NOT NULL 
								THEN @iHIST_internalRef 
								ELSE AE_internalRef END,
		@iHIST_metaModelType2 = CASE WHEN @iHIST_metaModelType2 IS NOT NULL 
								THEN @iHIST_metaModelType2 
								ELSE AE_metaModelType2 END
	FROM dbo.BT_PROJ_U_HEADER 
	WHERE AE_AEID = @iHIST_AEID
END

if @iHIST_tableName = 'BT_ACT_STANDARDS' AND (@iHIST_columnName = 'sta_target_date' OR @iHIST_columnName = 'sta_achieved_date') AND @iHIST_dateTime = '1900-01-01 00:00:00' --if target date is passed as 1900-01-01 00:00:00 then no target date has been set
BEGIN 
	set @iHIST_dateTime = null
END

SELECT TOP 1 @iHIST_lastChange = HIST_HISTID
FROM BT_ACT_HIST
WHERE HIST_AEID = @iHIST_AEID
AND HIST_fieldName = @iHIST_fieldName
ORDER BY HIST_dateCreated DESC

	INSERT BT_ACT_HIST(
	HIST_HISTID,
	HIST_AEID,
	HIST_lastChange,
	HIST_internalRef,
	HIST_metaModelType2,
	HIST_fieldType,
	HIST_fieldName,
	HIST_tableName,
	HIST_columnName,
	HIST_valueInt,
	HIST_valueChar,
	HIST_descr,
	HIST_dateTime,
	HIST_dateCreated,
	HIST_createdBy,
	HIST_createdByDescr,
	HIST_foreignKeyId
	)
	VALUES(
	(Select max(HIST_HISTID)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK)),
	@iHIST_AEID,
	@iHIST_lastChange,
	@iHIST_internalRef,
	@iHIST_metaModelType2,
	@iHIST_fieldType,
	@iHIST_fieldName,
	@iHIST_tableName,
	@iHIST_columnName,
	@iHIST_valueInt,
	@iHIST_valueChar,
	@iHIST_descr,
	@iHIST_dateTime,
	@HIST_dateCreatedCheck, --getDate()
	@iHIST_createdBy,
	@iHIST_createdByDescr,
	@iHIST_foreignKeyId
	)
END


GO
