USE [QPID_PROD]
GO

/* Archive objects for SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP2 (2026-11-02).
   Run this BEFORE deploying the changed procedure. Safe to re-run:
   every object is created only if it does not exist.
   One AR_ table per CFS interface table; rows kept 4 months.
   AR_ columns: AR_RUN_ID = one execution of the procedure,
   AR_RUN_DATE = when that execution started, AR_SECTION = SP section. */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- AR_XX_PROJECTS_XFACE  <- copy of rows sent to CDALINK.XX_PROJECTS_XFACE (sections: PROJECTS)
IF OBJECT_ID(N'dbo.AR_XX_PROJECTS_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_PROJECTS_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        PM_PROJECT_REFERENCE         nvarchar(15) NULL,
        PROJECT_NUMBER               nvarchar(15) NULL,
        PROJECT_NAME                 nvarchar(50) NULL,
        DESCRIPTION                  nvarchar(200) NULL,
        START_DATE                   varchar(30) NULL,
        COMPLETION_DATE              varchar(30) NULL,
        CUSTOMER_NUMBER              nvarchar(60) NULL,
        COPY_TEMPLATE_TASKS_FLAG     varchar(1) NULL,
        TEMPLATE_NUMBER              varchar(30) NULL,
        PROJECT_ORGANIZATION         nvarchar(60) NULL,
        RECORD_VERSION               int NULL,
        BATCH_NAME                   varchar(30) NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        ORG_ID                       int NULL,
        STATUS_FLAG                  varchar(1) NULL,
        PROJECT_RELATIONSHIP_CODE    varchar(30) NULL,
        CONTRIBUTION_PERCENT         numeric(18,4) NULL,
        DEFAULT_TOP_TASK_CUSTOMER    varchar(1) NULL,
        CONSTRAINT PK_AR_XX_PROJECTS_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_PROJECTS_XFACE_RUN_DATE ON dbo.AR_XX_PROJECTS_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_PROJECTS_XFACE_RUN_ID ON dbo.AR_XX_PROJECTS_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_PROJECTS_XFACE_PM_PROJECT_REFERENCE ON dbo.AR_XX_PROJECTS_XFACE (PM_PROJECT_REFERENCE, AR_RUN_DATE);
END
GO

-- AR_XX_TASKS_XFACE  <- copy of rows sent to CDALINK.XX_TASKS_XFACE (sections: TASKS)
IF OBJECT_ID(N'dbo.AR_XX_TASKS_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_TASKS_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        BATCH_NAME                   varchar(30) NULL,
        TASK_NUMBER                  nvarchar(15) NULL,
        PM_TASK_REFERENCE            nvarchar(15) NULL,
        TASK_NAME                    nvarchar(50) NULL,
        TASK_DESCRIPTION             nvarchar(200) NULL,
        TASK_START_DATE              smalldatetime NULL,
        TASK_COMPLETION_DATE         smalldatetime NULL,
        PM_PARENT_TASK_REFERENCE     nvarchar(15) NULL,
        SERVICE_TYPE_CODE            nvarchar(50) NULL,
        RECORD_VERSION               int NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        ORG_ID                       int NULL,
        STATUS_FLAG                  varchar(1) NULL,
        PM_PROJECT_REFERENCE         nvarchar(15) NULL,
        PROJECT_NUMBER               varchar(60) NULL,
        RECEIVER_TASK                varchar(1) NULL,
        TASK_CUSTOMER                nvarchar(60) NULL,
        CONSTRAINT PK_AR_XX_TASKS_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_TASKS_XFACE_RUN_DATE ON dbo.AR_XX_TASKS_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_TASKS_XFACE_RUN_ID ON dbo.AR_XX_TASKS_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_TASKS_XFACE_PM_PROJECT_REFERENCE ON dbo.AR_XX_TASKS_XFACE (PM_PROJECT_REFERENCE, AR_RUN_DATE);
END
GO

-- AR_XX_KEY_MEMBERS_XFACE  <- copy of rows sent to CDALINK.XX_KEY_MEMBERS_XFACE (sections: KEY MEMBERS)
IF OBJECT_ID(N'dbo.AR_XX_KEY_MEMBERS_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_KEY_MEMBERS_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        BATCH_NAME                   varchar(30) NULL,
        PM_PROJECT_REFERENCE         nvarchar(15) NULL,
        PROJECT_ROLE_TYPE            varchar(60) NULL,
        EMPLOYEE_NUMBER              varchar(200) NULL,
        START_DATE                   varchar(30) NULL,
        RECORD_VERSION               int NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        ORG_ID                       int NULL,
        STATUS_FLAG                  varchar(1) NULL,
        PROJECT_NUMBER               nvarchar(15) NULL,
        CONSTRAINT PK_AR_XX_KEY_MEMBERS_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_KEY_MEMBERS_XFACE_RUN_DATE ON dbo.AR_XX_KEY_MEMBERS_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_KEY_MEMBERS_XFACE_RUN_ID ON dbo.AR_XX_KEY_MEMBERS_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_KEY_MEMBERS_XFACE_PM_PROJECT_REFERENCE ON dbo.AR_XX_KEY_MEMBERS_XFACE (PM_PROJECT_REFERENCE, AR_RUN_DATE);
END
GO

-- AR_XX_CUST_CONTACTS_XFACE  <- copy of rows sent to CDALINK.XX_CUST_CONTACTS_XFACE (sections: BILLING CONTACTS)
IF OBJECT_ID(N'dbo.AR_XX_CUST_CONTACTS_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_CUST_CONTACTS_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        BATCH_NAME                   varchar(30) NULL,
        CUSTOMER_NUMBER              nvarchar(60) NULL,
        BILL_TO_ADDRESS_ID           int NULL,
        SHIP_TO_ADDRESS_ID           int NULL,
        PROJECT_CONTACT_ID           int NULL,
        RECORD_VERSION               int NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        ORG_ID                       int NULL,
        STATUS_FLAG                  varchar(1) NULL,
        PM_PROJECT_REFERENCE         nvarchar(15) NULL,
        PROJECT_NUMBER               nvarchar(15) NULL,
        PROJECT_CONTACT              varchar(100) NULL,
        CONTACT_ROLE                 varchar(30) NULL,
        CONSTRAINT PK_AR_XX_CUST_CONTACTS_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_CUST_CONTACTS_XFACE_RUN_DATE ON dbo.AR_XX_CUST_CONTACTS_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_CUST_CONTACTS_XFACE_RUN_ID ON dbo.AR_XX_CUST_CONTACTS_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_CUST_CONTACTS_XFACE_PM_PROJECT_REFERENCE ON dbo.AR_XX_CUST_CONTACTS_XFACE (PM_PROJECT_REFERENCE, AR_RUN_DATE);
END
GO

-- AR_XX_BUDGET_LINES_XFACE  <- copy of rows sent to CDALINK.XX_BUDGET_LINES_XFACE (sections: BUDGET LINES)
IF OBJECT_ID(N'dbo.AR_XX_BUDGET_LINES_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_BUDGET_LINES_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        PM_BUDGET_REFERENCE          varchar(30) NULL,
        BUDGET_TYPE                  varchar(30) NULL,
        RESOURCE_ALIAS               varchar(50) NULL,
        REVENUE                      numeric(10,2) NULL,
        BATCH_NAME                   varchar(30) NULL,
        RECORD_VERSION               int NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        ORG_ID                       int NULL,
        STATUS_FLAG                  varchar(10) NULL,
        PM_PROJECT_REFERENCE         varchar(25) NULL,
        PROJECT_NUMBER               varchar(25) NULL,
        PM_TASK_REFERENCE            varchar(25) NULL,
        PM_BUDGET_LINE_REFERENCE     varchar(50) NULL,
        BUDGET_TYPE_CODE             varchar(30) NULL,
        BUDGET_START_DATE            smalldatetime NULL,
        RAW_COST                     numeric(18,0) NULL,
        BURDENED_COST                numeric(18,0) NULL,
        CONSTRAINT PK_AR_XX_BUDGET_LINES_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_BUDGET_LINES_XFACE_RUN_DATE ON dbo.AR_XX_BUDGET_LINES_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_BUDGET_LINES_XFACE_RUN_ID ON dbo.AR_XX_BUDGET_LINES_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_BUDGET_LINES_XFACE_PM_PROJECT_REFERENCE ON dbo.AR_XX_BUDGET_LINES_XFACE (PM_PROJECT_REFERENCE, AR_RUN_DATE);
END
GO

-- AR_XX_AGREEMENTS_XFACE  <- copy of rows sent to CDALINK.XX_AGREEMENTS_XFACE (sections: AGREEMENTS)
IF OBJECT_ID(N'dbo.AR_XX_AGREEMENTS_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_AGREEMENTS_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        AGREEMENT_NUMBER             varchar(50) NULL,
        PM_AGREEMENT_REFERENCE       varchar(50) NULL,
        BATCH_NAME                   varchar(30) NULL,
        RECORD_VERSION               int NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        ORG_ID                       int NULL,
        STATUS_FLAG                  varchar(30) NULL,
        AGREEMENT_TYPE               varchar(30) NULL,
        REVENUE_LIMIT_FLAG           varchar(1) NULL,
        AMOUNT                       numeric(10,2) NULL,
        CUSTOMER_NUMBER              varchar(30) NULL,
        TERM_NAME                    varchar(15) NULL,
        CONSTRAINT PK_AR_XX_AGREEMENTS_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_AGREEMENTS_XFACE_RUN_DATE ON dbo.AR_XX_AGREEMENTS_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_AGREEMENTS_XFACE_RUN_ID ON dbo.AR_XX_AGREEMENTS_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_AGREEMENTS_XFACE_AGREEMENT_NUMBER ON dbo.AR_XX_AGREEMENTS_XFACE (AGREEMENT_NUMBER, AR_RUN_DATE);
END
GO

-- AR_XX_FUNDINGS_XFACE  <- copy of rows sent to CDALINK.XX_FUNDINGS_XFACE (sections: FUNDINGS)
IF OBJECT_ID(N'dbo.AR_XX_FUNDINGS_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_FUNDINGS_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        PM_TASK_REFERENCE            varchar(50) NULL,
        AGREEMENT_NUMBER             varchar(50) NULL,
        PM_AGREEMENT_REFERENCE       varchar(50) NULL,
        ALLOCATED_AMOUNT             numeric(10,2) NULL,
        BATCH_NAME                   varchar(30) NULL,
        RECORD_VERSION               int NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        ORG_ID                       int NULL,
        STATUS_FLAG                  varchar(1) NULL,
        PM_PROJECT_REFERENCE         varchar(25) NULL,
        PROJECT_NUMBER               varchar(25) NULL,
        DATE_ALLOCATED               datetime NULL,
        PM_FUNDING_REFERENCE         varchar(50) NULL,
        FUNDING_CATEGORY             varchar(50) NULL,
        CUSTOMER_NUMBER              varchar(30) NULL,
        CONSTRAINT PK_AR_XX_FUNDINGS_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_FUNDINGS_XFACE_RUN_DATE ON dbo.AR_XX_FUNDINGS_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_FUNDINGS_XFACE_RUN_ID ON dbo.AR_XX_FUNDINGS_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_FUNDINGS_XFACE_PM_PROJECT_REFERENCE ON dbo.AR_XX_FUNDINGS_XFACE (PM_PROJECT_REFERENCE, AR_RUN_DATE);
END
GO

-- AR_XX_PROJECT_CLASSES_XFACE  <- copy of rows sent to CDALINK.XX_PROJECT_CLASSES_XFACE (sections: INVESTMENT DRIVER, PRICEBOOKS)
IF OBJECT_ID(N'dbo.AR_XX_PROJECT_CLASSES_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_PROJECT_CLASSES_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        PM_PROJECT_REFERENCE         nvarchar(15) NULL,
        PROJECT_NUMBER               nvarchar(15) NULL,
        CLASS_CATEGORY               varchar(50) NULL,
        CLASS_CODE                   varchar(50) NULL,
        CODE_PERCENTAGE              int NULL,
        ORG_ID                       int NULL,
        BATCH_NAME                   varchar(30) NULL,
        STATUS_FLAG                  varchar(1) NULL,
        RECORD_VERSION               int NULL,
        CONSTRAINT PK_AR_XX_PROJECT_CLASSES_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_PROJECT_CLASSES_XFACE_RUN_DATE ON dbo.AR_XX_PROJECT_CLASSES_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_PROJECT_CLASSES_XFACE_RUN_ID ON dbo.AR_XX_PROJECT_CLASSES_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_PROJECT_CLASSES_XFACE_PM_PROJECT_REFERENCE ON dbo.AR_XX_PROJECT_CLASSES_XFACE (PM_PROJECT_REFERENCE, AR_RUN_DATE);
END
GO

-- AR_XX_BUDGETS_XFACE  <- copy of rows sent to CDALINK.XX_BUDGETS_XFACE (sections: BUDGET HEADERS)
IF OBJECT_ID(N'dbo.AR_XX_BUDGETS_XFACE', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_XX_BUDGETS_XFACE (
        AR_ID        bigint IDENTITY(1,1) NOT NULL,
        AR_RUN_ID    uniqueidentifier NOT NULL,
        AR_RUN_DATE  datetime NOT NULL,
        AR_SECTION   varchar(30) NOT NULL,
        BUDGET_TYPE                  varchar(30) NULL,
        BATCH_NAME                   varchar(30) NULL,
        RECORD_VERSION               int NULL,
        PM_PRODUCT_CODE              varchar(30) NULL,
        ORG_ID                       int NULL,
        STATUS_FLAG                  varchar(10) NULL,
        PM_PROJECT_REFERENCE         varchar(25) NULL,
        PROJECT_NUMBER               varchar(25) NULL,
        PM_BUDGET_REFERENCE          varchar(30) NULL,
        BUDGET_ENTRY_METHOD_CODE     varchar(30) NULL,
        RESOURCE_LIST_NAME           varchar(30) NULL,
        BUDGET_TYPE_CODE             varchar(30) NULL,
        BASELINE_FLAG                varchar(30) NULL,
        CONSTRAINT PK_AR_XX_BUDGETS_XFACE PRIMARY KEY CLUSTERED (AR_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_XX_BUDGETS_XFACE_RUN_DATE ON dbo.AR_XX_BUDGETS_XFACE (AR_RUN_DATE);
    CREATE NONCLUSTERED INDEX IX_AR_XX_BUDGETS_XFACE_RUN_ID ON dbo.AR_XX_BUDGETS_XFACE (AR_RUN_ID);
    CREATE NONCLUSTERED INDEX IX_AR_XX_BUDGETS_XFACE_PM_PROJECT_REFERENCE ON dbo.AR_XX_BUDGETS_XFACE (PM_PROJECT_REFERENCE, AR_RUN_DATE);
END
GO

-- AR_UKD_PROJECT_TRANSFER_STEP2_LOG  <- one row per section per run
--   CFS_STATUS: PENDING = CFS insert started but never finished (batch aborted),
--               SENT    = linked-server insert returned without error,
--               FAILED  = insert raised an error (CFS_ERROR holds the number).
IF OBJECT_ID(N'dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG (
        LOG_ID         int IDENTITY(1,1) NOT NULL,
        AR_RUN_ID      uniqueidentifier NOT NULL,
        AR_RUN_DATE    datetime NOT NULL,
        AR_SECTION     varchar(30) NOT NULL,
        CFS_TABLE      varchar(60) NOT NULL,
        ARCHIVED_ROWS  int NULL,
        ARCHIVE_ERROR  nvarchar(2000) NULL,
        CFS_STATUS     varchar(10) NOT NULL,
        CFS_ROWS       int NULL,
        CFS_ERROR      int NULL,
        STARTED_ON     datetime NOT NULL,
        FINISHED_ON    datetime NULL,
        CONSTRAINT PK_AR_UKD_PROJECT_TRANSFER_STEP2_LOG PRIMARY KEY CLUSTERED (LOG_ID)
    );
    CREATE NONCLUSTERED INDEX IX_AR_UKD_PROJECT_TRANSFER_STEP2_LOG_RUN_DATE ON dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG (AR_RUN_DATE);
END
GO

-- Purge: deletes archive + log rows older than @p_months (default 4),
-- 5000 rows at a time. Called at the end of SP_UKD_PROJECT_TRANSFER_INTERFACE_STEP2; can also be
-- run on its own (e.g. from a SQL Agent job).
CREATE OR ALTER PROCEDURE dbo.SP_UKD_PROJECT_TRANSFER_ARCHIVE_PURGE
    @p_months int = 4
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @cutoff datetime = DATEADD(MONTH, -@p_months, CAST(CAST(GETDATE() AS date) AS datetime));
    IF @p_months IS NULL OR @p_months < 1 RETURN;
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_PROJECTS_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_TASKS_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_KEY_MEMBERS_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_CUST_CONTACTS_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_BUDGET_LINES_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_AGREEMENTS_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_FUNDINGS_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_PROJECT_CLASSES_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_XX_BUDGETS_XFACE WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM dbo.AR_UKD_PROJECT_TRANSFER_STEP2_LOG WHERE AR_RUN_DATE < @cutoff;
        IF @@ROWCOUNT < 5000 BREAK;
    END
END
GO
