/******************************************************************************
  RECOMMENDED INDEX - NOT EXECUTED - REVIEW AND TEST BEFORE ANY DEPLOYMENT
  Batch V3-03 (2026-11-02) - requisition page SPs
  Table : dbo.MT_EQP_ASSEMBLYCONFIGS  (34,556 rows; clustered
          PK_MT_EQP_ASSEMBLYCONFIGS on Easc_ConfigID, FILLFACTOR 80,
          2.81 MB ~= 360 pages)
  Index : IX_MT_EQP_ASSEMBLYCONFIGS_Easc_ConfigAssID
          ON (Easc_ConfigAssID)
          INCLUDE (Easc_EqpOrAssemblyInd, Easc_ConstituentID,
                   Easc_Quantity, Easc_deleteFlag)

  EVIDENCE (production, before the phase-1/2 deploy; table untouched by it)
    - The clustered PK is the only index: 0 seeks and 168,640 scans in the
      window. Every reader filters on Easc_ConfigAssID (the parent
      assembly), which has no index.
    - SP_GET_AssemblyConfigs (105 plan-cache rows = 714 execs, avg 374.6
      reads, 4.3 s total) = one cursor over Easc_ConfigAssID = @id AND
      Easc_deleteFlag = 'N', recursing per sub-assembly. 360 pages = 96.1%
      of 374.6 (rest = cursor fetches + #t_equips inserts). Called by
      SP_CREATE_REQUISITION_V5 once per assembly line (~24 calls per V5
      call: 714 / 30), i.e. ~9k of V5's reads.
    - SP_GET_REQ_ASSEMBLY_BY_NAMEIDV1 (1,971 x 132 ms, CPU 82 ms, 9,254
      reads; 260 s total = the bigger user-visible cost): two correlated
      COUNT subqueries per assembly on Easc_ConfigAssID = t2.Eass_AssID,
      plus dbo.assemblyHasEquip(Eass_AssID) per row (function source not
      in QPID_SP). NOT closed: how much of 9,254 is this table vs the
      function is unknown -> V3-03.3 measures it.
    - sp_getSubAssemblyEquipmentByAssemblyIDV1 (42 x 159 ms, 11,486
      reads): the same correlated counts per constituent. Not closed.
    - Writers (sp_addAssemblyConfig, addAssemblyConfig, sp_deleteAssembly):
      0 leaf inserts / updates in the window.

  DESIGN
    - Key Easc_ConfigAssID; INCLUDE the four columns the readers filter or
      return (deleteFlag / EqpOrAssemblyInd filters, ConstituentID /
      Quantity outputs), so every reader is a covered seek. ~7 rows per
      assembly (34,556 / 4,928 assemblies).
    - Easc_ConfigAssID is int NOT NULL; all readers compare it with int
      (parameter or MT_EQP_ASSEMBLIES.Eass_AssID int): no conversion.

  SIZE / WRITE OVERHEAD
    - ~34.6k rows x ~35 bytes ~= 1.2 MB. Writes: none in the window.

  OVERLAP CHECK
    - No index on the table has Easc_ConfigAssID in any position.

  CONFIDENCE: high for SP_GET_AssemblyConfigs (96.1%); medium for
    SP_GET_REQ_ASSEMBLY_BY_NAMEIDV1 / sp_getSubAssembly... (not closed).
  CHECK AFTER: V3-03.3 in validation/v3_03_validation.sql.
******************************************************************************/

-- P1. Pre-check (read-only): confirm no equivalent index exists now.
-- SELECT i.name, ic.key_ordinal, c.name AS col, ic.is_included_column
-- FROM sys.indexes i
-- JOIN sys.index_columns ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
-- JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
-- WHERE i.object_id = OBJECT_ID('dbo.MT_EQP_ASSEMBLYCONFIGS')
-- ORDER BY i.name, ic.key_ordinal;

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID('dbo.MT_EQP_ASSEMBLYCONFIGS')
                 AND name = 'IX_MT_EQP_ASSEMBLYCONFIGS_Easc_ConfigAssID')
BEGIN
    -- ONLINE = ON requires Enterprise/Developer/Azure; remove on Standard.
    CREATE NONCLUSTERED INDEX IX_MT_EQP_ASSEMBLYCONFIGS_Easc_ConfigAssID
        ON dbo.MT_EQP_ASSEMBLYCONFIGS (Easc_ConfigAssID)
        INCLUDE (Easc_EqpOrAssemblyInd, Easc_ConstituentID, Easc_Quantity, Easc_deleteFlag)
        WITH (ONLINE = ON, SORT_IN_TEMPDB = ON, FILLFACTOR = 90);
END
GO

/* ROLLBACK
DROP INDEX IX_MT_EQP_ASSEMBLYCONFIGS_Easc_ConfigAssID ON dbo.MT_EQP_ASSEMBLYCONFIGS;
*/
