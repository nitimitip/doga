/******************************************************************************
  V3-03 - OPTIMIZED PROCEDURE - NOT EXECUTED - REVIEW AND TEST BEFORE DEPLOYMENT
  Procedure : [dbo].[SP_CREATE_REQUISITION_V5]  (requisition page:
              pre-authorise; also called by SP_DEL_PLANNED_MATERIAL and
              SP_EDIT_PLANNED_MATERIAL)
  Original  : QPID_SP/SP_CREATE_REQUISITION_V5.sql (not changed in phase 1
              or phase 2; its MT_EQP_REQUESTS / BT_ACT_TIME_UTIL reads were
              covered by indexes 04 + 31)
  Batch     : V3-03 (2026-11-02)
  Generated : optimization_v3/tools/gen_v3_03.py (inverse transform ==
              original; guard == negation of the four branch tests)
  Depends on: nothing. Indexes 57 + 58 (optimization_v3/table_index/) are
              independent and give the read savings; deploy them first.
              Guards G1-G2 REFUSE loudly (error 16 + NOEXEC); the last
              batch prints DEPLOYED / NOT DEPLOYED.

  WHY:
    Production baseline (Index/slowrunningSP.xlsx, before phase 1): 30
    execs, avg 2,776 ms, CPU 1,738 ms, 264,828 reads. Indexes 04 + 31
    (live since the phase-1/2 deploy) cover the BT_ACT_TIME_UTIL lookup
    and the ~14 MT_EQP_REQUESTS reads by Eqpreh_timeUtil_ID; index 57
    covers the MT_EQP_REQUESTLINES delete; index 58 covers
    SP_GET_AssemblyConfigs (one per assembly). What no index can remove:
    every call waits for one OPENQUERY round trip to CFSPROD before the
    pre-authorisation checks, even when an earlier check rejects it.

  WHAT CHANGED (one block):
    The @projId SELECT and the CFSPROD OPENQUERY run only when the call
    reaches the 'Project has not yet been created in CFS' test, i.e. when
    none of the four earlier rejections applies:
        @SENTTOCFS <= 0 AND coalesce(@hasCDAStandingTask,'N') <> 'N'
        AND @allItemAssignedSTKsHaveBeenSentToCFS <> 'N' AND @cnt1 <> 0
    Everything else (checks, history rows, PRINTs, the 3 debug result
    sets, transactions, cursor, error handling) is byte-identical.

  WHY IT IS EQUIVALENT:
    @countproj and @projId / @TSQL / @tbprojcnt are read only by the 5th
    test. The 4 earlier branches RETURN -1 without reading them. The guard
    is their exact complement (all four inputs are non-NULL and final).

  BEHAVIOUR DIFFERENCES (sign-off):
    a. If CFSPROD is unreachable, a call that is rejected by one of the
       first four checks now returns its normal -1 message and history row
       instead of failing on the linked-server error. Calls that reach the
       CFS check fail exactly as before.
    b. None otherwise.

  NOT CHANGED (reported, app team): the @projId TOP 1 has no filter on
    this TUL (checks an arbitrary project); DEL / EDIT_PLANNED_MATERIAL
    call this procedure with the parameters shifted by one; the history
    subqueries fail with error 512 when a TUL has 2+ requisition headers;
    the 3 debug SELECTs (one is a MT_EQP_REQUESTS scan by Eqpreh_AE_AEID)
    still return result sets - removing them needs the app team to confirm
    the .NET caller ignores them. See OPTIMIZATION_SUMMARY_V3.md V3-03.

  EXPECTED: an estimate, not measured: one CFSPROD round trip saved on
    every rejected call (path mix = V3-03.1). Successful calls: unchanged
    by this file (their gain comes from indexes 04 / 31 / 57 / 58).

  ROLLBACK: optimization_v3/rollback/SP_CREATE_REQUISITION_V5_ORIGINAL.sql
******************************************************************************/
-- G1: the live procedure must be the version this file was built from
--     (same text ignoring blanks / tabs / line breaks) and not yet patched.
IF OBJECT_ID('dbo.SP_CREATE_REQUISITION_V5', 'P') IS NULL
   OR OBJECT_DEFINITION(OBJECT_ID('dbo.SP_CREATE_REQUISITION_V5')) LIKE '%QPID_OPT%'
   OR ISNULL(LEN(REPLACE(REPLACE(REPLACE(REPLACE(
          OBJECT_DEFINITION(OBJECT_ID('dbo.SP_CREATE_REQUISITION_V5')),
          ' ', ''), CHAR(9), ''), CHAR(13), ''), CHAR(10), '')), -1) NOT IN (14609, 14608)
--     (14608 = the same text after the rollback file, if the server keeps
--     'ALTER' instead of 'CREATE' in the stored definition.)
BEGIN
    RAISERROR('REFUSED (G1): live SP_CREATE_REQUISITION_V5 is missing, already patched, or differs from QPID_SP (expected 14609 non-blank characters).', 16, 1);
    SET NOEXEC ON;
END
GO
-- G2: the guarded block must still be in the live text.
--     (ISNULL: no VIEW DEFINITION permission = NULL text = refuse.)
IF ISNULL(CHARINDEX('INSERT into @tbprojcnt EXEC (@TSQL)',
             OBJECT_DEFINITION(OBJECT_ID('dbo.SP_CREATE_REQUISITION_V5'))), 0) = 0
   OR ISNULL(CHARINDEX('else IF @countproj=0',
             OBJECT_DEFINITION(OBJECT_ID('dbo.SP_CREATE_REQUISITION_V5'))), 0) = 0
BEGIN
    RAISERROR('REFUSED (G2): the CFSPROD block / @countproj test is not in the live procedure.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[SP_CREATE_REQUISITION_V5] (
@p_TULREF varchar(20),
@p_TaskID int, 
@p_TimeUtilID int,
@userID int, 
@p_ErrorCode int=0 output, 
@p_ErrorMsg varchar(100)=NULL output )

AS
begin 

SELECT @p_TaskID = Tutl_AE_AEID ,@p_TimeUtilID=Tutl_TimeUtil_Id 
FROM BT_ACT_TIME_UTIL WHERE Tutl_internalRef= @p_TULREF 

declare @datecount int
select @datecount =count(distinct Eqpl_PickDate ) from MT_EQP_PLANNEDMATERIALS 
WHERE Eqpl_timeUtil_ID = @p_TimeUtilID
IF @datecount >1
BEGIN
update MT_EQP_PLANNEDMATERIALS set Eqpl_PickDate=(select Eqpl_PickDate from MT_EQP_PLANNEDMATERIALS where Eqpl_EqplID =
(select max(Eqpl_EqplID) from MT_EQP_PLANNEDMATERIALS where Eqpl_timeUtil_ID = @p_TimeUtilID ) )
WHERE Eqpl_timeUtil_ID = @p_TimeUtilID
END

declare @l_Error int, @l_Return int, @l_ErrorPlace varchar(60), @Msg Varchar(200)

  declare @l_Type  Varchar(1), 
          @l_constID varchar(30),
          @l_Qty     real,
          @l_ReqID   int,
          @l_PickDate smalldatetime,
          @l_ExpenType varchar(50),
          @l_SimpleTask int, 
          @l_AssemblyID int

  set @l_Error = 0
  set @l_Return = 0
  set @l_ErrorPlace = 'Initialise'

  create table #t_equips
    (EquipID    varchar(30),
     EquipQty   real )
  select @l_ERROR = @@ERROR, @l_ErrorPlace = 'creating #t_equips'
  if @l_ERROR != 0  goto Exceptions 

  Create table #t_Requests
  (  Eqprel_Eqpreh_ID    int
   , Eqprel_ComodityCode varchar(30)
   , Eqprel_Quantity     real
   , Eqprel_PickDate     smalldatetime
   , Eqprel_ExpenType    varchar(50)
   , Eqprel_SimpleTask   int
  )
  select @l_ERROR = @@ERROR, @l_ErrorPlace = 'creating #t_Requests'
  if @l_ERROR != 0  goto Exceptions 


DECLARE @hasCDAStandingTask VARCHAR(1)
DECLARE @CDAStandingTaskID INT
DECLARE @addressID INT --ADDED 10/06/2003 GM
DECLARE @allItemAssignedSTKsHaveBeenSentToCFS VARCHAR(1)
declare @cnt int
declare @cnt1  int
DECLARE @SENTTOCFS INT
SET @allItemAssignedSTKsHaveBeenSentToCFS = 'Y'

select @cnt1=count(*) from MT_ACT_PEOPORG where  peoorg_SecusUserID=@userID 
SELECT @SENTTOCFS=COUNT(*) FROM MT_EQP_REQUESTS 
WHERE coalesce(Eqpreh_BatchName,'')<>'' and Eqpreh_timeUtil_ID=@p_TimeUtilID

SELECT @cnt=count(*)--@allItemAssignedSTKsHaveBeenSentToCFS = 'N'
FROM  MT_EQP_PLANNEDMATERIALS Eqp
WHERE Eqp.Eqpl_timeUtil_ID = @p_TimeUtilID
--AND Eqp.Eqpl_AthorisedFlag = 'Y'
AND isnull(Eqpl_deleted,'N')='N'
AND coalesce(Eqp.Eqpl_SimpleTask,0) IN
                (
                                SELECT assignedSTK.AE_AEID 
                                FROM BT_STK_HEADER assignedSTK
                                WHERE assignedSTK.AE_AEID = Eqp.Eqpl_SimpleTask
                                AND coalesce(assignedSTK.AE_deleted,'N') = 'N'
                                AND LEN(coalesce(assignedSTK.AE_batchName,'')) < 1
                )
if @cnt>0
begin
                SET @allItemAssignedSTKsHaveBeenSentToCFS = 'N'
end

SELECT @addressID = AE_address
FROM BT_CTK_HEADER
WHERE AE_AEID = @p_TaskID


--IF A THE TASK HAS A CDA STANDING TASK THAT HAS BEEN SENT TO CFS, USE IT AS THE TASK ID 
--INSTEAD OF THE PASSED TASK 
SET         @hasCDAStandingTask = 'N'

SELECT @hasCDAStandingTask = 'Y', @CDAStandingTaskID = STSK.AE_AEID
FROM   BT_CTK_HEADER ACT, BT_STK_HEADER STSK
WHERE ACT.AE_AEID = @p_TaskID         
AND LEN(isnull(ACT.AE_CDMSStandingTask,'')) > 1
AND       ACT.AE_CDMSStandingTask = STSK.AE_internalRef


DECLARE @projId VARCHAR(20)  
DECLARE @TSQL VARCHAR(max)
DECLARE @countproj INT
DECLARE @tbprojcnt AS TABLE (prjcount int) 
-- QPID_OPT V3-03 (2026-11-02): see optimization_v3/OPTIMIZATION_SUMMARY_V3.md
-- @projId / CFSPROD are read only by the @countproj test below; skip the
-- linked-server round trip when one of the four earlier checks rejects.
IF @SENTTOCFS <= 0
   AND coalesce(@hasCDAStandingTask,'N') <> 'N'
   AND @allItemAssignedSTKsHaveBeenSentToCFS <> 'N'
   AND @cnt1 <> 0
BEGIN
 SELECT @projId=( SELECT TOP 1 case when AE_ParentID <19000000 then AE_ParentID-10000000
                                                                                                                                                                else  AE_ParentID 
                                                                                                                                                                end
                                FROM BT_STK_HEADER, MT_EQP_PLANNEDMATERIALS 
                                WHERE AE_AEID = Eqpl_SimpleTask
                                AND coalesce(AE_deleted,'N') = 'N')
                                                                
 SELECT  @TSQL = 'SELECT COUNT(*) FROM OPENQUERY(CFSPROD,''SELECT * from APPS.PA_PROJECTS_ALL WHERE PM_PRODUCT_CODE
                                                                in (''''CDA'''',''''CDMS'''')  AND PM_PROJECT_REFERENCE= '''''+ @projId +''''''')'
                INSERT into @tbprojcnt EXEC (@TSQL)
                SELECT @countproj=prjcount from @tbprojcnt
END -- QPID_OPT V3-03


print @CDAStandingTaskID
print '@CDAStandingTaskID'
IF @SENTTOCFS>0
BEGIN
                set @p_ErrorCode = -1 
    set @p_ErrorMsg  = 'Requisition has been already sent to CFS.' 
                print @p_ErrorMsg
                -------------For HISTORY Entry--------------
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Preauthorize failed - Requisition has been already sent to CFS.',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                RETURN -1;
END
ELSE IF (coalesce(@hasCDAStandingTask,'N') = 'N')
begin
                print @hasCDAStandingTask
                print '@@hasCDAStandingTask'
                set @p_ErrorCode = -1 
    set @p_ErrorMsg  = 'Authorisation Failed.No Standing Task found.' 
                print @p_ErrorMsg
                -------------For HISTORY Entry--------------
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Preauthorize failed - No Standing Task found',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                RETURN -1;
end
else IF @allItemAssignedSTKsHaveBeenSentToCFS = 'N'
begin
                set @p_ErrorCode = -1 
    set @p_ErrorMsg  = 'Authorisation Failed.Standing task(s) has not been sent to CFS.' 
                print @p_ErrorMsg
                -------------For HISTORY Entry--------------
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Preauthorize failed - Standing task(s) has not been sent to CFS.',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                RETURN -1;
end
else IF @cnt1=0
begin
                set @p_ErrorCode = -1 
    set @p_ErrorMsg  = 'Resource Profile is not configured to authorise a requisition. Please contact System Admin Group.' 
                print @p_ErrorMsg
                -------------For HISTORY Entry--------------
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Preauthorize failed - Resource Profile is not configured',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                RETURN -1;
end
else IF @countproj=0
begin
                set @p_ErrorCode = -1 
    set @p_ErrorMsg  = 'Project has not yet been created in CFS' 
                print @p_ErrorMsg
                -------------For HISTORY Entry--------------
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Preauthorize failed - Project has not yet been created in CFS',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                RETURN -1;
end
else
begin

                print 'GOT TO TASK HAS STANDING TASK'             
                begin tran MainTran
                                UPDATE MT_EQP_PLANNEDMATERIALS
                                                SET
                                                Eqpl_AthorisedFlag = 'Y',
                                                Eqpl_lastUpdated = getDate(),
                                                Eqpl_lastUpdatedBy = @userID,
                                                Eqpl_AuthorisedBy = @userID,
                                                Eqpl_AuthorisedDate = getDate()
                                WHERE Eqpl_timeUtil_ID = @p_TimeUtilID 
                                 -------------For HISTORY Entry-------------- 
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Requisition Preauthorize - Eqpl_AthorisedFlag Y',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                                -- automatically calculate the total estimated PRP units based on individual assemblies
                                -- SM 18052006
                                UPDATE BT_ACT_TIME_UTIL SET Tutl_estimatedPRPUnits=
                                (SELECT SUM(coalesce(pm.Eqpl_Quantity,0)*coalesce(a.Eass_PRPValue,0)) 
                                FROM MT_EQP_PLANNEDMATERIALS pm, BT_ACT_TIME_UTIL tu, MT_EQP_ASSEMBLIES a
                                WHERE pm.Eqpl_timeUtil_ID = tu.Tutl_TimeUtil_Id
                                AND pm.Eqpl_ConstituentID = a.Eass_AssID
                                AND pm.Eqpl_EqpOrAssemblyInd='A'
                                AND tu.Tutl_TimeUtil_Id=@p_TimeUtilID 
                                AND pm.Eqpl_deleted='N')
                                WHERE Tutl_TimeUtil_Id=@p_TimeUtilID 

                  begin Tran DeleteReqs
                
                   delete dbo.MT_EQP_REQUESTLINES
                   where Eqprel_Eqpreh_ID in (select Eqpreh_ID
                                             from   dbo.MT_EQP_REQUESTS
                                             where  Eqpreh_AE_AEID = @CDAStandingTaskID
                                                     and     Eqpreh_timeUtil_ID = @p_TimeUtilID 
                                             and    Eqpreh_BatchName is null)
                   select @l_ERROR = @@ERROR, @l_ErrorPlace = 'deleting requsts'
                   if @l_ERROR != 0   goto Exceptions 
                 
                   delete dbo.MT_EQP_REQUESTS
                   where  Eqpreh_AE_AEID = @CDAStandingTaskID
                   and     Eqpreh_timeUtil_ID = @p_TimeUtilID
                   and    Eqpreh_BatchName is null 
                   select @l_ERROR = @@ERROR, @l_ErrorPlace = 'deleting req headers'
                  if @l_ERROR != 0  goto Exceptions 
                
                 -------------For HISTORY Entry-------------- 
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Requisition Preauthorize - DeleteReqs Tran',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                  commit Tran DeleteReqs
                
                  /*
                  ** Get the Equipments/Assemblies authorised for the 
                  ** Task in Question 
                  */
                
                  begin Tran CreateReqs
                
                
                  insert into dbo.MT_EQP_REQUESTS
                  (Eqpreh_AE_AEID, Eqprh_RequisitionGroup, Eqpreh_DepotID, 
                   Eqpreh_AuthorisedBy, Eqpreh_AuthTelephone,
                   Eqpreh_ProfitCenter, Eqpreh_CostCenter, 
                   Eqpreh_DeliverToSite, 
                   Eqpreh_NeedByDate,Eqpreh_SendToCFS,
                   Eqpreh_Version, Eqperh_delete, Eqpreh_timeUtil_ID, 
                   Eqpreh_IssuedTo, Eqpreh_DepotLocation, Eqpreh_AddressID)
                  select distinct 
                         @CDAStandingTaskID, 
                                 Eqp.Eqpl_RequisitionGroup,Eqp.Eqpl_NearestDepot,
                         usr.USER_FIRSTNAME+' '+usr.USER_LASTNAME, pep.peoporg_telephone,
                         NULL, NULL,  
                         case when isnull(Eqp.Eqpl_DeliverToSite,'N') = 'Y' then 1 else 0 end , 
                         Eqp.Eqpl_PickDate, 'Y',
                         1,  'N', @p_TimeUtilID, 
                                Eqp.Eqpl_DepotLocation as IssuedTo,    
                --             (select top 1 peoporg_name from dbo.CDA_ACT_PEOPORG where peoporg_peoporgID = (select top 1
                --             Tutl_assignedToPerson from dbo.CDA_ACT_TIME_UTIL where Tutl_TimeUtil_Id = @p_TimeUtilID)) as IssuedTo, --GM 09/10/03
                         Eqp.Eqpl_DepotLocation, @addressID
                  from   dbo.MT_EQP_PLANNEDMATERIALS Eqp,
                         dbo.MT_ACT_PEOPORG pep,
                         dbo.MT_USERS usr,
                         dbo.BT_CTK_HEADER act
                  where  Eqp.Eqpl_RequisitionGroup is not null 
                  and    Eqp.Eqpl_AthorisedFlag = 'Y'
                  and    Eqp.Eqpl_act_AEID = act.AE_AEID
                  and    Eqp.Eqpl_act_AEID = @p_TaskID
                  and    Eqp.Eqpl_timeUtil_ID = @p_TimeUtilID
                  and    not exists 
                         (select 'x' from dbo.MT_EQP_REQUESTS req
                          where req.Eqpreh_AE_AEID = Eqp.Eqpl_act_AEID
                          and req.Eqpreh_timeUtil_ID = Eqp.Eqpl_timeUtil_ID 
                          and   req.Eqprh_RequisitionGroup = Eqp.Eqpl_RequisitionGroup )
                -- and    act.AE_batchName is not null --CHECK FOR STANDING TASK BATCH NAME IS DONE ABOVE
                  and    Eqp.Eqpl_AuthorisedBy = pep.peoorg_SecusUserID 
                  and    pep.peoorg_SecusUserID = usr.INT_USR_ID 
                  and    coalesce(pep.peoporg_deleted,'N') <> 'Y'
                  and    coalesce(usr.ACCOUNT_ENABLED,'Y') ='Y'
                  select @l_ERROR = @@ERROR, @l_ErrorPlace = ' inserting req headers'
                  if @l_ERROR != 0  goto Exceptions 
                
                print 'step1'
                print @CDAStandingTaskID
                print @p_TimeUtilID
                print @p_TaskID
                print 'SETP011'
                select * from MT_EQP_REQUESTS where Eqpreh_AE_AEID=@CDAStandingTaskID

                                    select Req.Eqpreh_ID, Eql.Eqpl_EqpOrAssemblyInd, Eql.Eqpl_ConstituentID,
                             Eql.Eqpl_Quantity,  Eqpl_ExpType, Eql.Eqpl_SimpleTask
                      from  dbo.MT_EQP_Requests Req,
                            dbo.MT_EQP_PlannedMaterials Eql
                      where Req.Eqpreh_AE_AEID = @CDAStandingTaskID
                      and   Req.Eqpreh_timeUtil_ID = @p_TimeUtilID
                      and   Req.Eqpreh_batchName is null 
                      and   Eql.Eqpl_act_AEID = @p_TaskID
                      and   Req.Eqpreh_timeUtil_ID = Eql.Eqpl_timeUtil_ID
                      and   Req.Eqprh_RequisitionGroup = Eql.Eqpl_RequisitionGroup
                      and   Eql.Eqpl_AthorisedFlag = 'Y'
                      and   isnull(Eqpl_deleted,'N') = 'N'
                  declare c_reqs cursor LOCAL READ_ONLY for 
                    select Req.Eqpreh_ID, Eql.Eqpl_EqpOrAssemblyInd, Eql.Eqpl_ConstituentID,
                             Eql.Eqpl_Quantity,  Eqpl_ExpType, Eql.Eqpl_SimpleTask
                      from  dbo.MT_EQP_Requests Req,
                            dbo.MT_EQP_PlannedMaterials Eql
                      where Req.Eqpreh_AE_AEID = @CDAStandingTaskID
                      and   Req.Eqpreh_timeUtil_ID = @p_TimeUtilID
                      and   Req.Eqpreh_batchName is null 
                      and   Eql.Eqpl_act_AEID = @p_TaskID
                      and   Req.Eqpreh_timeUtil_ID = Eql.Eqpl_timeUtil_ID
                      and   Req.Eqprh_RequisitionGroup = Eql.Eqpl_RequisitionGroup
                      and   Eql.Eqpl_AthorisedFlag = 'Y'
                      and   isnull(Eqpl_deleted,'N') = 'N'
                
                  open c_reqs 
                  select @l_ERROR = @@ERROR, @l_ErrorPlace = 'opening c_Reqs'
                  if @l_ERROR != 0  goto Exceptions 
                
                  fetch NEXT FROM c_reqs into           
                          @l_ReqID   ,
                          @l_Type  , 
                          @l_constID ,
                          @l_Qty     ,
                          @l_ExpenType , 
                          @l_SimpleTask 
                  select @l_ERROR = @@ERROR, @l_ErrorPlace = 'fetching c_reqs(1)'
                  if @l_ERROR != 0  goto Exceptions 
                  
                  while (@@FETCH_STATUS = 0) 
                  begin 
                print 'step2'
                
                if @l_Type = 'E' 
                       insert into #t_Equips
                       values (@l_constID, @l_Qty) 
                    else
                    begin
                                                print 'step02'
                
                       Set @l_AssemblyID = convert(int, @l_constID)
                       exec @l_Return = SP_GET_AssemblyConfigs @l_AssemblyID, @l_Qty
                       select @l_ERROR = @@ERROR, @l_ErrorPlace = 'decompsing assemblies'
                       if @l_ERROR != 0  or @l_Return != 0 goto Exceptions 
                
                    end 
                                
                    insert into #t_Requests
                    ( Eqprel_Eqpreh_ID, Eqprel_ComodityCode, Eqprel_Quantity, Eqprel_ExpenType, Eqprel_SimpleTask)
                    Select @l_ReqID, teqp.EquipID, sum(teqp.EquipQty),  @l_ExpenType, @l_SimpleTask 
                    from  #t_Equips teqp
                    group by teqp.EquipID
                    select @l_ERROR = @@ERROR, @l_ErrorPlace = 'insert temp requests'
                    if @l_ERROR != 0  goto Exceptions 
                  
                    delete #t_Equips 
                    select @l_ERROR = @@ERROR, @l_ErrorPlace = 'delete #t_equips'
                    if @l_ERROR != 0  goto Exceptions 
                
                    fetch NEXT FROM c_reqs into           
                          @l_ReqID   ,
                          @l_Type  , 
                          @l_constID ,
                          @l_Qty     
                ,
                          @l_ExpenType, 
                          @l_SimpleTask 
                    select @l_ERROR = @@ERROR, @l_ErrorPlace = 'Fetch c_reqs(2)'
                    if @l_ERROR != 0  goto Exceptions 
                
                  end 
                select Eqprel_Eqpreh_ID, Eqprel_ComodityCode, sum(Eqprel_Quantity), 
                         Eqprel_ExpenType, getdate(), 'IUS','N', Eqprel_SimpleTask
                  from #t_Requests
                  where Eqprel_Quantity > 0
                  group by Eqprel_Eqpreh_ID, Eqprel_ComodityCode,Eqprel_ExpenType, Eqprel_SimpleTask
                  

                  insert into dbo.MT_EQP_RequestLines
                  (Eqprel_Eqpreh_ID, Eqprel_ComodityCode, Eqprel_Quantity, 
                   Eqprel_ExpenType, Eqprel_ExpenDate, Eqprel_ExpenOrg, Eqprel_delete, Eqprel_SimpleTask)
                  select Eqprel_Eqpreh_ID, Eqprel_ComodityCode, sum(Eqprel_Quantity), 
                         Eqprel_ExpenType, getdate(), 'IUS','N', Eqprel_SimpleTask
                  from #t_Requests
                  where Eqprel_Quantity > 0
                  group by Eqprel_Eqpreh_ID, Eqprel_ComodityCode,Eqprel_ExpenType, Eqprel_SimpleTask
                  select @l_ERROR = @@ERROR, @l_ErrorPlace = 'Finalise Requisitions'
                  if @l_ERROR != 0 goto Exceptions 
                
                  -------------For HISTORY Entry-------------- 
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Requisition Preauthorize - CreateReqs Tran',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                  commit tran CreateReqs
                  -------------For HISTORY Entry-------------- 
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Requisition Preauthorize - Main Tran',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------
                commit Tran MainTran

                UPDATE               MT_EQP_PLANNEDMATERIALS
                SET         Eqpl_RequisitionNumber = req.Eqpreh_ID
                FROM   MT_EQP_PLANNEDMATERIALS pm, MT_EQP_REQUESTS req
                WHERE pm.Eqpl_act_AEID = @p_TaskID
                AND       req.Eqpreh_AE_AEID = @CDAStandingTaskID
                AND       pm.Eqpl_timeUtil_ID = req.Eqpreh_timeUtil_ID
                AND       pm.Eqpl_RequisitionGroup = req.Eqprh_RequisitionGroup
                AND       pm.Eqpl_timeUtil_ID =  @p_TimeUtilID  

                -------------For HISTORY Entry-------------- 
                insert into BT_ACT_REQUISITION_HIST values (@p_TaskID,@p_TimeUtilID,
                (select coalesce(Eqpreh_ID,'N/A') FROM              MT_EQP_REQUESTS WHERE Eqpreh_timeUtil_ID = @p_TimeUtilID),'SP_CREATE_REQUISITION_V5'
                ,'Requisition Preauthorize successful',getdate()
                ,@userID,(select USER_FIRSTNAME+' '+USER_LASTNAME from MT_USERS where INT_USR_ID=@userID))
                -------------For HISTORY Entry--------------

                set @p_ErrorCode = 0 
                RETURN 0;

end

print 'Test1'

Exceptions:
begin 
    if @@Trancount > 0  rollback transaction 
    select  @Msg = description + @l_ErrorPlace
    from master.dbo.sysmessages 
    where error = @l_Error 
    set @p_ErrorCode = @l_Error 
    set @p_ErrorMsg  = @Msg 
    Raiserror(@Msg,16,1) 
    return 1
  end 


end









GO
SET NOEXEC OFF;
GO
IF OBJECT_DEFINITION(OBJECT_ID('dbo.SP_CREATE_REQUISITION_V5')) LIKE '%QPID_OPT V3-03%'
    PRINT 'DEPLOYED: V3-03 is live.';
ELSE
    RAISERROR('NOT DEPLOYED: the original SP_CREATE_REQUISITION_V5 is still live (see the REFUSED message above).', 16, 1);
GO
