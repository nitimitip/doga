/******************************************************************************
  BUG FIX BF02 - PENDING VALIDATION - DO NOT DEPLOY UNTESTED
  Procedure : [dbo].[sp_ACT_PLABulkBillingQuery_UPDATE]
  Base      : QPID_SP/sp_ACT_PLABulkBillingQuery_UPDATE.sql (production original)
  Fix       : BF02 (2026-10-21)
  Generated : bugfix/tools/gen_bugfix.py (inverse transform = base, checked)

  WHY (BF02, user report 2026-10-21: records missing in BT_ACT_HIST):
    HIST_HISTID is the clustered PK (PK_BT_ACT_HIST_1) and NOT an identity.
    Every writer takes MAX(HIST_HISTID)+1 with an ordinary read. Two
    concurrent writers read the same MAX; the second INSERT fails with
    2627 (duplicate key) and that history row is lost. The ~30
    sp_ACT_addHIST_* wrappers have no error handling, and
    sp_ACT_PLABulkBillingQuery_UPDATE swallows the error in its CATCH.

  THE FIX (same as Batch 34, PLA_addEnquiry): WITH (UPDLOCK, HOLDLOCK) on
  the MAX() read. U is incompatible with U, so a second writer waits at its
  MAX() read until the first commits, then reads the new MAX (no 2627, no
  conversion deadlock). Outside a transaction the lock lasts for the one
  INSERT statement only. Ids stay gap-free and in the same sequence.
  Writers without the hint can still collide: deploy all five BF02
  procedures together and check other writers (bf02_validation BF02.2).

  WHAT CHANGED (and nothing else):
    1. Lines 61 and 99: (select max(hist_histid)+1 from BT_ACT_HIST)+ROW_NUMBER()
       -> (select max(hist_histid)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK))+ROW_NUMBER().
    2. BEGIN TRAN after BEGIN TRY, COMMIT TRAN before
       set @mResult='SUCCESSFUL', IF @@TRANCOUNT > 0 ROLLBACK TRAN in CATCH
       (after dbo.GetError(), so the error text is unchanged).
    3. CREATE -> ALTER.

  BEHAVIOUR CHANGE (failure path only): before, the two invoicing
  UPDATEs (PLA_PROD.dbo.PLA_ACT_ACTIVITYEVENT, BT_CTK_HEADER) stayed
  committed when a history INSERT failed: tasks Invoiced, history
  missing, the caller got an error string. Now the whole call is
  rolled back and the caller gets the same error string. Success path
  unchanged. PLA_PROD is a three-part name on the same instance (local
  transaction, no MSDTC). If the application calls this inside its own
  transaction, the CATCH rolls that back too (standard pattern).

  VALIDATION: bugfix/validation/bf02_validation.sql
  ROLLBACK  : bugfix/rollback/sp_ACT_PLABulkBillingQuery_UPDATE_ORIGINAL.sql
******************************************************************************/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[sp_ACT_PLABulkBillingQuery_UPDATE]  
(      
@tbid Type_PLABulkAEID READONLY ,
@UserId int 
)      
AS     
 BEGIN

Declare @mResult varchar(1000)='';
 BEGIN TRY
BEGIN TRAN --BF02: invoicing and its history rows succeed or fail together
declare @iHIST_createdByDescr as varchar(200)
declare @ae_status as varchar(20)
SELECT @iHIST_createdByDescr = CONCAT(USER_FIRSTNAME,' ',USER_LASTNAME) from MT_USERS where int_usr_id=@UserId
select @ae_status = lov_Value from MT_SYS_LOV WHERE	lov_Name = 'sysStatusTask' 
			and lov_Desc = 'Invoiced'

DECLARE @CTKIddistinct AS TABLE ( task_aeid INT ) 
insert into @CTKIddistinct select distinct task_aeid from @tbid

update PLA_PROD.dbo.PLA_ACT_ACTIVITYEVENT
set ae_invoiced = 'Y' , 
ae_status = @ae_status,
ae_lastupdated = getdate(),
ae_lastUpdatedBy = @UserId
where ae_aeid in (select ae_aeid from PLA_PROD.dbo.PLA_ACT_ACTIVITYEVENT where ae_internalref in (select ae_internalref from BT_CTK_HEADER where ae_aeid in(select  task_aeid from @CTKIddistinct)))


update BT_CTK_HEADER
set ae_invoiced = 'Y' , 
ae_status = @ae_status,
ae_lastupdated = getdate(),
ae_lastUpdatedBy = @UserId
where ae_aeid in (select  task_aeid from @CTKIddistinct)


	INSERT BT_ACT_HIST(
	HIST_HISTID,
	HIST_AEID,
	HIST_lastChange,
	HIST_internalRef,
	HIST_metaModelType2,
	HIST_fieldType,
	HIST_fieldName,
	HIST_tableName,
	HIST_columnName,
	HIST_valueInt,
	HIST_valueChar,
	HIST_descr,
	HIST_dateTime,
	HIST_dateCreated,
	HIST_createdBy,
	HIST_createdByDescr
	)
select  (select max(hist_histid)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK))+ROW_NUMBER() OVER(ORDER BY task_aeid), 
     task_aeid
	, null
	, ae_internalRef 
	, ae_metaModelType2
	, 'lovVarChar'
	, 'Invoiced'
	,'BT_CTK_HEADER'
	, 'AE_INVOICED'
	, null
	, 'Y'
	, 'Y'
	,null
	, getdate()
	,@userID
	, @iHIST_createdByDescr
from @CTKIddistinct inner join BT_CTK_HEADER
on ae_aeid = task_aeid

	INSERT BT_ACT_HIST(
	HIST_HISTID,
	HIST_AEID,
	HIST_lastChange,
	HIST_internalRef,
	HIST_metaModelType2,
	HIST_fieldType,
	HIST_fieldName,
	HIST_tableName,
	HIST_columnName,
	HIST_valueInt,
	HIST_valueChar,
	HIST_descr,
	HIST_dateTime,
	HIST_dateCreated,
	HIST_createdBy,
	HIST_createdByDescr
	)
select 
(select max(hist_histid)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK))+ROW_NUMBER() OVER(ORDER BY task_aeid), 
     task_aeid
	, null
	, ae_internalRef 
	, ae_metaModelType2
	, 'lovVarChar'
	, 'Status'
	,'BT_CTK_HEADER'
	, 'AE_STATUS'
	, null
	, @ae_status
	, 'Invoiced'
	,null
	, getdate()
	,@userID
	, @iHIST_createdByDescr
from @CTKIddistinct inner join BT_CTK_HEADER
on ae_aeid = task_aeid

--return @@rowcount
delete from @CTKIddistinct;
COMMIT TRAN
set @mResult='SUCCESSFUL';
	
End try

Begin catch
	Set @mResult=dbo.GetError();
	IF @@TRANCOUNT > 0 ROLLBACK TRAN; --BF02
end catch

select @mResult as Result

END


GO
