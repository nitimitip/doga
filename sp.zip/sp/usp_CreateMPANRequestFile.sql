/******************************************************************************
  BUG FIX BF02 - PENDING VALIDATION - DO NOT DEPLOY UNTESTED
  Procedure : [dbo].[usp_CreateMPANRequestFile]
  Base      : QPID_SP/usp_CreateMPANRequestFile.sql (production original)
  Fix       : BF02 (2026-10-21)
  Generated : bugfix/tools/gen_bugfix.py (inverse transform = base, checked)

  WHY (BF02, user report 2026-10-21: records missing in BT_ACT_HIST):
    HIST_HISTID is the clustered PK (PK_BT_ACT_HIST_1) and NOT an identity.
    Every writer takes MAX(HIST_HISTID)+1 with an ordinary read. Two
    concurrent writers read the same MAX; the second INSERT fails with
    2627 (duplicate key) and that history row is lost. The ~30
    sp_ACT_addHIST_* wrappers have no error handling, and
    sp_ACT_PLABulkBillingQuery_UPDATE swallows the error in its CATCH.

  THE FIX (same as Batch 34, PLA_addEnquiry): WITH (UPDLOCK, HOLDLOCK) on
  the MAX() read. U is incompatible with U, so a second writer waits at its
  MAX() read until the first commits, then reads the new MAX (no 2627, no
  conversion deadlock). Outside a transaction the lock lasts for the one
  INSERT statement only. Ids stay gap-free and in the same sequence.
  Writers without the hint can still collide: deploy all five BF02
  procedures together and check other writers (bf02_validation BF02.2).

  WHAT CHANGED (and nothing else):
    1. Line 339: (SELECT max(hist_histid)+1 from BT_ACT_HIST) -> (SELECT max(hist_histid)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK)).
    2. The 55 en-dash literals in REPLACE(..., '<en dash>', '-') are
       written CHAR(150) so the file is ASCII (same change and same
       code-page 1252 guard as Batch 25; equivalent only on 1252).
    3. CREATE -> ALTER, the guard batch.
  NOT changed: MAX(MPANReq_FileID)+1 (same race, not reported).

  VALIDATION: bugfix/validation/bf02_validation.sql
  ROLLBACK  : bugfix/rollback/usp_CreateMPANRequestFile_ORIGINAL.sql
******************************************************************************/

-- GUARD: CHAR(150) reproduces the original en-dash literals only on code page 1252
IF ISNULL(CONVERT(int, COLLATIONPROPERTY(CONVERT(sysname, DATABASEPROPERTYEX(DB_NAME(), 'Collation')), 'CodePage')), 0) <> 1252
BEGIN
    RAISERROR('Database default collation is not code page 1252: CHAR(150) literals are NOT equivalent. Deployment aborted.', 16, 1);
    SET NOEXEC ON;
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		TCS: Sumanta Dhara
-- Create date: 08-Jan-2020
-- Description:	Create MPAN File
-- Modifyed By: Sandeep Singh
-- Modifyed Date: 09-07-2020
-- =============================================
---    [usp_CreateMPANRequestFile] 40000375,10003716,'REQ5312717'
ALTER PROCEDURE [dbo].[usp_CreateMPANRequestFile] 
	@ActivityID INT,
	@UserID INT,
	@FileID varchar(17)
 
AS
SET NOCOUNT ON

DECLARE @userTelephone VARCHAR(50)
DECLARE @userFax VARCHAR(50)
DECLARE @parentEnquiry INT
DECLARE @newID INT
DECLARE @internalRef Varchar(20)
--select  MAX(MPANReq_FileID) from [dbo].[BT_MPANREQ_FILES]
select @newID = MAX(MPANReq_FileID) from [dbo].[BT_MPANREQ_FILES]
	set @newID = @newID + 1
--Select 'Step 1'

SELECT top 1 @userTelephone = CASE 
	WHEN len(isnull(peoporg_telephone, '')) < 1 THEN '01642 258100' 
	ELSE isnull(peoporg_telephone,'')
	END,
@userFax =
	CASE 
	WHEN len(isnull(peoporg_fax, '')) < 2 THEN '01642 258100' 
	ELSE isnull(peoporg_fax,'')
	END
FROM 	MT_ACT_PEOPORG
WHERE 	peoporg_deleted = 'N'
AND 	peoorg_SecusUserID = @UserID
print '@userTelephone'
print @userTelephone
 print '@userFax'
print @userFax
--Select 'Step 2'
INSERT INTO BT_MPANREQ_FILES(
	MPANReq_FileID,
	fileID, 
	projectRefNo, 
	tasRefNo, 
	IUSContactEngineer, 
	responsibleDepot, 
	IUSContactTelNo, 
	IUSContactFaxNo, 
	NEDLref, 
	CNES, 
	plotNo, 
	houseNo, 	
	streetName, 
	village, 
	district, 
	postalTown, 
	postcode, 
	description, 
	easting, 
	northing, 
	custBuildName, 
	positionInCompany, 
	company, 
	developmentName, 
	cHouseNo, 
	cBuildingName, 
	cStreet, 
	cVillage, 
	cDistrict, 
	cPostalTown, 
	cPostcode, 
	cTelephone, 
	cUsage, 
	meterPosition, 
	noOfMPANs, 
	feeder, 
	substation, 
	noOfPhases, 
	noOfWires, 
	red, 
	yellow, 
	blue, 
	supplyCapacity, 
	supplyVoltage, 
	distributor, 
	GSPgroup, 
	schedConnectDate, 
	otherInfo, 
	createdDate, 
	requestedBy, 
	processedOn, 
	deleted, 
	errorOccured, 
	errorDescription, 
	CTRatio,
	ContactEmail
	)
SELECT top 1
	@newID,
	@FileID as fileID, 
	Act.AE_internalRef AS projectRefNo,-- just for testing purpose (select top 1 A.ae_internalref from BT_PROJ_U_HEADER A where A.AE_AEID = Act.AE_parentProjID)  
	Act.AE_internalRef as tasRefNo, 
	REPLACE(UPPER(SUBSTRING(u.USER_FIRSTNAME + ' ' + u.USER_LASTNAME,1,20)),CHAR(150),'-') as IUSContactEngineer, 
	'CDA' as responsibleDepot, 
	REPLACE(LEFT(isnull(@userTelephone,'11111 00000'),15),CHAR(150),'-') as IUSContactTelNo, 
	REPLACE(LEFT(isnull(@userFax,'01642 258100'),15),CHAR(150),'-') as IUSContactFaxNo, 
    REPLACE(LEFT(UPPER(Act.AE_externalRef),20),CHAR(150),'-') as NEDLref, 
	LEFT(UPPER(Act.AE_NES),30) as CNES,  -- NOMINATED ELECTRICITY SUPPLIER
	RIGHT(UPPER(ltrim(rtrim(Act.AE_plotUnit))),4) as plotNo, 
	REPLACE(LEFT(UPPER(SiteAddress.addressLine3),20),CHAR(150),'-') as houseNo, 
	REPLACE(LEFT(UPPER(SiteAddress.addressLine5),40),CHAR(150),'-') as streetName, 
    REPLACE(LEFT(UPPER(SiteAddress.addressLine7),40),CHAR(150),'-') as village, 
	REPLACE(LEFT(UPPER(SiteAddress.addressLine9),40),CHAR(150),'-') as district, 
    REPLACE(LEFT(UPPER(SiteAddress.addressLine8),40),CHAR(150),'-') as postalTown, 
	LEFT(UPPER(ISNULL(SiteAddress.postCode,'')),10) as postcode, 

	substring(isnull((SELECT top 1 REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(UPPER(Note_Text),CHAR(13),' '),CHAR(10),' '),CHAR(9),' '),CHAR(124),' '),CHAR(150),'-') FROM BT_ALL_NOTE 
			WHERE Note_ParentTable in( 'activityEvent','BT_CTK_HEADER')
			and Note_ParentID = act.ae_aeid
			and Note_Deleted = 'N'
			and Note_Usage = (select top 1 LOV_VALUE from MT_SYS_LOV where
			 LOV_NAME = 'sysNoteUsage' and LOV_DESC = 'MPAN Site Location' and LOV_DELETED = 0)
			order by Note_DateCreated desc),''),1,255) as description,  -- description of Service address
	--LEFT(UPPER(SiteAddress.siteName),255) as description, -- changes for CTK site location
    ISNULL(LEFT(UPPER(SiteAddress.easting),10),'') as easting, 
   	ISNULL(LEFT(UPPER(SiteAddress.northing),10),'') as northing, 

	REPLACE(LEFT(UPPER(isnull(cont.con_forename,'') + ' ' +	isnull(cont.con_surname,'')),20),CHAR(150),'-') as custBuildName, 
	REPLACE(LEFT(UPPER(cont.con_jobTitle),20),CHAR(150),'-') as positionInCompany, 
	REPLACE(LEFT(UPPER(cust.CUST_ORG_NAME),40),CHAR(150),'-') as company, 
	REPLACE(LEFT(UPPER(Act.AE_relativeName),40),CHAR(150),'-') as developmentName, 
	--REPLACE(LEFT(UPPER(CustomerAddress.addressLine3),40),CHAR(150),'-') as cHouseNo, 
	REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine3<>'' or A.addressLine3 is null))>0 THEN CustomerAddress.addressLine3 ELSE SiteAddress.addressLine3 END),40),CHAR(150),'-') as cHouseNo,
	--REPLACE(LEFT(UPPER(CustomerAddress.addressLine3),40),CHAR(150),'-') as cBuildingName, 
REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine3<>'' or A.addressLine3 is null))>0 THEN CustomerAddress.addressLine3 ELSE SiteAddress.addressLine3 END),40),CHAR(150),'-') as cBuildingName,
--	REPLACE(LEFT(UPPER(CustomerAddress.addressLine5),40),CHAR(150),'-') as cStreet, 
REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine5<>'' or A.addressLine5 is null))>0 THEN CustomerAddress.addressLine5 ELSE SiteAddress.addressLine5 END),40),CHAR(150),'-') as cStreet,
   -- REPLACE(LEFT(UPPER(CustomerAddress.addressLine7),40),CHAR(150),'-') as cVillage, 
   REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine7<>'' or A.addressLine7 is null))>0 THEN CustomerAddress.addressLine7 ELSE SiteAddress.addressLine7 END),40),CHAR(150),'-') as cVillage,
	--REPLACE(LEFT(UPPER(CustomerAddress.addressLine9),40),CHAR(150),'-') as cDistrict, 
 REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine9<>'' or A.addressLine9 is null))>0 THEN CustomerAddress.addressLine9 ELSE SiteAddress.addressLine9 END),40),CHAR(150),'-') as cDistrict,
  --  REPLACE(LEFT(UPPER(CustomerAddress.addressLine8),40),CHAR(150),'-') as cPostalTown, 
   REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(addressLine8) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine8<>'' or A.addressLine8 is null))>0 THEN CustomerAddress.addressLine8 ELSE SiteAddress.addressLine8 END),40),CHAR(150),'-') as cPostalTown,
	--LEFT(UPPER(CustomerAddress.postCode),10) as cPostcode, 
	LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.postCode<>'' or A.postCode is null))>0 THEN CustomerAddress.postCode ELSE SiteAddress.postCode END),10) as cPostcode, 
        --LEFT(UPPER(isnull(cont.con_telephone,'') + REPLACE(isnull(cont.con_telExt,''), isnull(cont.con_telExt,''), ' ext: ') +   isnull(cont.con_telExt,'')),25) as cTelephone,
	CASE WHEN len(isnull(cont.con_telephone, '')) < 1 THEN '11111 000000' ELSE substring(isnull(peoporg_telephone,''),1,25) END cTelephone, 
	UPPER(substring(isnull((dbo.fn_TranslateSYSLOV('MPANsysUsage',Act.AE_usage)),(dbo.fn_TranslateSYSLOV('sysUsage',Act.AE_usage))),1,20))  as cUsage, 
	UPPER(substring((dbo.fn_TranslateSYSLOV('sysMeterPosition',Act.AE_meterPosition)),1,30)) as AE_meterPosition, 
	UPPER(Act.AE_MPANSrequired) as noOfMPANs, 
	LEFT(ISNULL(UPPER(Act.AE_feeder),''),50) as feeder, 
	LEFT(ISNULL(UPPER(Act.AE_substation),''),50) as substation, 
	--Act.AE_noPhases as noOfPhases, --to be removed and uncomment the below
    UPPER(isnull((dbo.fn_TranslateSYSLOV('MPANsysNoPhases',Act.AE_noPhases)) , (dbo.fn_TranslateSYSLOV('sysNoPhases',Act.AE_noPhases)))) as noOfPhases, 
	Act.AE_noWires as noOfWires, --to be removed  and uncomment the below
	--UPPER(isNull((dbo.fn_TranslateSYSLOV('MPANsysNoWires',Act.AE_noWires)),(dbo.fn_TranslateSYSLOV('sysNoWires',Act.AE_noWires)))) as noOfWires, 
	REPLACE(REPLACE(Act.AE_phaseRed, 'Y', 1),'N',0) as red, 
	REPLACE(REPLACE(Act.AE_phaseYellow, 'Y', 1),'N',0) as yellow, 
	REPLACE(REPLACE(Act.AE_phaseBlue, 'Y', 1),'N',0) as blue, 
    LEFT(UPPER(Act.AE_supplyCapacity),6) as supplyCapacity, 
	UPPER(substring(isnull((dbo.fn_TranslateSYSLOV('MPANsysSupplyVoltage',Act.AE_supplyVoltage)), (dbo.fn_TranslateSYSLOV('sysSupplyVoltage',Act.AE_supplyVoltage))),1,6)) as supplyVoltage, 
	UPPER(substring(isnull((dbo.fn_TranslateSYSLOV('MPANSYS_COMPANY',Act.AE_networkDistributor)),(dbo.fn_TranslateSYSLOV('SYS_COMPANY',Act.AE_networkDistributor))),1,4)) as distributor, 
	--Act.AE_GSPGroup as GSPgroup, --to be removed and uncomment the below
	UPPER(substring(isnull((dbo.fn_TranslateSYSLOV('MPANsysGSPGroup',Act.AE_GSPGroup)),(dbo.fn_TranslateSYSLOV('sysGSPGroup',Act.AE_GSPGroup))),1,2)) as GSPgroup, 
	[dbo].[fn_ConvDateToInt] (Act.AE_plannedEndDate) as schedConnectDate, 
	UPPER(SUBSTRING(REPLACE(REPLACE(REPLACE(REPLACE(Act.AE_summaryDescription, CHAR(9), ''), CHAR(13), ''), CHAR(10), ''),CHAR(150),'-'),1,200)) as otherInfo, 
	getDate() as createdDate, 
	@UserID as requestedBy, 
	NULL as processedOn, 
	'N' as deleted, 
	'N' as errorOccured, 
	NULL as errorDescription, 
	LEFT(ISNULL(UPPER(dbo.fn_TranslateSYSLOV('sysCTRatio', Act.AE_CTRatio)),''),6) as CTRatio, 
	REPLACE(UPPER(LEFT(LTRIM(RTRIM(isnull(cont.con_email,''))),50)),CHAR(150),'-') as ContactEmail 

FROM
	BT_CTK_HEADER Act INNER JOIN 
	BT_ENQUIRY_MASTER ENQ ON Act.AE_rootID = isnull(ENQ.AE_rootID,ENQ.AE_AEID) --AND ENQ.AE_AEID = @parentEnquiry 
	INNER JOIN
	MT_ACT_PEOPORG peop ON Act.AE_assignedToPerson = peop.peoporg_peoporgID LEFT OUTER JOIN
	BT_ADDRESS_MASTER SiteAddress ON Act.AE_address = SiteAddress.ADDRESS_ID INNER JOIN
	BT_CUSTOMER_MASTER cust ON Act.AE_customer = cust.CUST_ID  LEFT OUTER JOIN
	BT_ADDRESS_MASTER CustomerAddress ON ACT.AE_correspondenceAddress = CustomerAddress.ADDRESS_ID  LEFT OUTER JOIN
	BT_CONTACTS_MASTER cont ON ENQ.AE_Contact = cont.con_contactID,
	MT_USERS u

WHERE     (Act.AE_AEID = @ActivityID)
	AND (Act.AE_deleted = 'N')
	AND u.INT_USR_ID = @UserID


--Select 'Step 3'
UPDATE BT_CTK_HEADER
	SET AE_MpanRequested = 'Y',AE_MPANVerification=getdate()
WHERE AE_AEID = @ActivityID AND
	AE_deleted = 'N'
Select @internalRef=AE_internalRef 
From BT_CTK_HEADER 
WHERE AE_AEID = @ActivityID AND
AE_deleted = 'N' AND
ISNULL(AE_MpanRequested,'N') = 'Y'
--if not exists(Select * from BT_MPAN_QPIDNCAS_CTK Where QPID_Ref=@internalRef)
--Begin
--	INsert INto BT_MPAN_QPIDNCAS_CTK(QPID_Ref,NCAS_Ref)
--	Values(@internalRef, case when len(@internalRef)>10 then concat('CTK9',substring(@internalRef,6,len(@internalRef)-5)) Else @internalRef End)
--End
DECLARE @prefixchange varchar(4);
SET @prefixchange='CTK9';
if not exists(Select * from BT_MPAN_QPIDNCAS_CTK Where QPID_Ref=@internalRef)
Begin

    IF @internalRef like 'CTK22%'
	BEGIN
	 SET @prefixchange='CTK8'
	 INsert INto BT_MPAN_QPIDNCAS_CTK(QPID_Ref,NCAS_Ref)
	Values(@internalRef, case when len(@internalRef)>10 then concat(@prefixchange,substring(@internalRef,6,len(@internalRef)-5)) Else @internalRef End)
	END
	ELSE IF @internalRef like 'CTK29%'
	BEGIN
	 SET @prefixchange='CTK9'
	 INsert INto BT_MPAN_QPIDNCAS_CTK(QPID_Ref,NCAS_Ref)
	Values(@internalRef, case when len(@internalRef)>10 then concat(@prefixchange,substring(@internalRef,6,len(@internalRef)-5)) Else @internalRef End)
	END

	
End	
--    Select * from BT_MPAN_QPIDNCAS_CTK
--Select 'Step 4'
SELECT   top 1
(select top 1 AE_internalRef from BT_PROJ_U_HEADER where ae_aeid= (select s.AE_ParentID from BT_STK_HEADER s where s.ae_aeid=Act.AE_parentID))  AS AE_parenttProjInternalRef,
	--(select top 1 ae_internalref from BT_PROJ_U_HEADER where ae_aeid = Act.AE_parentProjID) AS AE_parenttProjInternalRef, 
	 case when len(Act.AE_internalRef)>10 then concat(@prefixchange,substring(Act.AE_internalRef,6,len(Act.AE_internalRef)-5)) Else Act.AE_internalRef End As intRef, --Act.AE_internalRef intRef,
	REPLACE(UPPER(SUBSTRING(u.USER_FIRSTNAME + ' ' + u.USER_LASTNAME ,1,20)),CHAR(150),'-') userName,--CDMS_ACT_peoporg.peoporg_name,
	'CDA' responsibleDepot, 
	REPLACE(LEFT(isnull(@userTelephone,'11111 000000'),15),CHAR(150),'-') telephone, 
	REPLACE(LEFT(isnull(@userFax,'01642 258100'),15),CHAR(150),'-') fax,  
    REPLACE(LEFT(UPPER(Act.AE_externalRef),20),CHAR(150),'-') extRef,
	LEFT(UPPER(Act.AE_NES),30) nominatedSupplier, -- NOMINATED ELECTRICITY SUPPLIER
	RIGHT(UPPER(ltrim(rtrim(Act.AE_plotUnit))),4) AE_plotUnit,
	REPLACE(LEFT(UPPER(SiteAddress.addressLine3),20),CHAR(150),'-') servAddrLine3,
	REPLACE(LEFT(UPPER(SiteAddress.addressLine5),40),CHAR(150),'-') servAddrLine5, 
    REPLACE(LEFT(UPPER(SiteAddress.addressLine7),40),CHAR(150),'-') servAddrLine7,
	REPLACE(LEFT(UPPER(SiteAddress.addressLine9),40),CHAR(150),'-') servAddrLine9,
    REPLACE(LEFT(UPPER(SiteAddress.addressLine8),40),CHAR(150),'-') servAddrLine8,
	        LEFT(UPPER(SiteAddress.postCode),10) servAddrPostCode, 
	substring(isnull((SELECT top 1 REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(UPPER(Note_Text),CHAR(13),' '),CHAR(10),' '),CHAR(9),' '),CHAR(124),' '),CHAR(150),'-') FROM BT_ALL_NOTE 
			WHERE Note_ParentTable in( 'activityEvent','BT_CTK_HEADER')
			and Note_ParentID = act.ae_aeid
			and Note_Deleted = 'N'
			and Note_Usage = (select top 1 LOV_VALUE from MT_SYS_LOV where LOV_NAME = 'sysNoteUsage' and LOV_DESC = 'MPAN Site Location' and LOV_DELETED = 0)
			order by Note_DateCreated desc),''),1,255) servAddrDescr, -- description of Service address
	--LEFT(UPPER(SiteAddress.siteName),255)servAddrDescr, --changed for CTK site location
    ISNULL(LEFT(UPPER(SiteAddress.easting),10),'') servAddrEasting,
	ISNULL(LEFT(UPPER(SiteAddress.northing),10),'') servAddrNorthing,

	REPLACE(LEFT(UPPER(isnull(cont.con_forename,'') + ' ' +	isnull(cont.con_surname,'')),20),CHAR(150),'-') contactName,
	REPLACE(LEFT(UPPER(cont.con_jobTitle),40),CHAR(150),'-') jobTitle, 
	REPLACE(LEFT(UPPER(cust.CUST_ORG_NAME),40),CHAR(150),'-') custName,    
	REPLACE(LEFT(UPPER(Act.AE_relativeName),40),CHAR(150),'-') taskTitle,
	--REPLACE(LEFT(UPPER(CustomerAddress.addressLine3),40),CHAR(150),'-') custAddrLine3,
	--REPLACE(LEFT(UPPER(CustomerAddress.addressLine3),40),CHAR(150),'-') custAddrLine3,
	--REPLACE(LEFT(UPPER(CustomerAddress.addressLine5),40),CHAR(150),'-') custAddrLine5, 
 --   REPLACE(LEFT(UPPER(CustomerAddress.addressLine7),40),CHAR(150),'-') custAddrLine7,
	--REPLACE(LEFT(UPPER(CustomerAddress.addressLine9),40),CHAR(150),'-') custAddrLine9,
 --   REPLACE(LEFT(UPPER(CustomerAddress.addressLine8),40),CHAR(150),'-') custAddrLine8,
-- LEFT(UPPER(CustomerAddress.postCode),10) custAddrPostCode, 
REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine3<>'' or A.addressLine3 is null))>0 THEN CustomerAddress.addressLine3 ELSE SiteAddress.addressLine3 END),40),CHAR(150),'-') as custAddrLine3,
REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine3<>'' or A.addressLine3 is null))>0 THEN CustomerAddress.addressLine3 ELSE SiteAddress.addressLine3 END),40),CHAR(150),'-') as custAddrLine3,
REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine5<>'' or A.addressLine5 is null))>0 THEN CustomerAddress.addressLine5 ELSE SiteAddress.addressLine5 END),40),CHAR(150),'-') as custAddrLine5,
REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine7<>'' or A.addressLine7 is null))>0 THEN CustomerAddress.addressLine7 ELSE SiteAddress.addressLine7 END),40),CHAR(150),'-') as custAddrLine7,
REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine9<>'' or A.addressLine9 is null))>0 THEN CustomerAddress.addressLine9 ELSE SiteAddress.addressLine9 END),40),CHAR(150),'-') as custAddrLine9,
REPLACE(LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.addressLine8<>'' or A.addressLine8 is null))>0 THEN CustomerAddress.addressLine8 ELSE SiteAddress.addressLine8 END),40),CHAR(150),'-') as custAddrLine8,
LEFT(UPPER(CASE WHEN (SELECT COUNT(1) FROM  BT_ADDRESS_MASTER A INNER JOIN BT_CTK_HEADER B ON A.ADDRESS_ID=B.AE_correspondenceAddress
where B.AE_AEID=@ActivityID and (A.postCode<>'' or A.postCode is null))>0 THEN CustomerAddress.postCode ELSE SiteAddress.postCode END),10) as custAddrPostCode, 
    REPLACE(LEFT(UPPER(isnull(cont.con_telephone,'') + REPLACE(isnull(cont.con_telExt,''), isnull(cont.con_telExt,''), ' ext: ') +   isnull(cont.con_telExt,'')),25),CHAR(150),'-') contactPhone,
	UPPER(substring(isnull((dbo.fn_TranslateSYSLOV('MPANsysUsage',Act.AE_usage)),(dbo.fn_TranslateSYSLOV('sysUsage',Act.AE_usage))),1,20))  as AE_usage,
UPPER(substring((dbo.fn_TranslateSYSLOV('sysMeterPosition',Act.AE_meterPosition)),1,30)) as AE_meterPosition,
	UPPER(Act.AE_MPANSrequired) mpanReq,
	LEFT(ISNULL(UPPER(Act.AE_feeder),''),50) feeder,
	LEFT(ISNULL(UPPER(Act.AE_substation),''),50) substation,
	--Act.AE_noPhases as AE_noPhases, --to be removed and uncomment the below
    UPPER(isnull((dbo.fn_TranslateSYSLOV('MPANsysNoPhases',Act.AE_noPhases)) , (dbo.fn_TranslateSYSLOV('sysNoPhases',Act.AE_noPhases)))) as AE_noPhases,
	Act.AE_noWires as AE_noWires, --to be removed and uncomment the below
	--UPPER(isNull((dbo.fn_TranslateSYSLOV('MPANsysNoWires',Act.AE_noWires)),(dbo.fn_TranslateSYSLOV('sysNoWires',Act.AE_noWires)))) as AE_noWires,
	REPLACE(REPLACE(Act.AE_phaseRed, 'Y', 1),'N',0) as phaseRed,--RED
	REPLACE(REPLACE(Act.AE_phaseYellow, 'Y', 1),'N',0) as phaseYellow, --YELLOW
	REPLACE(REPLACE(Act.AE_phaseBlue, 'Y', 1),'N',0) as phaseBlue, --BLUE
        LEFT(UPPER(Act.AE_supplyCapacity),6) supCap,
	UPPER(substring(isnull((dbo.fn_TranslateSYSLOV('MPANsysSupplyVoltage',Act.AE_supplyVoltage)), (dbo.fn_TranslateSYSLOV('sysSupplyVoltage',Act.AE_supplyVoltage))),1,6)) as AE_supplyVoltage,
	UPPER(substring(isnull((dbo.fn_TranslateSYSLOV('MPANSYS_COMPANY',Act.AE_networkDistributor)),(dbo.fn_TranslateSYSLOV('SYS_COMPANY',Act.AE_networkDistributor))),1,4)) as AE_networkDistributor,
	--Act.AE_GSPGroup as AE_GSPGroup, --to be removed and uncomment the below
	UPPER(substring(isnull((dbo.fn_TranslateSYSLOV('MPANsysGSPGroup',Act.AE_GSPGroup)),(dbo.fn_TranslateSYSLOV('sysGSPGroup',Act.AE_GSPGroup))),1,2)) as AE_GSPGroup,
	[dbo].[fn_ConvDateToInt] (Act.AE_plannedEndDate) as SchedConnectDate,
	UPPER(SUBSTRING(REPLACE(REPLACE(REPLACE(Act.AE_summaryDescription, CHAR(9), ''), CHAR(13), ''), CHAR(10), ''),1,200)) as Descript,
	LEFT(ISNULL(UPPER(dbo.fn_TranslateSYSLOV('sysCTRatio', Act.AE_CTRatio)),''),6) as CTRatio, 
	UPPER(LEFT(LTRIM(RTRIM(isnull(cont.con_email,''))),50)) as ContactEmail 
FROM
	BT_CTK_HEADER Act INNER JOIN 
	BT_ENQUIRY_MASTER ENQ ON Act.AE_rootID = isnull(ENQ.AE_rootID,ENQ.AE_AEID) --AND ENQ.AE_AEID = @parentEnquiry 
	INNER JOIN
	MT_ACT_PEOPORG peop ON Act.AE_assignedToPerson = peop.peoporg_peoporgID LEFT OUTER JOIN
	BT_ADDRESS_MASTER SiteAddress ON Act.AE_address = SiteAddress.ADDRESS_ID INNER JOIN
	BT_CUSTOMER_MASTER cust ON Act.AE_customer = cust.cust_ID  LEFT OUTER JOIN
	BT_ADDRESS_MASTER CustomerAddress ON ACT.AE_correspondenceAddress = CustomerAddress.ADDRESS_ID  LEFT OUTER JOIN
	BT_CONTACTS_MASTER cont ON ENQ.AE_Contact = cont.con_contactID,
	MT_USERS u 
WHERE     (Act.AE_AEID = @ActivityID)
	AND (Act.AE_deleted = 'N')
	AND u.INT_USR_ID = @UserID

	--Select 'Step 5'

insert into BT_ACT_HIST values(
(SELECT max(hist_histid)+1 from BT_ACT_HIST WITH (UPDLOCK, HOLDLOCK))
, @ActivityID
,NULL
,(SELECT ae_internalref from BT_CTK_HEADER where ae_aeid=@ActivityID)
,13
,'dateTime'
,'MPAN Requested - File ID : ' + @FileID
,'BT_CTK_HEADER'
,'createdDate'
,NULL
,NULL
,NULL
,getdate()
,getdate()
,@UserId
,(SELECT USER_FIRSTNAME+' '+USER_LASTNAME FROM MT_USERS where INT_USR_ID = @UserId)
,NULL
,NULL )
GO
SET NOEXEC OFF
GO
