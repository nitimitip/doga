"""
templates_lib.py - ready-made forms a member can start a survey from.

Each entry is a complete, valid survey: title, description and a schema that
schema.normalise accepts. Starting from one creates an ordinary draft - the
builder can change any of it - so a template is a head start, never a lock.

The first one reproduces the paper "Remote Global Protect VPN Application
Testing Feedback Form" (sample_uploads/) question for question, which is also
the reference the builder's layout options were designed against: half-width
fields, inline Yes / No, "Other (please specify)", and a results table whose
rows the tester adds, with Y/N columns.
"""

TEMPLATES = [
    {
        'key': 'vpn_testing',
        'name': 'VPN application testing feedback',
        'blurb': 'User details, VPN experience, a per-application results '
                 'table and a sign-off outcome.',
        'title': 'Remote Global Protect VPN Application Testing Feedback Form',
        'description': 'Purpose: To confirm that business applications are '
                       'accessible and functioning correctly when connected '
                       'through the Global Protect VPN.',
        'schema': {'questions': [
            {'type': 'section', 'label': 'User information', 'help': ''},
            {'type': 'text', 'label': 'Name', 'required': True,
             'width': 'half'},
            {'type': 'text', 'label': 'Department / Profile Name',
             'required': True, 'width': 'half'},
            {'type': 'radio', 'label': 'VPN Connection Used',
             'required': True, 'layout': 'inline', 'options': ['Yes', 'No']},

            {'type': 'section', 'label': 'Overall VPN experience', 'help': ''},
            {'type': 'radio', 'required': True, 'layout': 'inline',
             'label': 'Were you able to establish a VPN connection '
                      'successfully?',
             'options': ['Yes', 'No']},
            {'type': 'radio', 'required': True, 'layout': 'inline',
             'label': 'Did all required business applications launch and '
                      'function as expected?',
             'help': '(If No, please provide details below in Application '
                     'Testing Results section)',
             'options': ['Yes', 'No']},
            {'type': 'checkbox', 'required': True, 'layout': 'inline',
             'allow_other': True,
             'label': 'Did you experience any performance issues while '
                      'connected via VPN?',
             'options': ['No Issues', 'Slow Application Performance',
                         'Connection Drops', 'Authentication Issues']},
            {'type': 'radio', 'required': True, 'layout': 'inline',
             'label': 'Are you satisfied that you can perform your normal '
                      'business activities remotely using the VPN service?',
             'options': ['Yes', 'Partially', 'No']},
            {'type': 'paragraph', 'label': 'Comments', 'required': False},

            {'type': 'section', 'label': 'Application testing results',
             'help': 'For each application tested, please provide your '
                     'feedback.'},
            # No fixed App #1..#3 rows: each tester adds one row per
            # application they tested.
            {'type': 'table', 'required': False,
             'label': 'Application testing results',
             'columns': ['Application Name',
                         'Successfully Accessed via VPN? (Y/N)',
                         'Application Functionality Verified? (Y/N)',
                         'Comments / Issues Identified'],
             'column_types': ['text', 'yesno', 'yesno', 'text']},

            {'type': 'section', 'label': 'Sign-off', 'help': ''},
            {'type': 'radio', 'label': 'Sign-off Outcome', 'required': True,
             'layout': 'stacked',
             'options': ['Passed - Applications accessible and functioning '
                         'as expected',
                         'Passed with Minor Issues',
                         'Failed - Further investigation required']},
        ],
            # The paper form's USER ACCEPTANCE CONFIRMATION, as the standard
            # acknowledgement block: statement, confirm, User Name, Date and
            # Comments / Issues Identified.
            'acknowledgement': {
                'enabled': True,
                'heading': 'User acceptance confirmation',
                'statement': 'I confirm that I have tested the applications '
                             'listed above while connected through the '
                             'Remote User VPN service and have provided '
                             'accurate feedback based on my testing.',
                'comments': True,
                'comments_label': 'Comments / Issues Identified',
            }},
    },
    {
        'key': 'satisfaction',
        'name': 'Service satisfaction',
        'blurb': 'A rating table across service areas, plus what went well '
                 'and what to improve.',
        'title': 'Service Satisfaction Survey',
        'description': 'Tell us how the service has worked for you over the '
                       'last month. It takes about three minutes.',
        'schema': {'questions': [
            {'type': 'text', 'label': 'Team / Department', 'required': False,
             'width': 'half'},
            {'type': 'dropdown', 'label': 'How often do you use the service?',
             'required': True, 'width': 'half',
             'options': ['Daily', 'Weekly', 'Monthly', 'Rarely']},
            {'type': 'grid', 'required': True,
             'label': 'How satisfied are you with each of the following?',
             'row_header': 'Service area',
             'rows': ['Response time', 'Quality of resolution',
                      'Communication', 'Ease of raising a request'],
             'columns': ['Very poor', 'Poor', 'Neutral', 'Good',
                         'Excellent']},
            {'type': 'paragraph', 'label': 'What went well?',
             'required': False},
            {'type': 'paragraph', 'label': 'What should we improve?',
             'required': False},
        ]},
    },
]

BY_KEY = dict((t['key'], t) for t in TEMPLATES)
