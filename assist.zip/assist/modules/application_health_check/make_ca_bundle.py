"""make_ca_bundle.py - build the PEM file that CORPORATE_CA_BUNDLE points at.

Connects to one or more monitored HTTPS endpoints, collects the certificate
chain above each leaf (intermediates + root), writes every distinct CA once as
PEM and - unless told not to - appends certifi's public root store.

That last step is the whole point. requests treats verify=<path> as a
REPLACEMENT trust store, not an addition: a bundle holding only the internal
root makes every public HTTPS monitor in this install start failing. The
combined bundle keeps both working.

CORPORATE_CA_BUNDLE is a single file for the whole install, so every endpoint
the monitor checks has to be covered by it. Endpoints on different hosts or
ports usually share one issuing CA - the bundle trusts the CA, not the server,
so a single URL is often enough. Pass every URL anyway: the chains are merged
(each CA written once, de-duplicated by SHA-256 fingerprint) and each URL is
verified against the finished bundle, which is what proves coverage.

Servers usually send their intermediates but not the root, so the root is
looked up in the Windows certificate stores. Run this ON the monitoring host
(SV301077) - it is domain-joined, so the corporate CA is already installed
there by GPO, and it is where the bundle has to end up anyway.

Targets Python 3.9+ so it runs on the production Anaconda as well as on a
developer machine.

Usage:
    python make_ca_bundle.py --url https://host1.volt.local:4443/path
                             --url https://host2.volt.local:9503/path
                             --out E:\\ApplicationDashboard\\certs\\corporate-ca.pem

    python make_ca_bundle.py --url-file monitored_urls.txt --out ...
        (one URL per line; blank lines and lines starting with # are ignored)

Then set the printed path in .env and restart BOTH the IIS app pool and the
health-monitor Windows service - modules/application_health_check/utils/
common.py resolves CORPORATE_CA_BUNDLE once at import time, so a running
process never picks up the change.
"""

import argparse
import base64
import datetime
import os
import socket
import ssl
import sys
import warnings
from collections import OrderedDict
from urllib.parse import urlparse

try:
    from cryptography import x509
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import hashes
except ImportError:
    sys.exit("This script needs the 'cryptography' package: pip install cryptography")


# An endpoint that aborts the handshake over ALPN (the HTTP-version offer)
# fails in requests before any certificate is looked at. Seen on ORDS/Jetty
# listeners that will not accept urllib3's 'http/1.1' offer.
ALPN_MARKERS = ('NO_APPLICATION_PROTOCOL', 'no application protocol')
HOSTNAME_MARKERS = ('hostname mismatch', "doesn't match", 'not valid for')


# ---------------------------------------------------------------------------
# Certificate helpers
# ---------------------------------------------------------------------------

def load(der):
    """Parse a DER blob into an x509 certificate object."""
    return x509.load_der_x509_certificate(der, default_backend())


def name(x509_name):
    """Human-readable RDN string, falling back to the raw form."""
    try:
        return x509_name.rfc4514_string()
    except Exception:
        return str(x509_name)


def expiry(cert):
    """not_valid_after, tolerating the cryptography 42+ rename."""
    try:
        return cert.not_valid_after_utc.replace(tzinfo=None)
    except AttributeError:
        return cert.not_valid_after


def is_self_signed(cert):
    return cert.subject == cert.issuer


def fingerprint(der):
    return load(der).fingerprint(hashes.SHA256())


def leaf_names(cert):
    """Names a hostname check will accept: SAN DNS/IP entries, else the CN."""
    names = []
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        names.extend(san.get_values_for_type(x509.DNSName))
        names.extend(str(ip) for ip in san.get_values_for_type(x509.IPAddress))
    except x509.ExtensionNotFound:
        pass
    if not names:
        for attr in cert.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME):
            names.append(attr.value)
    return names


def host_matches(host, names):
    """Simplified RFC 6125 match: exact name, or a single-label wildcard."""
    host = host.lower().rstrip('.')
    for candidate in names:
        candidate = candidate.lower().rstrip('.')
        if candidate == host:
            return True
        if (candidate.startswith('*.') and '.' in host
                and host.split('.', 1)[1] == candidate[2:]):
            return True
    return False


def _der_of(entry):
    """DER bytes from a get_unverified_chain() element that is not raw bytes.

    The DER constant lives on the private _ssl module, not on ssl itself.
    """
    import _ssl
    return entry.public_bytes(_ssl.ENCODING_DER)


def to_pem(der, used_by=()):
    """Render a DER certificate as an annotated PEM block."""
    cert = load(der)
    body = base64.b64encode(der).decode('ascii')
    lines = [body[i:i + 64] for i in range(0, len(body), 64)]
    used = "# Used by: %s\n" % ", ".join(used_by) if used_by else ""
    return (
        "# Subject: %s\n"
        "# Issuer : %s\n"
        "# Expires: %s\n"
        "%s"
        "-----BEGIN CERTIFICATE-----\n%s\n-----END CERTIFICATE-----\n"
        % (name(cert.subject), name(cert.issuer),
           expiry(cert).strftime('%Y-%m-%d'), used, "\n".join(lines))
    )


# ---------------------------------------------------------------------------
# URL handling
# ---------------------------------------------------------------------------

def endpoint(url):
    """(host, port) for an https URL, or None if the URL is unusable."""
    parsed = urlparse(url)
    try:
        port = parsed.port or 443
    except ValueError:
        return None
    if parsed.scheme != 'https' or not parsed.hostname:
        return None
    return parsed.hostname, port


def read_urls(cli_urls, url_file):
    """Every URL from --url and --url-file, de-duplicated, order kept."""
    urls = list(cli_urls or [])
    if url_file:
        try:
            with open(url_file, 'r', encoding='utf-8-sig') as handle:
                for line in handle:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        urls.append(line)
        except OSError as exc:
            sys.exit("Could not read --url-file: %s" % exc)

    unique = list(OrderedDict.fromkeys(urls))
    if not unique:
        sys.exit('Give at least one --url, or a --url-file.')
    bad = [url for url in unique if endpoint(url) is None]
    if bad:
        sys.exit('Every URL must be https:// with a hostname (and a valid port). '
                 'Not usable:\n  ' + '\n  '.join(bad))
    return unique


# ---------------------------------------------------------------------------
# Step 1 - what the server presents
# ---------------------------------------------------------------------------

def fetch_from_server(host, port, timeout=15):
    """Return (leaf_der, [extra_der, ...]) straight off the TLS handshake.

    Verification is deliberately off: the whole reason we are here is that the
    chain does not validate yet. Nothing fetched is trusted blindly - it is
    matched against the Windows stores below, and the requests check at the
    end is what actually proves the bundle.
    """
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    with socket.create_connection((host, port), timeout=timeout) as raw:
        with context.wrap_socket(raw, server_hostname=host) as sock:
            leaf = sock.getpeercert(binary_form=True)
            extras = []
            # get_unverified_chain() is Python 3.10+; on 3.9 we rely purely on
            # the Windows stores to supply the intermediates. Its element type
            # is not stable across builds - some return raw DER bytes, others
            # a Certificate object - so handle both rather than trusting one.
            getter = getattr(sock, 'get_unverified_chain', None)
            if getter is not None:
                try:
                    for entry in (getter() or []):
                        extras.append(entry if isinstance(entry, bytes) else _der_of(entry))
                except Exception as exc:
                    print("  ? could not read the served chain (%s) - using the "
                          "Windows stores only." % exc)
                    extras = []
    # The served chain usually repeats the leaf as its first element.
    return leaf, [der for der in extras if der and der != leaf]


# ---------------------------------------------------------------------------
# Step 2 - what the machine already trusts
# ---------------------------------------------------------------------------

def windows_ca_pool():
    """DER certificates from the Windows ROOT and CA stores, keyed by subject.

    ssl.enum_certificates is Windows-only. On any other platform this returns
    an empty pool and the chain is built from what the server sent.
    """
    pool = {}
    if not hasattr(ssl, 'enum_certificates'):
        return pool
    # A machine store routinely holds certificates that trip cryptography's
    # RFC-5280 deprecation warnings (zero or negative serials, most often on
    # old internal CAs). We are only reading subjects here, so keep the
    # output legible instead of printing a warning per certificate.
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        for store in ('ROOT', 'CA'):
            try:
                entries = ssl.enum_certificates(store)
            except Exception:
                continue
            for der, encoding, _trust in entries:
                if encoding != 'x509_asn':
                    continue
                try:
                    pool.setdefault(name(load(der).subject), der)
                except Exception:
                    continue
    return pool


def build_chain(leaf_der, extra_ders, pool, max_depth=12):
    """Walk from the leaf up to a self-signed root, collecting the CAs.

    Issuer/subject name matching, not signature verification - good enough to
    assemble a candidate bundle, and the requests check at the end is what
    decides whether it is right.
    """
    candidates = dict(pool)
    for der in extra_ders:
        try:
            candidates.setdefault(name(load(der).subject), der)
        except Exception:
            continue

    chain = []
    seen = set()
    current = load(leaf_der)
    for _ in range(max_depth):
        if is_self_signed(current):
            break
        issuer_der = candidates.get(name(current.issuer))
        if issuer_der is None:
            print("  ! issuer not found locally: %s" % name(current.issuer))
            print("    Install the corporate CA on this machine, or run this")
            print("    script on the monitoring host where it is already trusted.")
            break
        issuer = load(issuer_der)
        issuer_fp = issuer.fingerprint(hashes.SHA256())
        if issuer_fp in seen:
            break
        seen.add(issuer_fp)
        chain.append(issuer_der)
        current = issuer
    return chain


def collect(urls, pool, force_leaf):
    """Fetch and chain every distinct host:port behind the given URLs.

    Returns (certs, used_by, unreachable):
      certs       OrderedDict fingerprint -> DER, each certificate once
      used_by     fingerprint -> ['host:port', ...] that needed it
      unreachable URLs whose endpoint could not be fetched (not covered)
    """
    endpoints = OrderedDict()
    for url in urls:
        endpoints.setdefault(endpoint(url), []).append(url)

    certs = OrderedDict()
    used_by = {}
    unreachable = []
    for (host, port), members in endpoints.items():
        label = "%s:%s" % (host, port)
        print("\nConnecting to %s ..." % label)
        try:
            leaf_der, extra_ders = fetch_from_server(host, port)
        except OSError as exc:  # timeouts, refusals and ssl.SSLError alike
            print("  ! could not connect (%s) - NOT included in the bundle." % exc)
            unreachable.extend(members)
            continue

        leaf = load(leaf_der)
        print("  leaf: %s" % name(leaf.subject))
        names = leaf_names(leaf)
        if names and not host_matches(host, names):
            print("  ! '%s' is not a name on this certificate (%s)." % (host, ", ".join(names)))
            print("    Hostname checks will fail - monitor it by one of those names instead.")
        print("  server also sent %d intermediate(s)" % len(extra_ders))

        chain = build_chain(leaf_der, extra_ders, pool)
        include_leaf = force_leaf
        if not chain:
            print('  ! No CA found above the leaf - treating the endpoint as self-signed.')
            include_leaf = True

        for der in ([leaf_der] if include_leaf else []) + chain:
            fp = fingerprint(der)
            cert = load(der)
            if fp in certs:
                print("  = %s  (already in the bundle)" % name(cert.subject))
            else:
                certs[fp] = der
                print("  + %s  (expires %s)" % (name(cert.subject),
                                               expiry(cert).strftime('%Y-%m-%d')))
            if label not in used_by.setdefault(fp, []):
                used_by[fp].append(label)
    return certs, used_by, unreachable


# ---------------------------------------------------------------------------
# Step 3 - prove it before anyone edits .env
# ---------------------------------------------------------------------------

def raw_tls_trust(host, port, bundle_path, timeout=15):
    """Chain + hostname check against the bundle with NO ALPN offered.

    Returns None when trusted, otherwise the exception. Used to tell an
    ALPN-refusing server apart from a bundle that genuinely does not cover it.
    """
    context = ssl.create_default_context(cafile=bundle_path)
    try:
        with socket.create_connection((host, port), timeout=timeout) as raw:
            with context.wrap_socket(raw, server_hostname=host):
                return None
    except Exception as exc:
        return exc


def trust_note(text):
    """One-line explanation for a trust failure's message."""
    if any(marker in text for marker in HOSTNAME_MARKERS):
        return ('The URL hostname is not a name on the certificate - use the '
                'name the certificate was issued to (usually the FQDN).')
    return 'The bundle does not cover this endpoint.'


def verify(urls, bundle_path, public_probe):
    """Re-run the real request path for every URL against the new bundle.

    Returns (ok, alpn_blocked). Only a trust failure makes ok False. A
    timeout, refused connection or proxy error says nothing about trust - a
    locked-down monitoring host routinely cannot reach the public probe at
    all - so those are reported but do not fail the run. An ALPN refusal is
    re-checked over raw TLS: if that trusts, the bundle is right and the
    endpoint is listed in alpn_blocked as a server-side problem.
    """
    try:
        import requests
    except ImportError:
        print('  ?    requests is not installed here - skipping verification.')
        return True, []

    def probe(target):
        """'ok' | 'fail' | 'alpn' | 'unreachable'."""
        try:
            response = requests.get(target, verify=bundle_path, timeout=20,
                                    allow_redirects=False)
            print("  OK   %s - HTTP %s" % (target, response.status_code))
            return 'ok'
        except requests.exceptions.SSLError as exc:
            text = str(exc)
            if any(marker in text for marker in ALPN_MARKERS):
                return 'alpn'
            print("  FAIL %s: %s" % (target, text))
            print("       %s" % trust_note(text))
            return 'fail'
        except Exception as exc:
            print("  ?    %s could not be reached (%s)." % (target, exc))
            print('       Not a trust failure - the bundle was not disproved.')
            return 'unreachable'

    ok = True
    alpn_blocked = []
    for url in urls:
        outcome = probe(url)
        if outcome == 'fail':
            ok = False
        elif outcome == 'alpn':
            host, port = endpoint(url)
            error = raw_tls_trust(host, port, bundle_path)
            if error is None:
                print("  OK*  %s - trusted, but the server refused requests' "
                      "HTTP/1.1 ALPN offer." % url)
                alpn_blocked.append(url)
            else:
                print("  FAIL %s: %s" % (url, error))
                print("       %s" % trust_note(str(error)))
                ok = False

    target_hosts = {endpoint(url)[0].lower() for url in urls}
    probe_host = (urlparse(public_probe).hostname or '').lower() if public_probe else ''
    if public_probe and probe_host in target_hosts:
        print('  -    public probe skipped: same host as a target.')
    elif public_probe:
        if probe(public_probe) == 'fail':
            print('       This bundle breaks public HTTPS monitors. Re-run '
                  'without --no-public-roots.')
            ok = False
    return ok, alpn_blocked


# ---------------------------------------------------------------------------

def report_unreachable(unreachable):
    """List the URLs whose CAs are missing because they could not be fetched."""
    if not unreachable:
        return
    print('\nNOT covered - these could not be reached, so their CAs are not in the')
    print('bundle. Re-run with them included once they are reachable:')
    for url in unreachable:
        print("  %s" % url)


def main(argv=None):
    parser = argparse.ArgumentParser(
        description='Build a CORPORATE_CA_BUNDLE PEM from one or more monitored '
                    'HTTPS endpoints.')
    parser.add_argument('--url', action='append', default=[],
                        help='A monitored HTTPS endpoint. Repeat for every endpoint '
                             'the bundle must cover (any host, any port).')
    parser.add_argument('--url-file',
                        help='Text file of monitored URLs, one per line; blank lines '
                             'and # comments are ignored. Combines with --url.')
    parser.add_argument('--out', default='corporate-ca.pem',
                        help='Destination PEM (default: ./corporate-ca.pem).')
    parser.add_argument('--no-public-roots', action='store_true',
                        help='Do not append certifi. Only safe when EVERY monitored '
                             'HTTPS target is issued internally.')
    parser.add_argument('--include-leaf', action='store_true',
                        help="Also write each server's own certificate. Set "
                             'automatically for an endpoint that is self-signed '
                             'with no CA above it.')
    parser.add_argument('--skip-verify', action='store_true',
                        help='Write the bundle without testing it.')
    parser.add_argument('--public-probe', default='https://www.google.com',
                        help='Public HTTPS URL used to confirm the bundle has not '
                             'broken externally-issued monitors. Point it at any '
                             'public site this host can reach, or pass an empty '
                             'string to skip that check.')
    args = parser.parse_args(argv)

    urls = read_urls(args.url, args.url_file)
    print("%d URL(s) to cover." % len(urls))

    pool = windows_ca_pool()
    print("windows trust stores: %d CA certificate(s)" % len(pool))
    if not pool and os.name == 'nt':
        print("! Could not read the Windows stores - roots may be missing.")

    certs, used_by, unreachable = collect(urls, pool, args.include_leaf)
    if not certs:
        sys.exit('\nNothing to export - no endpoint could be read.')

    covered = [url for url in urls if url not in unreachable]
    stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    parts = [
        '# Corporate CA bundle for CORPORATE_CA_BUNDLE\n'
        '# Generated %s from:\n%s'
        '# Regenerate with make_ca_bundle.py before the certificates below expire.\n\n'
        % (stamp, ''.join('#   %s\n' % url for url in covered))
    ]
    for fp, der in certs.items():
        parts.append(to_pem(der, used_by.get(fp, ())) + "\n")

    print()
    if args.no_public_roots:
        print('! Public roots omitted - every monitored HTTPS target must now be')
        print('  issued by the CAs above, or its check will fail.')
    else:
        try:
            import certifi
        except ImportError:
            sys.exit('certifi is not installed. pip install certifi, or pass --no-public-roots.')
        print("+ public roots from %s" % certifi.where())
        parts.append('# ---- certifi public roots ----\n')
        with open(certifi.where(), 'r', encoding='ascii', errors='replace') as handle:
            parts.append(handle.read())

    out_dir = os.path.dirname(os.path.abspath(args.out))
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    # PEM is ASCII by definition, and a BOM breaks OpenSSL-style parsers.
    with open(args.out, 'w', encoding='ascii', errors='replace', newline='\n') as handle:
        handle.write(''.join(parts))

    resolved = os.path.abspath(args.out)
    print("\nWrote %s (%d certificate(s) from %d endpoint URL(s))"
          % (resolved, len(certs), len(covered)))

    alpn_blocked = []
    if not args.skip_verify and covered:
        print('Verifying ...')
        ok, alpn_blocked = verify(covered, resolved, args.public_probe)
        if not ok:
            report_unreachable(unreachable)
            print('\nVerification failed - do NOT point CORPORATE_CA_BUNDLE at this file yet.')
            return 1

    if alpn_blocked:
        print('\nThe bundle trusts these, but they refuse the HTTP/1.1 ALPN offer that')
        print('requests sends, so the health monitor will still fail them. Ask the')
        print('server owners to accept http/1.1 in ALPN on these listeners:')
        for url in alpn_blocked:
            print("  %s" % url)

    if unreachable:
        report_unreachable(unreachable)
        print('\nDo not point CORPORATE_CA_BUNDLE at this file until they are covered.')
        return 1

    print('\nSet this in .env, then restart BOTH the IIS app pool and the')
    print('health-monitor Windows service:')
    print("  CORPORATE_CA_BUNDLE=%s" % resolved)
    return 0


if __name__ == '__main__':
    sys.exit(main())
