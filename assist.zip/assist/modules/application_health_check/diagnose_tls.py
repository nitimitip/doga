"""diagnose_tls.py - why does a monitored URL fail the TLS handshake?

Runs the same URL through every layer the health check uses and prints what
each one does, so an ALPN refusal, a trust failure, a hostname mismatch and
"the new code is not deployed / not restarted" can be told apart.

Run it ON the monitoring host, from the appassist_v1 folder, with the SAME
Python the health-monitor service uses (e.g. E:\\Anaconda3\\python.exe):

    python modules\\application_health_check\\diagnose_tls.py https://sv930001.volt.local:9503/ords/durabill/f?p=9002

The CA bundle defaults to CORPORATE_CA_BUNDLE (from the environment or .env);
override it with --bundle path\\to\\corporate-ca.pem. Read-only: it makes a
few GET requests and changes nothing.
"""

import argparse
import importlib.util
import inspect
import os
import socket
import ssl
import sys
from urllib.parse import urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))


def env_bundle():
    """CORPORATE_CA_BUNDLE from the environment, else from ROOT/.env."""
    value = (os.environ.get('CORPORATE_CA_BUNDLE') or '').strip()
    if value:
        return value
    try:
        with open(os.path.join(ROOT, '.env'), 'r', encoding='utf-8-sig') as handle:
            for line in handle:
                line = line.strip()
                if line.startswith('CORPORATE_CA_BUNDLE='):
                    return line.split('=', 1)[1].strip().strip('"\'')
    except OSError:
        pass
    return ''


def raw_handshake(host, port, alpn, bundle):
    """One TLS handshake with plain ssl. bundle=None means no verification."""
    if bundle is None:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    else:
        context = ssl.create_default_context(cafile=bundle)
    if alpn:
        context.set_alpn_protocols(alpn)
    try:
        with socket.create_connection((host, port), timeout=15) as raw:
            with context.wrap_socket(raw, server_hostname=host) as sock:
                return 'OK   (ALPN selected: %s, %s)' % (sock.selected_alpn_protocol(), sock.version())
    except Exception as exc:
        return 'FAIL %s: %s' % (type(exc).__name__, exc)


def load_secure_http():
    """The deployed secure_http.py, loaded by path (skips the Flask package)."""
    path = os.path.join(HERE, 'utils', 'secure_http.py')
    spec = importlib.util.spec_from_file_location('diag_secure_http', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return path, module


def main():
    parser = argparse.ArgumentParser(description='Diagnose a health-check TLS failure.')
    parser.add_argument('url')
    parser.add_argument('--bundle', help='CA bundle PEM (default: CORPORATE_CA_BUNDLE).')
    args = parser.parse_args()

    parsed = urlparse(args.url)
    if parsed.scheme != 'https' or not parsed.hostname:
        sys.exit('Give an https:// URL.')
    host, port = parsed.hostname, parsed.port or 443
    bundle = args.bundle or env_bundle() or None

    print('== Environment')
    print('  python   :', sys.executable, sys.version.split()[0])
    print('  openssl  :', ssl.OPENSSL_VERSION)
    try:
        import requests
        import urllib3
        print('  requests :', requests.__version__, '| urllib3:', urllib3.__version__)
        try:
            from urllib3.util import ssl_ as u3ssl
            print('  pyOpenSSL injected:', bool(getattr(u3ssl, 'IS_PYOPENSSL', False)))
        except Exception:
            pass
    except ImportError as exc:
        sys.exit('requests/urllib3 missing: %s' % exc)
    print('  bundle   :', bundle or '(none - default trust store)')
    if bundle and not os.path.isfile(bundle):
        print('  ! bundle file does not exist')
    try:
        print('  resolves :', host, '->', sorted({r[4][0] for r in socket.getaddrinfo(host, port)}))
    except Exception as exc:
        sys.exit('  DNS failed for %s: %s' % (host, exc))

    print('\n== 1. Raw TLS handshakes (plain ssl, no requests)')
    print('  no ALPN,  no verify      :', raw_handshake(host, port, None, None))
    print('  ALPN http/1.1, no verify :', raw_handshake(host, port, ['http/1.1'], None))
    print('  ALPN h2+http/1.1         :', raw_handshake(host, port, ['h2', 'http/1.1'], None))
    if bundle:
        print('  no ALPN, verify w/ bundle:', raw_handshake(host, port, None, bundle))

    print('\n== 2. Deployed code')
    url_check = os.path.join(HERE, 'utils', 'url_check.py')
    with open(url_check, 'r', encoding='utf-8') as handle:
        has_fallback = '_NO_ALPN_ENDPOINTS' in handle.read()
    print('  url_check.py has ALPN fallback :', has_fallback, '(%s)' % url_check)
    path, secure_http = load_secure_http()
    has_param = 'alpn' in inspect.signature(secure_http.new_session).parameters
    print('  secure_http.py has alpn=False  :', has_param, '(%s)' % path)
    if not (has_fallback and has_param):
        print('  ! The new files are NOT in this folder - copy them here, then restart')
        print('    the IIS app pool and the health-monitor service.')

    print('\n== 3. requests through the health-check transport')
    # Skip the SSRF allowlist so this works without .env; pinning is unchanged.
    secure_http.approved_addresses = lambda h, p: [socket.getaddrinfo(h, p, type=socket.SOCK_STREAM)[0][4][0]]
    modes = [('with ALPN   ', {})]
    if has_param:
        modes.append(('without ALPN', {'alpn': False}))
    for label, kwargs in modes:
        session = secure_http.new_session(**kwargs)
        try:
            response = session.get(args.url, verify=bundle or True, timeout=20,
                                   allow_redirects=False, stream=True)
            print('  %s: OK   HTTP %s' % (label, response.status_code))
            response.close()
        except Exception as exc:
            print('  %s: FAIL %s: %s' % (label, type(exc).__name__, exc))
        finally:
            session.close()

    print('\nSend this whole output back for analysis.')


if __name__ == '__main__':
    main()
