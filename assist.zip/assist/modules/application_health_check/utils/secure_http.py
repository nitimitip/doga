"""HTTP transport which validates and pins each connection's destination IP.

TLS SNI and hostname verification still use the original hostname. Automatic
redirects and environment proxies are disabled by the caller.

new_session(alpn=False) builds the same pinned transport without the TLS ALPN
extension, for listeners that abort the handshake over urllib3's 'http/1.1'
offer ("tlsv1 alert no application protocol" - seen on ORDS/Jetty ports).
Certificate and hostname verification are unchanged; only the offer goes.
"""
import ipaddress
import os
import socket
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3 import PoolManager
from urllib3.connection import HTTPConnection, HTTPSConnection
from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool
from urllib3.util.connection import create_connection
from urllib3.util.ssl_ import create_urllib3_context, resolve_cert_reqs


def approved_addresses(host, port):
    allowed_hosts = {h.strip().lower().rstrip('.') for h in os.environ.get('HEALTH_ALLOWED_HOSTS', '').split(',') if h.strip()}
    networks = [ipaddress.ip_network(n.strip()) for n in os.environ.get('HEALTH_ALLOWED_NETWORKS', '').split(',') if n.strip()]
    rows = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    addresses = list(dict.fromkeys(row[4][0] for row in rows))
    if not addresses:
        raise ValueError('Target has no resolved addresses.')
    for address in addresses:
        ip = ipaddress.ip_address(address)
        # Metadata, local host and multicast targets are never monitoring targets.
        if ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified or ip.is_reserved:
            raise ValueError('Target resolves to a prohibited address.')
        permitted_network = any(ip in network for network in networks)
        if not ip.is_global and not permitted_network:
            raise ValueError('Private target requires HEALTH_ALLOWED_NETWORKS.')
        if allowed_hosts and host.lower().rstrip('.') not in allowed_hosts:
            raise ValueError('Host is outside HEALTH_ALLOWED_HOSTS.')
    return addresses


def validate_url(url):
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        raise ValueError('Use an HTTP or HTTPS URL with a hostname.')
    if parsed.username or parsed.password:
        raise ValueError('Credentials must not be embedded in URLs.')
    port = parsed.port or (443 if parsed.scheme == 'https' else 80)
    if not 1 <= port <= 65535:
        raise ValueError('Invalid target port.')
    approved_addresses(parsed.hostname, port)
    return parsed


class _PinnedConnection:
    def _new_conn(self):
        last_error = None
        for address in approved_addresses(self.host, self.port):
            try:
                return create_connection((address, self.port), timeout=self.timeout,
                                         source_address=self.source_address,
                                         socket_options=self.socket_options)
            except OSError as exc:
                last_error = exc
        raise last_error or OSError('Unable to connect to approved target.')


class _HTTP(_PinnedConnection, HTTPConnection):
    pass


class _HTTPS(_PinnedConnection, HTTPSConnection):
    pass


class _HTTPSNoALPN(_HTTPS):
    """Pinned HTTPS connection that sends no ALPN offer.

    urllib3 calls set_alpn_protocols() on whatever context it wraps with, a
    caller-supplied one included, so the offer is suppressed on a fresh
    per-connection context rather than by patching urllib3's module-wide
    ALPN_PROTOCOLS (that would change every other client in the process).
    The context mirrors urllib3's own default: same cert_reqs and hostname
    checking, and requests still passes the CA bundle through ca_certs.
    """

    def connect(self):
        context = create_urllib3_context(cert_reqs=resolve_cert_reqs(self.cert_reqs))
        if not (self.ca_certs or self.ca_cert_dir or getattr(self, 'ca_cert_data', None)):
            context.load_default_certs()
        context.set_alpn_protocols = lambda protocols: None
        self.ssl_context = context
        super().connect()


class _HTTPPool(HTTPConnectionPool):
    ConnectionCls = _HTTP


class _HTTPSPool(HTTPSConnectionPool):
    ConnectionCls = _HTTPS


class _HTTPSNoALPNPool(HTTPSConnectionPool):
    ConnectionCls = _HTTPSNoALPN


class _Adapter(HTTPAdapter):
    https_pool = _HTTPSPool

    def init_poolmanager(self, connections, maxsize, block=False, **kwargs):
        self.poolmanager = PoolManager(num_pools=connections, maxsize=maxsize, block=block, **kwargs)
        self.poolmanager.pool_classes_by_scheme = {'http': _HTTPPool, 'https': self.https_pool}


class _NoALPNAdapter(_Adapter):
    https_pool = _HTTPSNoALPNPool


def new_session(alpn=True):
    adapter = _Adapter if alpn else _NoALPNAdapter
    session = requests.Session()
    session.trust_env = False
    session.mount('http://', adapter())
    session.mount('https://', adapter())
    return session
