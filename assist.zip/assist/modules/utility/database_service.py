import os
import re
import logging
import pandas as pd

# Database drivers are imported lazily inside the methods that need them.
# This keeps the module importable on machines where only one driver
# (or neither) is installed - for example a deployment that only ever
# talks to SQL Server should not require an Oracle driver to be present.
from crypto_utils import decrypt_data, CredentialDecryptionError
from .servers_models import DatabaseReport


# ---------------------------------------------------------------------------
# Execution limits
# ---------------------------------------------------------------------------
# A report query runs inside an IIS worker. Without a statement timeout a slow
# or blocked query holds that worker for as long as the server takes; without
# a row bound a careless SELECT loads a whole table into the worker's memory.
# Both are enforced by the DRIVER, not by this process watching a clock.
QUERY_TIMEOUT_SECONDS = int(os.environ.get('UTILITY_QUERY_TIMEOUT_SECONDS', '60'))
MAX_ROWS = int(os.environ.get('UTILITY_MAX_ROWS', '50000'))
FETCH_BATCH = 2000

# Encrypt=yes and a VERIFIED server certificate, the same stance as the
# health-check probe. A server with a self-signed certificate needs its CA in
# the web server's trust store; UTILITY_MSSQL_TRUST_SERVER_CERTIFICATE=yes is
# the documented escape hatch, off by default.
_TRUST_SERVER_CERT = os.environ.get(
    'UTILITY_MSSQL_TRUST_SERVER_CERTIFICATE', 'no').strip().lower() in (
        '1', 'yes', 'true')


class QueryRejected(ValueError):
  """The configured SQL, or its result, is outside what Utility will run."""


def _report_password(report):
  """Plain-text password for a report connection.

  New rows store the password encrypted (routes.save_report). Rows saved
  before that fix hold plain text, so fall back to the stored value when
  no known key can decrypt it -- those rows keep working until re-saved.
  """
  stored = report.password or ''
  try:
    return decrypt_data(stored)
  except CredentialDecryptionError:
    return stored


def _odbc_value(value):
  """Brace-quote one ODBC connection-string value.

  Without it a password containing ';' ends the PWD attribute early and the
  rest of the password is parsed as further attributes of the caller's
  choosing. Same escaping as the health-check probe.
  """
  return '{' + str(value if value is not None else '').replace('}', '}}') + '}'


def _mssql_driver():
  return os.environ.get('MSSQL_ODBC_DRIVER', 'ODBC Driver 17 for SQL Server')


def _mssql_connection_string(report):
  return (
    f"DRIVER={{{_mssql_driver()}}};"
    f"SERVER={_odbc_value(str(report.connection_host) + ',' + str(report.connection_port))};"
    f"DATABASE={_odbc_value(report.database_name)};"
    f"UID={_odbc_value(report.username)};"
    f"PWD={_odbc_value(_report_password(report))};"
    f"Encrypt=yes;"
    f"TrustServerCertificate={'yes' if _TRUST_SERVER_CERT else 'no'};"
  )


def _import_pyodbc():
    try:
        import pyodbc
        return pyodbc
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(
            "The 'pyodbc' package is required for SQL Server connections. "
            "Install it with: pip install pyodbc"
        ) from exc


def _import_oracle():
    # get_oracle_driver() prefers python-oracledb (auto thick/thin - thin
    # needs no Oracle Client install, avoiding DPI-1047) and falls back to
    # cx_Oracle where oracledb is not installed.
    try:
        from oracle_client import get_oracle_driver
        return get_oracle_driver()
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(
            "An Oracle driver is required for Oracle connections. "
            "Install one with: pip install oracledb"
        ) from exc


def _bounded_frame(cursor, max_rows=None):
  """Fetch at most max_rows rows from an executed cursor into a DataFrame.

  Raises QueryRejected when the result is larger: handing back the first N
  rows of an unordered result as if they were the data would be silently
  wrong, so the operator is told to narrow the query instead.
  """
  limit = MAX_ROWS if max_rows is None else max_rows
  if cursor.description is None:
    raise QueryRejected('The query returned no result set.')
  columns = [d[0] for d in cursor.description]
  rows = []
  while True:
    batch = cursor.fetchmany(FETCH_BATCH)
    if not batch:
      break
    rows.extend(tuple(r) for r in batch)
    if len(rows) > limit:
      raise QueryRejected(
        f'The query returned more than {limit} rows. Narrow it with a '
        f'WHERE clause (limit: UTILITY_MAX_ROWS).')
  return pd.DataFrame.from_records(rows, columns=columns)


# ---------------------------------------------------------------------------
# Query validation
# ---------------------------------------------------------------------------
# THIS IS A GUARD RAIL, NOT THE SECURITY BOUNDARY. The boundary is the
# database account each report connects as, which must be a dedicated login
# with SELECT (and nothing else) on what the report needs. The checks below
# stop the obvious mistakes and the known ways a SELECT can still write, lock
# or reach another server; the connection is ALSO rolled back on close (and
# Oracle runs the statement inside SET TRANSACTION READ ONLY).

_STRING_OR_COMMENT = re.compile(
  r"'(?:[^']|'')*'"          # 'string' with '' escapes
  r"|N'(?:[^']|'')*'"        # N'unicode string'
  r"|--[^\n]*"               # -- line comment
  r"|/\*.*?\*/",             # /* block comment */
  re.DOTALL)

# Statement keywords that have no place in a read-only report.
_BLOCKED_WORDS = (
  'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 'ALTER', 'TRUNCATE',
  'EXEC', 'EXECUTE', 'MERGE', 'GRANT', 'REVOKE', 'DENY', 'COMMIT',
  'ROLLBACK', 'CALL', 'DECLARE', 'WAITFOR', 'DBCC', 'BACKUP', 'RESTORE',
  'BULK', 'SHUTDOWN', 'KILL', 'RECONFIGURE', 'LOCK', 'RENAME', 'UPSERT',
  # SELECT ... INTO creates a table.
  'INTO',
  # Reaching another server or the file system from inside a SELECT.
  'OPENROWSET', 'OPENQUERY', 'OPENDATASOURCE', 'OPENXML',
  # Table hints that take or hold stronger locks than a plain read. NOLOCK /
  # READUNCOMMITTED stay allowed - they take fewer locks, not more.
  'TABLOCK', 'TABLOCKX', 'HOLDLOCK', 'UPDLOCK', 'XLOCK', 'PAGLOCK',
  'ROWLOCK', 'SERIALIZABLE', 'REPEATABLEREAD',
)
_BLOCKED_RE = re.compile(r'\b(' + '|'.join(_BLOCKED_WORDS) + r')\b')
# Oracle row locking.
_FOR_UPDATE_RE = re.compile(r'\bFOR\s+UPDATE\b')
# Four-part name (linked server): part.part.part.part, parts bare or [quoted].
_PART = r'(?:\[[^\]]*\]|"[^"]*"|\w+)'
_FOUR_PART_RE = re.compile(_PART + r'?\.' + _PART + r'?\.' + _PART + r'?\.' + _PART)
# Oracle database link: table@link.
_DBLINK_RE = re.compile(r'[\w"\]]@\w')


def _strip_literals(sql):
  """SQL with string literals and comments blanked out.

  Keywords inside a string ('please DELETE me') are not statements and must
  not be flagged; keywords hidden inside a comment are dropped by the server
  and must not be able to smuggle a ';' past the stacked-statement check.
  """
  return _STRING_OR_COMMENT.sub(' ', sql)


class DatabaseService:
  def __init__(self):
    self.logger = logging.getLogger(__name__)

  def execute_query(self, report, errors=None):
    """
    Execute SQL query from database report configuration.

    Returns a DataFrame, or None on failure. When ``errors`` is a list, a
    message fit to show the operator is appended to it on failure.
    """
    try:
      if report is None:
        self.logger.error("execute_query called with no report")
        return None
      if report.database_type == 'mssql':
        return self._execute_mssql_query(report)
      elif report.database_type == 'oracle':
        return self._execute_oracle_query(report)
      else:
        self.logger.error(f"Unsupported database type: {report.database_type}")
        if errors is not None:
          errors.append(f"Unsupported database type: {report.database_type}")
        return None
    except QueryRejected as e:
      self.logger.warning(f"Report query rejected: {e}")
      if errors is not None:
        errors.append(str(e))
      return None
    except Exception as e:
      self.logger.error(f"Database query execution failed: {str(e)}")
      if errors is not None:
        errors.append('The database query failed - see the application log.')
      return None

  def _checked_query(self, report):
    query = (report.sql_query or '').strip()
    is_valid, message = self.validate_query(query)
    if not is_valid:
      raise QueryRejected(message)
    return query.rstrip().rstrip(';').rstrip()

  def _execute_mssql_query(self, report):
    """
    Execute query on SQL Server database
    """
    query = self._checked_query(report)
    pyodbc = _import_pyodbc()

    # `with pyodbc.connect(...)` commits or rolls back the TRANSACTION and
    # leaves the connection OPEN - that is documented pyodbc behaviour, not
    # a bug in it. Without the explicit close below, every report run leaked
    # a connection in the long-lived IIS worker until garbage collection,
    # which shows up as pool exhaustion on the SQL Server side.
    conn = pyodbc.connect(_mssql_connection_string(report), timeout=30)
    try:
      # autocommit stays OFF: the statement runs inside a transaction that
      # is rolled back below, so anything that slipped past the validator
      # is undone and any lock it took is released at the end of the call.
      # The statement timeout is REQUIRED - if the driver will not take it,
      # the query does not run.
      conn.timeout = QUERY_TIMEOUT_SECONDS
      if conn.timeout != QUERY_TIMEOUT_SECONDS:
        raise RuntimeError('The ODBC driver did not accept a query timeout.')
      cursor = conn.cursor()
      cursor.execute(query)
      df = _bounded_frame(cursor)
      self.logger.info(f"Successfully executed MSSQL query, returned {len(df)} rows")
      return df
    finally:
      try:
        conn.rollback()
      except Exception:
        self.logger.debug("Rolling back the MSSQL report transaction failed",
                          exc_info=True)
      try:
        conn.close()
      except Exception:
        self.logger.debug("Closing the MSSQL connection failed", exc_info=True)

  def _execute_oracle_query(self, report):
    """
    Execute query on Oracle database
    """
    query = self._checked_query(report)
    oracle = _import_oracle()

    # Build connection string (TNS format)
    dsn = f"{report.connection_host}:{report.connection_port}/{report.database_name}"

    with oracle.connect(
      user=report.username,
      password=_report_password(report),
      dsn=dsn
    ) as conn:
      try:
        # call_timeout is milliseconds and applies to every round trip.
        # Required, as for SQL Server: no timeout, no query.
        conn.call_timeout = QUERY_TIMEOUT_SECONDS * 1000
        if conn.call_timeout != QUERY_TIMEOUT_SECONDS * 1000:
          raise RuntimeError('The Oracle driver did not accept a call timeout.')
        cursor = conn.cursor()
        # Server-enforced: inside a READ ONLY transaction Oracle rejects
        # DML and SELECT ... FOR UPDATE outright (ORA-01456).
        cursor.execute("SET TRANSACTION READ ONLY")
        cursor.arraysize = FETCH_BATCH
        cursor.execute(query)
        df = _bounded_frame(cursor)
        self.logger.info(f"Successfully executed Oracle query, returned {len(df)} rows")
        return df
      finally:
        try:
          conn.rollback()
        except Exception:
          self.logger.debug("Rolling back the Oracle report transaction failed",
                            exc_info=True)

  def test_connection(self, report):
    """
    Test database connection without executing the main query
    """
    try:
      if report.database_type == 'mssql':
        return self._test_mssql_connection(report)
      elif report.database_type == 'oracle':
        return self._test_oracle_connection(report)
      else:
        return False, f"Unsupported database type: {report.database_type}"
    except Exception as e:
      return False, str(e)

  def _test_mssql_connection(self, report):
    """
    Test SQL Server connection
    """
    try:
      pyodbc = _import_pyodbc()

      # Same leak as _execute_mssql_query: pyodbc's context manager ends the
      # transaction, not the connection.
      conn = pyodbc.connect(_mssql_connection_string(report), timeout=10)
      try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        return True, "Connection successful"
      finally:
        try:
          conn.close()
        except Exception:
          self.logger.debug("Closing the MSSQL test connection failed",
                            exc_info=True)

    except Exception as e:
      return False, f"Connection failed: {str(e)}"

  def _test_oracle_connection(self, report):
    """
    Test Oracle connection
    """
    try:
      oracle = _import_oracle()
      dsn = f"{report.connection_host}:{report.connection_port}/{report.database_name}"

      with oracle.connect(
        user=report.username,
        password=_report_password(report),
        dsn=dsn
      ) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM DUAL")
        cursor.fetchone()
        return True, "Connection successful"

    except Exception as e:
      return False, f"Connection failed: {str(e)}"

  def validate_query(self, query):
    """
    Validate SQL query for security.

    Uses word-boundary matching so legitimate identifiers such as
    'created_at' or 'updated_by' are NOT mistaken for the keywords
    CREATE / UPDATE. String literals and comments are blanked before any
    check, so a keyword quoted in data is allowed and one hidden in a comment
    cannot carry a statement separator. See the block comment above
    _BLOCKED_WORDS: this is a guard rail, the read-only login is the boundary.
    """
    if not query or not query.strip():
      return False, "Query is empty"

    code = _strip_literals(query.strip())
    if "'" in code or '/*' in code:
      # An unterminated literal or comment - the rest of the text cannot be
      # classified reliably, so it is not run.
      return False, "Unterminated string literal or comment"
    upper = code.upper().strip()

    # Only allow SELECT statements (also allow a leading CTE: WITH ... SELECT).
    if not re.match(r'(SELECT|WITH)\b', upper):
      return False, "Only SELECT statements are allowed"

    # Reject stacked / multiple statements. Allow a single optional
    # trailing semicolon, but nothing meaningful after it.
    without_trailing = upper.rstrip().rstrip(';').rstrip()
    if ';' in without_trailing:
      return False, "Multiple SQL statements are not allowed"

    match = _BLOCKED_RE.search(upper)
    if match:
      return False, f"Keyword '{match.group(1)}' is not allowed"
    if _FOR_UPDATE_RE.search(upper):
      return False, "Keyword 'FOR UPDATE' is not allowed"
    if _FOUR_PART_RE.search(code):
      return False, "Linked-server (four-part) names are not allowed"
    if _DBLINK_RE.search(code):
      return False, "Database links (@link) are not allowed"

    return True, "Query is valid"
