"""
Rule self-test: run a rule's documented examples through the real scanner.

Every built-in rule documents a noncompliant example (must raise the rule)
and a compliant example (must not). Running them through the same per-file
analysis a scan uses turns the documentation into a regression suite: an
example that drifts from the detection logic fails the build instead of
misleading a reader.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

#: Sample file name per language when an example does not name one.
DEFAULT_FILES = {
    "aspnet": "Default.aspx", "batch": "run.bat", "c": "example.c",
    "cpp": "example.cpp", "csharp": "Example.cs", "classic_asp": "default.asp",
    "config": "app.ini", "css": "site.css", "dart": "example.dart",
    "dockerfile": "Dockerfile", "go": "example.go", "html": "index.html",
    "java": "Example.java", "javascript": "example.js", "jinja": "page.j2",
    "json": "settings.json", "kotlin": "Example.kt", "php": "example.php",
    "plsql": "pkg.pkb", "powershell": "script.ps1", "python": "example.py",
    "razor": "Index.cshtml", "rust": "example.rs", "shell": "script.sh",
    "sql": "script.sql", "swift": "Example.swift", "terraform": "main.tf",
    "typescript": "example.ts", "vbnet": "Module1.vb", "xml": "web.config",
    "yaml": "deploy.yaml",
}


def example_filename(languages, declared: str = "") -> str:
    """The file name an example is analysed as."""
    if declared:
        return declared
    for language in languages:
        if language in DEFAULT_FILES:
            return DEFAULT_FILES[language]
    return "example.py"


def rule_ids_for(code: str, filename: str, rule_engine, registry) -> set:
    """
    Rule ids raised when `code` is scanned as a file called `filename`.

    Analysed in memory under a virtual path: examples include fork bombs and
    reverse shells, which antivirus quarantines if they touch the disk.
    """
    from ..analysis.engine import analyze_file
    path = Path(tempfile.gettempdir()) / "codesentinel-selftest" / filename
    analysis = analyze_file(path, rule_engine, registry, text=code)
    return {finding.rule_id for finding in analysis.findings}


def check_examples(rule_id: str, languages, noncompliant: str, compliant: str,
                   filename: str, rule_engine, registry) -> list:
    """Problems with one rule's examples (empty list = examples are correct)."""
    problems = []
    name = example_filename(languages, filename)
    if rule_id not in rule_ids_for(noncompliant, name, rule_engine, registry):
        problems.append(f"{rule_id}: noncompliant example does not raise the rule ({name})")
    if rule_id in rule_ids_for(compliant, name, rule_engine, registry):
        problems.append(f"{rule_id}: compliant example still raises the rule ({name})")
    return problems
