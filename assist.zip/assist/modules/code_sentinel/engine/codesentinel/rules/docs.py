"""
Rule documentation lookup for report exporters.

Indexes the built-in rule packs and the analyzer catalog by rule id, so a
report can print a rule's description, examples and standards mapping next
to its findings. Pattern-pack entries win over the analyzer catalog for ids
both define (one id, one meaning). Loaded once per process.
"""

from __future__ import annotations

import json
from functools import lru_cache

from . import taxonomy
from .loader import BUILTIN_PACK_DIR

_FIELDS = ("title", "type", "cwe", "owasp", "owasp_2025", "asvs", "pci_dss",
           "description", "remediation", "status")


@lru_cache(maxsize=1)
def _index() -> dict:
    from ..analysis.rule_catalog import analyzer_rules
    index: dict = {}
    for entry in analyzer_rules():
        index[entry["id"]] = _doc(entry)
    for path in sorted(BUILTIN_PACK_DIR.glob("*.json")):
        try:
            pack = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        for entry in pack.get("rules", []):
            if isinstance(entry, dict) and entry.get("id"):
                current = index.get(entry["id"])
                # A query rule never replaces the pattern rule's documentation.
                if current is None or not current.get("_pack") or "query" not in entry:
                    index[entry["id"]] = dict(_doc(entry), _pack=True)
    return index


def _doc(entry: dict) -> dict:
    doc = {key: entry.get(key, "") for key in _FIELDS}
    doc["pci_dss"] = list(entry.get("pci_dss") or [])
    examples = entry.get("examples") or {}
    doc["noncompliant"] = examples.get("noncompliant", "")
    doc["compliant"] = examples.get("compliant", "")
    doc["type_label"] = taxonomy.TYPE_LABELS.get(doc["type"], "")
    doc["cwe_top25"] = taxonomy.in_cwe_top_25(doc["cwe"])
    return doc


def rule_docs(rule_id: str):
    """Documentation dict for one rule id, or None when it is unknown."""
    doc = _index().get(rule_id)
    if doc is None:
        return None
    return {key: value for key, value in doc.items() if not key.startswith("_")}
