# Code Sentinel rule policy - version 4.0

Reviewed 12–13 September 2026; .NET coverage pass 21 September 2026. This is the built-in pack directory.
Administrator overrides belong in CODESENTINEL_HOME/rules. Later packs
can override matching IDs. The earlier policy is preserved in the review baseline.

## Scope and evidence

Recognizing a language does not imply equivalent analysis depth. Python has
native AST and bounded taint analysis; JavaScript, TypeScript, Java and C# have
optional syntax and bounded in-file taint analysis. Go, Rust, Kotlin and Swift
have optional syntax-query checks. Other profiles use patterns and, where
implemented, specialist statement/template checks. See
artifacts/code-sentinel-review/REVIEW.md in the project root for the assessment.

No rule count, quality score, CWE reference or regression pass rate establishes
SonarQube/Veracode parity or OWASP/CERT/ASVS compliance.

## Authoring

- One stable uppercase, hyphen-separated ID must have one meaning across
  pattern and parser implementations. Match their taxonomy and remediation.
- Declare rule-level languages when narrower than the pack. Reserve universal
  rules for shared evidence such as recognizable credential formats.
- Required fields: id, severity, pattern (or query), message. Built-ins must
  also have useful titles, categories, confidence and remediation.
- Severities: BLOCKER, CRITICAL, HIGH, MEDIUM, LOW, INFO. Confidence: HIGH,
  MEDIUM, LOW. Severity describes potential impact; confidence describes the
  evidence. Neither proves exploitation. Categories use RiskCategory constants.
- match_scope=code requires the first matched token outside a string/comment.
  source retains literal evidence but normally masks comments. comments targets
  documentation markers and compiler-suppression comments. This is lexical
  filtering, not a complete language lexer.
- check_comments=true is appropriate for credential evidence, not executable
  API checks. Set ignore_case according to the language and API.
- multiline=true explicitly permits cross-line matching and multiline anchors;
  it does not enable DOTALL. Prefer syntax queries to complex regexes. Review
  worst-case runtime and add safe, unsafe, multiline, comment and string cases.
- Parser/query failures and invalid packs must surface as incomplete analysis.
  Missing optional grammars remain visible as reduced analysis depth.

## Findings and waivers

A variable URL, unsafe block, pseudorandom API, inline template or initialized
empty password is review evidence, not automatically a vulnerability. Do not
label public key identifiers as leaked authentication secrets. Give conditional
remediation when a finding depends on context.

Use an actual language comment containing nosast: RULE-ID for a same-line
waiver. A bare nosast waives every finding on that line; use it sparingly.
Text inside a string is not a waiver. Profiles and waivers apply to pattern,
AST, query and taint findings. Waiving a parser finding does not remove its
analysis-error evidence. Persisted reviewer triage is a separate mechanism.

## Compatibility

Go defer uses QRY-GO001, avoiding the URL review rule GO-P001. Kotlin query IDs
now agree with pattern IDs. Swift forced-cast syntax uses QRY-SW001. Rust
unsafe syntax uses RS-U001. Python swallowed exceptions use PY-Q001, bare
except uses PY-Q006, and credential logging retains PY-Q002.

Old ambiguous triage cannot be migrated reliably by ID alone. Review affected
waivers and run a fresh scan. The engine cache version is bumped; every rule
field and regex flag participates in invalidation. Project-wide findings are
recomputed outside the per-file cache.

## .NET coverage pass (21 September 2026)

Rules tagged `dotnet-coverage-2026-09` extend the C#/.NET profile. Each has a
safe/unsafe fixture pair in tests/fixtures/code_sentinel_dotnet_rules.json.

- csharp.json adds injection families the pattern packs did not reach (LDAP
  filters, XPath expressions, Zip Slip extraction, process argument strings,
  BSON filter parsing), run-time type/assembly loading, key-derivation and RSA
  padding strength, certificate password and revocation handling, Data
  Protection key storage, Identity password policy, SameSite, the
  trust-boundary assembly attributes, model over-posting and regex timeouts.
- dotnet_config.json covers deployed ASP.NET/IIS/MSBuild configuration:
  trace output, cookieless and non-regenerated sessions, forms-ticket
  protection, header checking, directory browsing, detailed IIS errors,
  inline impersonation credentials, legacy request validation, ASP.NET Core
  DetailedErrors and disabled analysis modes. Checks already in xml.json
  (compilation debug, customErrors, requireSSL, httpOnlyCookies,
  validateRequest, enableViewStateMac, machineKey, enableEventValidation) are
  not duplicated.
- csharp_queries.json adds parse-tree quality rules that regexes cannot state
  precisely: self-assignment, identical conditional branches, self-comparison
  and locking on an interned string literal.
- razor.json adds unencoded output and script-context interpolation.

The C# taint profile gained SSRF, LDAP, XPath and reflection sinks, property
sinks (`Filter`, `Arguments`, `CommandText`, `InnerHtml`) and per-constructor
argument selection. Generic method and property names are gated on the
receiver's declared type, so an unrelated `Filter` or `GetAsync` is suppressed.
SSRF, path and reflection findings carry their own OWASP category rather than
A03.

Scope unchanged by this pass: there is still no Roslyn semantic model, no
overload resolution across assemblies, and no VB.NET profile. A recognized
extension is not evidence of complete language support.

## Validation

Run python artifacts/code-sentinel-review/test_review.py from the project root,
and python -m unittest discover -s tests -p test_code_sentinel_dotnet.py for
the .NET suite.
The review loads isolated parser packages from its test-deps directory; these
are not installed into the web host. Set CODE_SENTINEL_NO_PARSERS=1 to test
fallback mode. Use the pinned requirements for deployment parser support.

Independent labeled applications and comparison-tool runs are required before
making effectiveness claims. These regression fixtures are not an independent
security benchmark.

## Language coverage pass (30 September 2026)

Rules tagged `lang-coverage-2026-09` (111 pattern rules) each have a safe/unsafe
pair in tests/fixtures/code_sentinel_language_rules.json.

- New language profiles: VB.NET (`.vb`, vbnet.json), Classic ASP (`.asp`,
  `.asa`, ASP-looking `.inc`; classic_asp.json) and ASP.NET Web Forms
  (`.aspx/.ascx/.master/.asmx/.ashx/.asax`; aspnet_webforms.json). Inline
  server code in Web Forms pages is also scanned with the C# or VB.NET
  pack chosen from the page directive's Language attribute.
- New packs: plsql.json (SQL/PL/SQL bugs and dangerous operations),
  embedded_sql.json (DROP/TRUNCATE, DELETE/UPDATE without WHERE and
  xp_cmdshell inside application string literals), web_common.json.
- python.json, csharp.json and shell.json gained bug, dangerous-operation and
  configuration rules.
- Code-implemented checks: analysis/pybugs.py (PY-B001..B025, definite Python
  bugs), analysis/structure_checks.py (SYN-* structural syntax for shell,
  SQL/PL/SQL, VB.NET, Classic ASP and Web Forms; PL/SQL cursor/trigger bugs;
  ASP error-suppression; C# format-string arity). analysis/rule_catalog.py
  lists every code-implemented rule id for the rule browser and scan scope.
- Shell structural syntax was validated against `bash -n` on 451 real scripts
  (0 false positives) and 693 broken mutants (96% detected).

Scan scope (domain/scope.py): a scan may be limited to languages, rule
families (syntax / bug / dangerous / security / practice) or individual
rules. Unselected languages are not analysed; analysis errors are never
filtered. Scoped scans are labelled as partial on the scan page.

## Standards metadata and rule documentation (1 October 2026, pack schema v2)

Every built-in rule now carries, in addition to the v1 fields:

- `type`: VULNERABILITY (insecure as written), SECURITY_HOTSPOT (security-
  sensitive code a reviewer must judge in context), BUG or CODE_SMELL.
  Regex rules that cannot see where data comes from (concatenated SQL,
  variable command lines, eval of a variable) are hotspots; rules whose
  pattern includes the untrusted source (Request, $_GET) or an always-unsafe
  construct (BinaryFormatter, TLS verification off) are vulnerabilities.
  Data-flow (TAINT-*) findings are vulnerabilities. The type is metadata: it
  does not change severity, scoring or the quality gate.
- `owasp` (canonical OWASP Top 10 2021 label), `owasp_2025` (follows the
  rule's 2021 category; supply-chain CWEs move to A03:2025), `asvs` (ASVS 5.0
  chapter) and `pci_dss` (PCI DSS v4.0.1 requirements). Security types must
  map to all four. Defaults come from rules/taxonomy.py (CWE -> standards);
  hand-reviewed 2021 labels are kept.
- `status` (stable / beta / deprecated with `replaced_by`) and `since`
  (pack version that introduced the rule).
- `description` (why it matters, when it is acceptable) and `examples`
  (`noncompliant`, `compliant`, optional `file`). The examples are run
  through the real scanner by tests/test_code_sentinel_rule_standards.py:
  the noncompliant example must raise the rule and the compliant one must
  not. This found and fixed two dead rules (JS-S002, JS-C002), two missed
  common forms (CS-D003, ASP-C001), two false positives (SH-D011, BAT-C005)
  and an unscanned file type (.plist, XM-C006).

CWE corrections: CWE-730 (a retired OWASP 2004 category) and catch-all
CWE-73 on literal-target destructive operations became CWE-676; CWE-73 is
kept only where the deleted path comes from a variable. Categories and
poor fits listed in taxonomy.RETIRED_CWES are rejected by the tests.

Checks implemented in code are documented in rules/analyzer_rules.json with
the same fields (plus `detection`); entries whose behaviour cannot be shown
in one in-memory file (cross-file taint, duplication, dependency advisories)
set `selftest: false` with a `selftest_note`.

Id hygiene: one id has one meaning across packs and analyzers. The Python
compiler checks were renamed PY-C001..C003 -> PY-E001..E003 (they collided
with the TLS/debug pattern rules, so a verify=False finding was classified
as a syntax failure), and the Razor analyzer now uses RAZOR-X001 for raw
markup and RAZOR-X002 for script-context output, matching the pack. Ids an
analyzer shares with a pack rule are allow-listed in the standards test.

The JSON Schema for packs is rules/rule-pack.schema.json. Override packs
may omit every v2 key: a missing `type` is derived from category and
confidence, and malformed v2 values are rejected with a load error.

Mappings are review aids. They do not certify compliance with OWASP, ASVS,
PCI DSS or any other standard.

