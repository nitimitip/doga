"""
Standards taxonomy for rule metadata.

One place that knows the external standards a rule can be mapped to:

  * rule types (the SonarQube-style Vulnerability / Security Hotspot / Bug /
    Code Smell split),
  * OWASP Top 10 2021 and 2025 canonical labels,
  * OWASP ASVS 5.0 chapters,
  * PCI DSS v4.0.1 requirements,
  * the 2024 CWE Top 25 and the names of every CWE the packs use.

Pack rules carry their mappings explicitly (packs are self-describing); this
module is the reference table the pack migration derives them from, the
validator checks them against, and the UI renders names and links from.

Mappings are review aids. They do not certify compliance with any standard -
see UNIFIED_POLICY.md.
"""

from __future__ import annotations

import re

# ---------------------------------------------------------------------------
# Rule types and lifecycle
# ---------------------------------------------------------------------------

VULNERABILITY = "VULNERABILITY"
SECURITY_HOTSPOT = "SECURITY_HOTSPOT"
BUG = "BUG"
CODE_SMELL = "CODE_SMELL"

RULE_TYPES = (VULNERABILITY, SECURITY_HOTSPOT, BUG, CODE_SMELL)
SECURITY_TYPES = frozenset({VULNERABILITY, SECURITY_HOTSPOT})

TYPE_LABELS = {
    VULNERABILITY: "Vulnerability",
    SECURITY_HOTSPOT: "Security hotspot",
    BUG: "Bug",
    CODE_SMELL: "Code smell",
}

TYPE_HELP = {
    VULNERABILITY: "The matched construct is insecure as written; fix it.",
    SECURITY_HOTSPOT: "Security-sensitive code that needs a reviewer to decide "
                      "whether it is safe in context.",
    BUG: "Code that is valid but wrong: it crashes or gives wrong results.",
    CODE_SMELL: "Maintainability, performance or style issue.",
}



def default_rule_type(category: str, confidence: str = "HIGH") -> str:
    """
    Type for a rule that does not declare one (admin override packs).
    Security categories are a Vulnerability only on HIGH-confidence evidence
    and a Security hotspot otherwise; destructive operations always need a
    reviewer's judgement of intent.
    """
    from ..domain.models import RiskCategory
    if category == RiskCategory.DESTRUCTIVE:
        return SECURITY_HOTSPOT
    if category in RiskCategory.SECURITY_CATEGORIES:
        return VULNERABILITY if confidence.upper() == "HIGH" else SECURITY_HOTSPOT
    if category == RiskCategory.RELIABILITY:
        return BUG
    return CODE_SMELL


STATUS_STABLE = "stable"
STATUS_BETA = "beta"
STATUS_DEPRECATED = "deprecated"
RULE_STATUSES = (STATUS_STABLE, STATUS_BETA, STATUS_DEPRECATED)

STATUS_HELP = {
    STATUS_STABLE: "Field-proven rule with a stable meaning.",
    STATUS_BETA: "Recently added; findings are reported normally but precision "
                 "is still being measured.",
    STATUS_DEPRECATED: "Retained so old triage keeps resolving; superseded by "
                       "the rule named in replaced_by.",
}

# ---------------------------------------------------------------------------
# OWASP Top 10
# ---------------------------------------------------------------------------

OWASP_2021 = {
    "A01:2021": "Broken Access Control",
    "A02:2021": "Cryptographic Failures",
    "A03:2021": "Injection",
    "A04:2021": "Insecure Design",
    "A05:2021": "Security Misconfiguration",
    "A06:2021": "Vulnerable and Outdated Components",
    "A07:2021": "Identification and Authentication Failures",
    "A08:2021": "Software and Data Integrity Failures",
    "A09:2021": "Security Logging and Monitoring Failures",
    "A10:2021": "Server-Side Request Forgery",
}

OWASP_2025 = {
    "A01:2025": "Broken Access Control",
    "A02:2025": "Security Misconfiguration",
    "A03:2025": "Software Supply Chain Failures",
    "A04:2025": "Cryptographic Failures",
    "A05:2025": "Injection",
    "A06:2025": "Insecure Design",
    "A07:2025": "Authentication Failures",
    "A08:2025": "Software or Data Integrity Failures",
    "A09:2025": "Security Logging and Alerting Failures",
    "A10:2025": "Mishandling of Exceptional Conditions",
}

_OWASP_SLUG_2021 = {
    "A01:2021": "A01_2021-Broken_Access_Control",
    "A02:2021": "A02_2021-Cryptographic_Failures",
    "A03:2021": "A03_2021-Injection",
    "A04:2021": "A04_2021-Insecure_Design",
    "A05:2021": "A05_2021-Security_Misconfiguration",
    "A06:2021": "A06_2021-Vulnerable_and_Outdated_Components",
    "A07:2021": "A07_2021-Identification_and_Authentication_Failures",
    "A08:2021": "A08_2021-Software_and_Data_Integrity_Failures",
    "A09:2021": "A09_2021-Security_Logging_and_Monitoring_Failures",
    "A10:2021": "A10_2021-Server-Side_Request_Forgery_%28SSRF%29",
}


def owasp_label(code: str) -> str:
    """'A03:2021' -> 'A03:2021-Injection' (canonical stored form)."""
    key = owasp_code(code)
    name = OWASP_2021.get(key) or OWASP_2025.get(key)
    return f"{key}-{name}" if name else ""


def owasp_code(label: str) -> str:
    """Canonical 'Ann:YYYY' key from any spelling ('A08:2021-Software & ...')."""
    match = re.match(r"^\s*(A\d{2}:\d{4})", label or "")
    return match.group(1) if match else ""


def owasp_url(label: str) -> str:
    code = owasp_code(label)
    if code in _OWASP_SLUG_2021:
        return f"https://owasp.org/Top10/{_OWASP_SLUG_2021[code]}/"
    if code in OWASP_2025:
        return "https://owasp.org/Top10/2025/"
    return ""


# ---------------------------------------------------------------------------
# OWASP ASVS 5.0 chapters
# ---------------------------------------------------------------------------

ASVS_5 = {
    "V1": "Encoding and Sanitization",
    "V2": "Validation and Business Logic",
    "V3": "Web Frontend Security",
    "V4": "API and Web Service",
    "V5": "File Handling",
    "V6": "Authentication",
    "V7": "Session Management",
    "V8": "Authorization",
    "V9": "Self-contained Tokens",
    "V10": "OAuth and OIDC",
    "V11": "Cryptography",
    "V12": "Secure Communication",
    "V13": "Configuration",
    "V14": "Data Protection",
    "V15": "Secure Coding and Architecture",
    "V16": "Security Logging and Error Handling",
    "V17": "WebRTC",
}


def asvs_label(chapter: str) -> str:
    """'V1' -> 'V1 Encoding and Sanitization'."""
    key = (chapter or "").split(" ", 1)[0]
    return f"{key} {ASVS_5[key]}" if key in ASVS_5 else ""


# ---------------------------------------------------------------------------
# PCI DSS v4.0.1 (requirements a source-code finding can evidence)
# ---------------------------------------------------------------------------

PCI_DSS = {
    "2.2.6": "System security parameters are configured to prevent misuse",
    "3.6.1": "Cryptographic keys are protected against disclosure and misuse",
    "4.2.1": "Strong cryptography protects data in transit over open networks",
    "6.2.4": "Software engineering techniques prevent common software attacks",
    "6.3.3": "Components are protected from known vulnerabilities by patching",
    "8.6.2": "Account passwords are not hard coded in scripts, files or source",
    "10.2.1": "Audit logs are enabled and active",
}

# ---------------------------------------------------------------------------
# CWE
# ---------------------------------------------------------------------------

#: 2024 CWE Top 25 Most Dangerous Software Weaknesses, in rank order.
CWE_TOP_25_2024 = (
    79, 787, 89, 352, 22, 125, 78, 416, 862, 434, 94, 20, 77, 287, 269,
    502, 200, 863, 918, 119, 476, 798, 190, 400, 306,
)

CWE_NAMES = {
    11: "ASP.NET Misconfiguration: Creating Debug Binary",
    14: "Compiler Removal of Code to Clear Buffers",
    20: "Improper Input Validation",
    22: "Path Traversal",
    73: "External Control of File Name or Path",
    77: "Command Injection",
    78: "OS Command Injection",
    79: "Cross-site Scripting",
    80: "Basic XSS",
    89: "SQL Injection",
    90: "LDAP Injection",
    93: "CRLF Injection",
    94: "Code Injection",
    95: "Eval Injection",
    98: "PHP Remote File Inclusion",
    113: "HTTP Response Splitting",
    117: "Improper Output Neutralization for Logs",
    119: "Improper Restriction of Operations within the Bounds of a Memory Buffer",
    120: "Classic Buffer Overflow",
    125: "Out-of-bounds Read",
    134: "Use of Externally-Controlled Format String",
    190: "Integer Overflow or Wraparound",
    200: "Exposure of Sensitive Information to an Unauthorized Actor",
    209: "Generation of Error Message Containing Sensitive Information",
    214: "Invocation of Process Using Visible Sensitive Information",
    215: "Insertion of Sensitive Information Into Debugging Code",
    242: "Use of Inherently Dangerous Function",
    248: "Uncaught Exception",
    250: "Execution with Unnecessary Privileges",
    252: "Unchecked Return Value",
    258: "Empty Password in Configuration File",
    259: "Use of Hard-coded Password",
    269: "Improper Privilege Management",
    272: "Least Privilege Violation",
    284: "Improper Access Control",
    287: "Improper Authentication",
    295: "Improper Certificate Validation",
    299: "Improper Check for Certificate Revocation",
    306: "Missing Authentication for Critical Function",
    311: "Missing Encryption of Sensitive Data",
    312: "Cleartext Storage of Sensitive Information",
    319: "Cleartext Transmission of Sensitive Information",
    321: "Use of Hard-coded Cryptographic Key",
    324: "Use of a Key Past its Expiration Date",
    326: "Inadequate Encryption Strength",
    327: "Use of a Broken or Risky Cryptographic Algorithm",
    330: "Use of Insufficiently Random Values",
    338: "Use of Cryptographically Weak PRNG",
    345: "Insufficient Verification of Data Authenticity",
    346: "Origin Validation Error",
    347: "Improper Verification of Cryptographic Signature",
    352: "Cross-Site Request Forgery",
    362: "Race Condition",
    367: "Time-of-check Time-of-use Race Condition",
    369: "Divide By Zero",
    377: "Insecure Temporary File",
    382: "J2EE Bad Practices: Use of System.exit()",
    384: "Session Fixation",
    390: "Detection of Error Condition Without Action",
    391: "Unchecked Error Condition",
    395: "Use of NullPointerException Catch to Detect NULL Pointer Dereference",
    396: "Declaration of Catch for Generic Exception",
    400: "Uncontrolled Resource Consumption",
    401: "Missing Release of Memory after Effective Lifetime",
    416: "Use After Free",
    434: "Unrestricted Upload of File with Dangerous Type",
    457: "Use of Uninitialized Variable",
    462: "Duplicate Key in Associative List",
    470: "Unsafe Reflection",
    476: "NULL Pointer Dereference",
    477: "Use of Obsolete Function",
    480: "Use of Incorrect Operator",
    482: "Comparing instead of Assigning",
    483: "Incorrect Block Delimitation",
    489: "Active Debug Code",
    494: "Download of Code Without Integrity Check",
    502: "Deserialization of Untrusted Data",
    506: "Embedded Malicious Code",
    521: "Weak Password Requirements",
    522: "Insufficiently Protected Credentials",
    532: "Insertion of Sensitive Information into Log File",
    546: "Suspicious Comment",
    547: "Use of Hard-coded, Security-relevant Constants",
    548: "Exposure of Information Through Directory Listing",
    561: "Dead Code",
    563: "Assignment to Variable without Use",
    570: "Expression is Always False",
    571: "Expression is Always True",
    584: "Return Inside Finally Block",
    598: "Use of GET Request Method With Sensitive Query Strings",
    601: "Open Redirect",
    611: "XML External Entity Reference",
    613: "Insufficient Session Expiration",
    614: "Sensitive Cookie in HTTPS Session Without 'Secure' Attribute",
    628: "Function Call with Incorrectly Specified Arguments",
    642: "External Control of Critical State Data",
    643: "XPath Injection",
    662: "Improper Synchronization",
    667: "Improper Locking",
    668: "Exposure of Resource to Wrong Sphere",
    670: "Always-Incorrect Control Flow Implementation",
    674: "Uncontrolled Recursion",
    676: "Use of Potentially Dangerous Function",
    682: "Incorrect Calculation",
    685: "Function Call With Incorrect Number of Arguments",
    693: "Protection Mechanism Failure",
    697: "Incorrect Comparison",
    703: "Improper Check or Handling of Exceptional Conditions",
    704: "Incorrect Type Conversion or Cast",
    710: "Improper Adherence to Coding Standards",
    732: "Incorrect Permission Assignment for Critical Resource",
    749: "Exposed Dangerous Method or Function",
    754: "Improper Check for Unusual or Exceptional Conditions",
    755: "Improper Handling of Exceptional Conditions",
    770: "Allocation of Resources Without Limits or Throttling",
    772: "Missing Release of Resource after Effective Lifetime",
    778: "Insufficient Logging",
    780: "Use of RSA Algorithm without OAEP",
    787: "Out-of-bounds Write",
    798: "Use of Hard-coded Credentials",
    829: "Inclusion of Functionality from Untrusted Control Sphere",
    833: "Deadlock",
    835: "Infinite Loop",
    862: "Missing Authorization",
    863: "Incorrect Authorization",
    914: "Improper Control of Dynamically-Identified Variables",
    915: "Mass Assignment",
    916: "Use of Password Hash With Insufficient Computational Effort",
    917: "Expression Language Injection",
    918: "Server-Side Request Forgery",
    922: "Insecure Storage of Sensitive Information",
    926: "Improper Export of Android Application Components",
    942: "Permissive Cross-domain Policy with Untrusted Domains",
    943: "NoSQL Injection",
    1004: "Sensitive Cookie Without 'HttpOnly' Flag",
    1021: "Improper Restriction of Rendered UI Layers or Frames",
    1022: "Use of Web Link to Untrusted Target with window.opener Access",
    1041: "Use of Redundant Code",
    1049: "Excessive Data Query Operations in a Large Data Table",
    1050: "Excessive Platform Resource Consumption within a Loop",
    1064: "Invokable Control Element with Excessive Number of Parameters",
    1073: "Non-SQL Invokable Control Element with Excessive Data Resource Accesses",
    1078: "Inappropriate Source Code Style or Formatting",
    1104: "Use of Unmaintained Third Party Components",
    1120: "Excessive Code Complexity",
    1164: "Irrelevant Code",
    1188: "Initialization of a Resource with an Insecure Default",
    1275: "Sensitive Cookie with Improper SameSite Attribute",
    1327: "Binding to an Unrestricted IP Address",
    1333: "Inefficient Regular Expression Complexity",
    1336: "Server-Side Template Injection",
}

#: CWE ids the packs once used that are categories or a poor fit, with the
#: weakness that replaces them. The validator rejects the old ids.
RETIRED_CWES = {
    398: "a CWE category, not a weakness",
    605: "multiple binds to one port; use CWE-1327 for binding to 0.0.0.0",
    644: "header scripting syntax; Host-header allow-lists are CWE-20",
    707: "too abstract for a disabled constraint; use CWE-693",
    730: "a retired OWASP 2004 category; use CWE-676 or CWE-400",
    1058: "unrelated to blocking on async code; use CWE-833",
    1069: "means an empty exception block, not GOTO",
    320: "a CWE category; key rotation is CWE-324",
}


def cwe_numbers(value: str) -> list:
    return [int(n) for n in re.findall(r"CWE-(\d+)", value or "")]


def cwe_name(number: int) -> str:
    return CWE_NAMES.get(int(number), "")


def cwe_url(number: int) -> str:
    return f"https://cwe.mitre.org/data/definitions/{int(number)}.html"


def in_cwe_top_25(cwe: str) -> bool:
    return any(n in CWE_TOP_25_2024 for n in cwe_numbers(cwe))


# CWE -> (OWASP 2021, OWASP 2025, ASVS 5.0 chapter, PCI DSS requirements).
# 2021 follows OWASP's published CWE lists where a CWE appears there, except
# certificate validation, filed under A05 like the hand-reviewed pack rules;
# the rest, and every 2025 entry, are assigned by the category's stated scope.
_INJ = ("A03:2021", "A05:2025", "V1", ("6.2.4",))
_CRYPTO = ("A02:2021", "A04:2025", "V11", ("6.2.4",))
_TRANSPORT = ("A02:2021", "A04:2025", "V12", ("4.2.1", "6.2.4"))
_CERT = ("A05:2021", "A02:2025", "V12", ("4.2.1", "6.2.4"))
_ACCESS = ("A01:2021", "A01:2025", "V8", ("6.2.4",))
_CONFIG = ("A05:2021", "A02:2025", "V13", ("2.2.6",))
_FRONTEND = ("A05:2021", "A02:2025", "V3", ("6.2.4",))
_CRED = ("A07:2021", "A07:2025", "V13", ("8.6.2", "6.2.4"))
_SESSION = ("A07:2021", "A07:2025", "V7", ("6.2.4",))
_TOKEN = ("A08:2021", "A08:2025", "V9", ("6.2.4",))
_LOGGING = ("A09:2021", "A09:2025", "V16", ("6.2.4",))
_AUDIT = ("A09:2021", "A09:2025", "V16", ("10.2.1",))
_DESIGN = ("A04:2021", "A06:2025", "V15", ("6.2.4",))
_INTEGRITY = ("A08:2021", "A08:2025", "V15", ("6.2.4",))
_SUPPLY = ("A08:2021", "A03:2025", "V15", ("6.2.4",))
_COMPONENTS = ("A06:2021", "A03:2025", "V15", ("6.3.3",))
_DATA = ("A02:2021", "A04:2025", "V14", ("6.2.4",))
_FILE = ("A01:2021", "A01:2025", "V5", ("6.2.4",))
_EXCEPTIONS = ("", "A10:2025", "V16", ())

CWE_MAP = {
    # Injection and output encoding
    77: _INJ, 78: _INJ, 79: _INJ, 80: _INJ, 89: _INJ, 90: _INJ, 93: _INJ,
    94: _INJ, 95: _INJ, 98: _INJ, 113: _INJ, 134: _INJ, 643: _INJ,
    914: _INJ, 917: _INJ, 943: _INJ, 1336: _INJ, 470: _INJ,
    20: ("A03:2021", "A05:2025", "V2", ("6.2.4",)),
    611: ("A05:2021", "A02:2025", "V1", ("6.2.4",)),
    502: ("A08:2021", "A08:2025", "V1", ("6.2.4",)),
    918: ("A10:2021", "A01:2025", "V1", ("6.2.4",)),
    601: ("A01:2021", "A01:2025", "V1", ("6.2.4",)),
    # Files and paths
    22: _FILE, 73: ("A04:2021", "A01:2025", "V5", ("6.2.4",)),
    434: ("A04:2021", "A06:2025", "V5", ("6.2.4",)),
    377: _FILE,
    # Access control and privilege
    200: _ACCESS, 250: _ACCESS, 269: _ACCESS, 272: _ACCESS, 284: _ACCESS,
    668: _ACCESS, 732: _ACCESS, 862: _ACCESS, 863: _ACCESS, 926: _ACCESS,
    352: ("A01:2021", "A01:2025", "V3", ("6.2.4",)),
    1275: ("A01:2021", "A01:2025", "V3", ("6.2.4",)),
    # Cryptography
    14: _CRYPTO, 324: _CRYPTO, 326: _CRYPTO, 327: _CRYPTO, 330: _CRYPTO,
    338: _CRYPTO, 780: _CRYPTO, 916: _CRYPTO,
    321: ("A02:2021", "A04:2025", "V11", ("3.6.1", "6.2.4")),
    347: ("A02:2021", "A04:2025", "V9", ("6.2.4",)),
    # Transport
    319: _TRANSPORT, 295: _CERT, 299: _CERT,
    # Data protection
    311: _DATA, 312: _DATA, 922: _DATA, 214: _DATA,
    # Credentials, authentication and sessions
    259: _CRED, 258: _CRED, 798: _CRED,
    287: ("A07:2021", "A07:2025", "V6", ("6.2.4",)),
    306: ("A07:2021", "A07:2025", "V6", ("6.2.4",)),
    521: ("A07:2021", "A07:2025", "V6", ("6.2.4",)),
    522: ("A04:2021", "A07:2025", "V6", ("6.2.4",)),
    346: ("A07:2021", "A07:2025", "V9", ("6.2.4",)),
    345: _TOKEN, 384: _SESSION, 613: _SESSION, 598: _SESSION,
    # Browser / front end
    614: _FRONTEND, 1004: _FRONTEND, 942: _FRONTEND, 1021: _FRONTEND,
    1022: _FRONTEND,
    # Configuration
    11: _CONFIG, 215: _CONFIG, 489: _CONFIG, 548: _CONFIG, 693: _CONFIG,
    1327: _CONFIG, 749: _CONFIG, 547: _CONFIG,
    209: ("A04:2021", "A10:2025", "V16", ("6.2.4",)),
    # Integrity and supply chain
    494: _SUPPLY, 829: _SUPPLY, 506: _INTEGRITY, 642: _INTEGRITY,
    915: ("A08:2021", "A08:2025", "V15", ("6.2.4",)),
    1104: _COMPONENTS,
    477: ("A06:2021", "A03:2025", "V15", ("6.2.4",)),
    # Logging
    532: _LOGGING, 117: _LOGGING, 778: _AUDIT,
    # Design / dangerous operations / resource exhaustion
    676: _DESIGN, 242: _DESIGN, 400: _DESIGN, 770: _DESIGN, 674: _DESIGN,
    362: _DESIGN, 367: _DESIGN, 1333: _DESIGN,
    # Exceptional conditions (OWASP 2025 A10 only)
    248: _EXCEPTIONS, 390: _EXCEPTIONS, 391: _EXCEPTIONS, 395: _EXCEPTIONS,
    396: _EXCEPTIONS, 703: _EXCEPTIONS, 754: _EXCEPTIONS, 755: _EXCEPTIONS,
}


def standards_for(cwe: str) -> dict:
    """
    Default standard mappings for a rule's CWE: {owasp, owasp_2025, asvs,
    pci_dss}. The first mapped CWE in the value wins; unmapped -> empty.
    """
    for number in cwe_numbers(cwe):
        if number in CWE_MAP:
            o21, o25, asvs, pci = CWE_MAP[number]
            return {
                "owasp": owasp_label(o21) if o21 else "",
                "owasp_2025": owasp_label(o25) if o25 else "",
                "asvs": asvs_label(asvs) if asvs else "",
                "pci_dss": list(pci),
            }
    return {"owasp": "", "owasp_2025": "", "asvs": "", "pci_dss": []}


def standard_links(rule: dict) -> list:
    """(label, url) pairs for a rule dict: its CWEs, then its OWASP 2021 entry."""
    links = []
    for number in cwe_numbers(rule.get("cwe", "")):
        name = cwe_name(number)
        links.append((f"CWE-{number}" + (f": {name}" if name else ""), cwe_url(number)))
    owasp = rule.get("owasp", "")
    if owasp_url(owasp):
        links.append((owasp_label(owasp) or owasp, owasp_url(owasp)))
    return links
