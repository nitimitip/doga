"""
Quality-outcome model: scan completeness and finding classes.

A quality report answers three separate questions, in this order:

  1. Was the scan complete?   (every discovered file analysed, every parser
                               available, nothing stopped early)
  2. Did it pass the gate?
  3. What was found?          syntax failures, bugs, and coding-practice
                               suggestions - with security reported
                               separately, never blended into the verdict
                               of a quality-only gate.

Numeric scores come after these. A score of 100 means "no issues detected
within the stated coverage" - which is only a strong statement when (1) is
a yes.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field

from .models import RiskCategory, Severity

SYNTAX = "Syntax failure"
BUG = "Bug"
PRACTICE = "Coding practice"
SECURITY = "Security"

#: Report order: what must be fixed first comes first.
CLASSES = (SYNTAX, BUG, PRACTICE, SECURITY)

#: Rules whose finding means the file cannot be parsed, compiled or loaded.
SYNTAX_RULE_IDS = frozenset({
    "PY-Q000", "PY-E001", "PARSE-001",
    "JSON-S001", "JSON-S002", "XML-S001", "YAML-S001",
    # Structural syntax validation (analysis/structure_checks.py).
    "SYN-SH001", "SYN-SH002", "SYN-SQL001", "SYN-SQL002", "SYN-PLSQL001",
    "SYN-VB001", "SYN-ASP001", "SYN-ASP002", "SYN-ASPX001",
})

_SEVERITY_ORDER = [s.value for s in (Severity.BLOCKER, Severity.CRITICAL,
                                     Severity.HIGH, Severity.MEDIUM,
                                     Severity.LOW, Severity.INFO)]


def finding_class(finding) -> str:
    """Syntax failure / Bug / Coding practice / Security for one finding."""
    return classify(getattr(finding, "rule_id", ""), getattr(finding, "category", ""))


def classify(rule_id: str, category: str) -> str:
    if rule_id in SYNTAX_RULE_IDS:
        return SYNTAX
    if category in RiskCategory.SECURITY_CATEGORIES:
        return SECURITY
    if category == RiskCategory.RELIABILITY:
        return BUG
    return PRACTICE


def at_or_above(severity: str, threshold: str) -> bool:
    """True when `severity` is as severe as `threshold` or worse."""
    if threshold not in _SEVERITY_ORDER:
        return False
    value = getattr(severity, "value", severity)
    return value in _SEVERITY_ORDER and \
        _SEVERITY_ORDER.index(value) <= _SEVERITY_ORDER.index(threshold)


@dataclass
class Completeness:
    """Whether a scan analysed everything it claims to have analysed."""

    complete: bool
    files: int = 0
    reasons: list = field(default_factory=list)
    #: (path, message) for every file with recorded analysis errors.
    file_errors: list = field(default_factory=list)
    parser_gaps: int = 0

    @property
    def label(self) -> str:
        return "COMPLETE" if self.complete else "INCOMPLETE"

    @property
    def score_qualifier(self) -> str:
        if self.complete:
            return ("100 means no issues were detected within the stated "
                    "coverage")
        return ("coverage is INCOMPLETE - scores reflect only the evidence "
                "that was analysed")


def scan_completeness(result, require_parsers: bool = True) -> Completeness:
    """Completeness of `result`, from the per-file analysis evidence."""
    from .assurance import language_assurance
    from .models import relative_to_root

    reasons: list = []
    if not result.analyses or result.total_code_lines <= 0:
        reasons.append("No analysable source code was found.")
    parser_gaps = 0
    for row in language_assurance(result):
        if row["errors"] or row["missing"]:
            reasons.append(f"{row['language']}: {row['errors']} file(s) with "
                           f"analysis errors, {row['missing']} without "
                           f"analysis evidence.")
        if require_parsers and row["parser_gaps"]:
            parser_gaps += row["parser_gaps"]
            reasons.append(f"{row['language']}: {row['parser_gaps']} file(s) "
                           f"analysed without the language parser (pattern "
                           f"rules only).")
    file_errors = []
    for analysis in result.analyses:
        for error in analysis.tool_errors:
            file_errors.append((relative_to_root(analysis.path, result.root), error))
    return Completeness(complete=not reasons, files=len(result.analyses),
                        reasons=reasons, file_errors=file_errors,
                        parser_gaps=parser_gaps)


def outcome_counts(findings) -> "OrderedDict[str, dict]":
    """{class: {"total": n, "by_severity": {SEV: n}}} in report order."""
    out: OrderedDict = OrderedDict((name, {"total": 0, "by_severity": {}}) for name in CLASSES)
    for finding in findings:
        bucket = out[finding_class(finding)]
        severity = getattr(finding.severity, "value", finding.severity)
        bucket["total"] += 1
        bucket["by_severity"][severity] = bucket["by_severity"].get(severity, 0) + 1
    return out


def severity_phrase(by_severity: dict) -> str:
    """'1 HIGH, 3 MEDIUM' in severity order."""
    return ", ".join(f"{by_severity[s]} {s}" for s in _SEVERITY_ORDER if by_severity.get(s))
