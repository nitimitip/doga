"""
Scan scope: which languages and which rule families (or individual rules)
a scan should report.

A scope narrows what is ANALYSED (files of unselected languages are not
read at all) and what is REPORTED (findings outside the selected families
or rules are dropped before scoring). Analysis errors are never filtered:
an incomplete scan stays visibly incomplete whatever the scope.

The default scope - every language, every family, every rule - is the
full scan the platform has always run.
"""

from __future__ import annotations

import re
from collections import OrderedDict
from dataclasses import dataclass

from .models import RiskCategory
from .quality import SYNTAX_RULE_IDS

#: Rule families a user can choose, in display order.
FAMILIES = OrderedDict((
    ("syntax", "Syntax & parse errors"),
    ("bug", "Bugs (reliability)"),
    ("dangerous", "Dangerous operations"),
    ("security", "Security vulnerabilities"),
    ("practice", "Code smells & practices"),
))

_FAMILY_HELP = {
    "syntax": "Files that cannot be parsed, compiled or loaded.",
    "bug": "Code that is valid but wrong: crashes, dead branches, wrong results.",
    "dangerous": "Destructive operations: deletes, drops, wipes, shutdowns.",
    "security": "Injection, secrets, weak crypto, insecure configuration.",
    "practice": "Maintainability, performance and coding standards.",
}

_LANGUAGE_ID = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
_RULE_ID = re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+$")
#: Pseudo-rule id selecting every dependency (SCA) finding.
SCA_RULE_ID = "SCA-ALL"
#: Hard cap on individually selected rules (defensive; the catalog is ~600).
MAX_RULES = 2000


def family_help(family: str) -> str:
    return _FAMILY_HELP.get(family, "")


def rule_family(rule_id: str, category: str) -> str:
    """The user-facing family of one rule / finding."""
    if rule_id in SYNTAX_RULE_IDS:
        return "syntax"
    if category == RiskCategory.DESTRUCTIVE:
        return "dangerous"
    if category in RiskCategory.SECURITY_CATEGORIES:
        return "security"
    if category == RiskCategory.RELIABILITY:
        return "bug"
    return "practice"


@dataclass(frozen=True)
class ScanScope:
    """Languages / families / rules selected for one scan (empty = all)."""

    languages: tuple = ()
    families: tuple = ()
    rules: tuple = ()

    @classmethod
    def from_dict(cls, data) -> "ScanScope":
        """Build from untrusted input (form data, stored JSON); never raises."""
        if not isinstance(data, dict):
            return cls()

        def clean(values, valid, limit=None):
            if not isinstance(values, (list, tuple)):
                return ()
            out = []
            for value in values:
                if isinstance(value, str) and valid(value.strip()) and value.strip() not in out:
                    out.append(value.strip())
            return tuple(sorted(out[:limit] if limit else out))

        languages = clean(data.get("languages"), _LANGUAGE_ID.match)
        families = clean(data.get("families"), lambda v: v in FAMILIES)
        if set(families) == set(FAMILIES):
            families = ()
        rules = clean(data.get("rules"), _RULE_ID.match, MAX_RULES)
        return cls(languages=languages, families=families, rules=rules)

    def to_dict(self) -> dict:
        return {"languages": list(self.languages), "families": list(self.families),
                "rules": list(self.rules)}

    @property
    def is_full(self) -> bool:
        return not (self.languages or self.families or self.rules)

    def allows_language(self, language_id: str) -> bool:
        return not self.languages or language_id in self.languages

    def allows_path(self, path, registry) -> bool:
        if not self.languages:
            return True
        spec = registry.detect(path)
        return spec is not None and spec.id in self.languages

    def allows_family(self, family: str) -> bool:
        return not self.families or family in self.families

    def allows_finding(self, finding) -> bool:
        if self.rules:
            # Dependency advisories carry their advisory id as rule id; they
            # are selected as one group through the SCA-ALL pseudo-rule.
            rule_id = (SCA_RULE_ID if finding.category == RiskCategory.VULNERABLE_DEPENDENCY
                       else finding.rule_id)
            if rule_id not in self.rules:
                return False
        return self.allows_family(rule_family(finding.rule_id, finding.category))

    def apply(self, result) -> int:
        """
        Drop out-of-scope analyses and findings from a ScanResult in place.
        Returns the number of findings removed. Tool errors are kept.
        """
        if self.is_full:
            return 0
        removed = 0
        kept = []
        for analysis in result.analyses:
            language = analysis.language_id
            if self.languages and language not in self.languages \
                    and language not in ("unknown", "manifest"):
                removed += len(analysis.findings)
                continue
            before = len(analysis.findings)
            analysis.findings = [f for f in analysis.findings if self.allows_finding(f)]
            removed += before - len(analysis.findings)
            kept.append(analysis)
        result.analyses[:] = kept
        return removed

    def describe(self, language_name=None) -> dict:
        """Human-readable summary for logs, pages and reports."""
        name = language_name or (lambda v: v)
        return {
            "languages": ", ".join(name(l) for l in self.languages) if self.languages else "All languages",
            "families": ", ".join(FAMILIES[f] for f in self.families) if self.families else "All rule families",
            "rules": f"{len(self.rules)} selected rule(s)" if self.rules else "All rules",
        }
