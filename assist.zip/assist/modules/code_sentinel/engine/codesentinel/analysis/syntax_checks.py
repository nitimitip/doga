"""
Native syntax validation for structured data files (JSON, XML, YAML).

These formats were previously covered by pattern rules only, so a file that
could not even be loaded - `{"x": }`, `<root><child></root>` - produced no
finding at all. The checkers here report well-formedness errors with their
real line numbers, choose the JSON dialect by the file's consumer, and say
so explicitly whenever validation could not cover the whole file (the
engine records that as an analysis error, so an unchecked file never reads
as a clean one). Schema and business validation are out of scope.

Nothing is executed or resolved: JSON is decoded by the standard library,
XML by expat with external entities disabled, YAML by composing the node
graph only (no object construction).
"""

from __future__ import annotations

import json
import re
from xml.parsers import expat

from ..domain.models import Finding, RiskCategory, Severity

TOOL_NAME = "sentinel-syntax"

#: Characters that can only appear in a UTF-16/32 file mis-decoded as UTF-8;
#: such a file cannot be validated from the text the scanner holds.
_UNDECODABLE = re.compile(r"\x00")
_NOT_TEXT = ("the file is not UTF-8 text (it contains NUL bytes - UTF-16/32 "
             "or binary); syntax was not validated")


class SyntaxResult:
    """Findings plus, when validation could not cover the whole file, why."""

    __slots__ = ("findings", "incomplete")

    def __init__(self, findings=None, incomplete: str = "") -> None:
        self.findings = list(findings or [])
        self.incomplete = incomplete


# ---------------------------------------------------------------------------
# JSON / JSONC
# ---------------------------------------------------------------------------

#: JSON files whose consumers accept comments and trailing commas (JSONC).
_JSONC_NAMES = frozenset({
    "tsconfig.json", "jsconfig.json", ".eslintrc.json", ".eslintrc",
    ".babelrc", ".babelrc.json", "devcontainer.json", ".devcontainer.json",
    "tslint.json", ".jshintrc", "api-extractor.json", "turbo.json",
    "biome.json", "deno.json", "launchsettings.json",
})
#: tsconfig.base.json, appsettings.Development.json (ASP.NET Core's
#: configuration reader accepts comments) ...
_JSONC_PREFIXES = ("tsconfig.", "jsconfig.", "appsettings")
_JSONC_DIRS = frozenset({".vscode", ".devcontainer"})


def json_dialect(path) -> str:
    """'jsonc' when the file's consumer tolerates comments, else 'json'."""
    if path is None:
        return "json"
    name = path.name.lower()
    if path.suffix.lower() == ".jsonc" or name in _JSONC_NAMES \
            or name.startswith(_JSONC_PREFIXES) \
            or path.parent.name.lower() in _JSONC_DIRS:
        return "jsonc"
    return "json"


def _strip_jsonc(text: str) -> str:
    """
    Remove // and /* */ comments and trailing commas outside strings.
    Newlines are preserved so error line numbers stay accurate.
    """
    out = []
    i, n = 0, len(text)
    in_string = False
    while i < n:
        ch = text[i]
        if in_string:
            out.append(ch)
            if ch == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 2
                continue
            if ch == '"':
                in_string = False
            i += 1
            continue
        if ch == '"':
            in_string = True
            out.append(ch)
            i += 1
        elif text.startswith("//", i):
            end = text.find("\n", i)
            i = n if end < 0 else end
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            chunk = text[i:n if end < 0 else end + 2]
            out.append("\n" * chunk.count("\n"))
            i = n if end < 0 else end + 2
        else:
            out.append(ch)
            i += 1
    return re.sub(r",(\s*[}\]])", r"\1", "".join(out))


class JsonSyntaxChecker:
    """
    JSON-S001: the file cannot be loaded the way its consumer reads it.
    JSON-S002: a strict-JSON file uses comments / trailing commas - valid
    JSONC, but a strict consumer (npm, JSON.parse, json.load) rejects it.
    """

    def scan(self, text: str, path=None) -> list:
        return self.check(text, path).findings

    def check(self, text: str, path=None) -> SyntaxResult:
        text = text.lstrip("﻿")
        if not text.strip():
            return SyntaxResult()
        if _UNDECODABLE.search(text):
            return SyntaxResult(incomplete=_NOT_TEXT)
        dialect = json_dialect(path)
        try:
            json.loads(text)
            return SyntaxResult()
        except RecursionError:
            return SyntaxResult(incomplete="nesting too deep to validate")
        except ValueError as exc:
            error = exc
        try:
            json.loads(_strip_jsonc(text))
            jsonc_valid = True
        except (ValueError, RecursionError):
            jsonc_valid = False
        if jsonc_valid and dialect == "jsonc":
            return SyntaxResult()

        line = getattr(error, "lineno", 1) or 1
        column = getattr(error, "colno", 0)
        reason = getattr(error, "msg", str(error))
        if jsonc_valid:
            return SyntaxResult([Finding(
                tool=TOOL_NAME, rule_id="JSON-S002", severity=Severity.MEDIUM,
                line=line, category=RiskCategory.RELIABILITY, cwe="CWE-1078",
                confidence="MEDIUM",
                message=f"Comment or trailing comma at line {line}, column "
                        f"{column}: valid JSONC but not JSON. Strict consumers "
                        f"(npm, JSON.parse, json.load) reject this file.",
                remediation="Remove the comments/trailing commas, or rename the "
                            "file to .jsonc if every consumer accepts JSONC.",
            )])
        return SyntaxResult([Finding(
            tool=TOOL_NAME, rule_id="JSON-S001", severity=Severity.HIGH,
            line=line, category=RiskCategory.RELIABILITY, cwe="CWE-1078",
            message=f"Invalid {'JSONC' if dialect == 'jsonc' else 'JSON'} at "
                    f"line {line}, column {column}: {reason}. Any consumer "
                    f"that loads this file will fail.",
            remediation="Fix the syntax at the reported position (missing "
                        "value, unbalanced bracket, unquoted key, stray "
                        "comma) and validate with a JSON parser.",
        )])


# ---------------------------------------------------------------------------
# XML
# ---------------------------------------------------------------------------

class _EntityDeclared(Exception):
    """Raised to stop validation once the document declares entities."""


class XmlSyntaxChecker:
    """XML-S001: the file is not well-formed XML."""

    def scan(self, text: str, path=None) -> list:
        return self.check(text, path).findings

    def check(self, text: str, path=None) -> SyntaxResult:
        text = text.lstrip("﻿")
        if not text.strip():
            return SyntaxResult()
        if _UNDECODABLE.search(text):
            return SyntaxResult(incomplete=_NOT_TEXT)
        # The text was already decoded as UTF-8; override any encoding
        # declaration so expat does not re-decode it.
        parser = expat.ParserCreate(encoding="utf-8")
        parser.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)

        def _stop(*_args):
            raise _EntityDeclared(parser.CurrentLineNumber)

        # Entity declarations are where expansion attacks live: the document
        # is not parsed past one, and the result says the check stopped.
        parser.EntityDeclHandler = _stop
        try:
            parser.Parse(text.encode("utf-8"), True)
        except _EntityDeclared as stop:
            return SyntaxResult(incomplete=(
                f"validation stopped at the entity declaration on line "
                f"{stop.args[0]} (entities are not expanded, for safety); the "
                f"rest of the document was not checked"))
        except expat.ExpatError as exc:
            line = exc.lineno or 1
            reason = expat.ErrorString(exc.code)
            return SyntaxResult([Finding(
                tool=TOOL_NAME, rule_id="XML-S001", severity=Severity.HIGH,
                line=line, category=RiskCategory.RELIABILITY, cwe="CWE-1078",
                message=f"Malformed XML at line {line}, column {exc.offset}: "
                        f"{reason}. Any consumer that loads this file "
                        f"(build, IIS, application config) will fail.",
                remediation="Fix the reported element (unclosed or mismatched "
                            "tag, unescaped '&' or '<', duplicate attribute) "
                            "and validate with an XML parser.",
            )])
        except RecursionError:
            return SyntaxResult(incomplete="nesting too deep to validate")
        return SyntaxResult()


# ---------------------------------------------------------------------------
# YAML
# ---------------------------------------------------------------------------

#: Template syntax (Helm/Go templates, Jinja, Ansible) that is not YAML
#: until rendered.
_TEMPLATE_LINE = re.compile(r"^\s*(\{\{-?|\{%-?).*(-?\}\}|-?%\})\s*$")
_TEMPLATE_INLINE = re.compile(r"\{\{.*?\}\}|\{%.*?%\}")


def _detemplate(text: str) -> str:
    """
    Best-effort render of a template: directive-only lines become blank and
    inline expressions become a plain scalar. Line numbers are preserved.
    """
    out = []
    for line in text.split("\n"):
        if _TEMPLATE_LINE.match(line):
            out.append("")
        else:
            out.append(_TEMPLATE_INLINE.sub("TEMPLATE_VALUE", line))
    return "\n".join(out)


class YamlSyntaxChecker:
    """
    YAML-S001: the file is not valid YAML.

    Only composes the node graph - no object is constructed, so custom tags
    (CloudFormation !Ref, Ansible !vault) are accepted and alias "bombs"
    cannot expand. Templated YAML (Helm, Jinja) is validated after the
    template expressions are substituted; when even that fails, the file is
    reported as NOT validated rather than as invalid.
    """

    def scan(self, text: str, path=None) -> list:
        return self.check(text, path).findings

    def check(self, text: str, path=None) -> SyntaxResult:
        text = text.lstrip("﻿")
        if not text.strip():
            return SyntaxResult()
        if _UNDECODABLE.search(text):
            return SyntaxResult(incomplete=_NOT_TEXT)
        try:
            import yaml
        except ImportError:
            return SyntaxResult(incomplete=(
                "the YAML parser (PyYAML) is not installed on the scanning "
                "host; install it (requirements.txt) and re-scan"))
        loader = getattr(yaml, "CSafeLoader", yaml.SafeLoader)
        error = self._compose(yaml, loader, text)
        if error is None:
            return SyntaxResult()
        if _TEMPLATE_INLINE.search(text):
            if self._compose(yaml, loader, _detemplate(text)) is None:
                return SyntaxResult()
            return SyntaxResult(incomplete=(
                "templated YAML (Helm/Jinja) did not parse even with the "
                "template expressions substituted; validate the rendered "
                "output instead"))
        if isinstance(error, str):
            return SyntaxResult(incomplete=error)
        mark = getattr(error, "problem_mark", None)
        line = mark.line + 1 if mark is not None else 1
        column = mark.column + 1 if mark is not None else 0
        reason = getattr(error, "problem", None) or str(error).split("\n")[0]
        return SyntaxResult([Finding(
            tool=TOOL_NAME, rule_id="YAML-S001", severity=Severity.HIGH,
            line=line, category=RiskCategory.RELIABILITY, cwe="CWE-1078",
            message=f"Invalid YAML at line {line}, column {column}: {reason}. "
                    f"Any consumer that loads this file (CI pipeline, "
                    f"deployment, application config) will fail.",
            remediation="Fix the indentation, quoting or structure at the "
                        "reported position and validate with a YAML parser.",
        )])

    @staticmethod
    def _compose(yaml, loader, text: str):
        """None when valid; the YAMLError, or a string when not checkable."""
        try:
            for _ in yaml.compose_all(text, Loader=loader):
                pass
            return None
        except yaml.YAMLError as exc:
            return exc
        except RecursionError:
            return "nesting too deep to validate"
