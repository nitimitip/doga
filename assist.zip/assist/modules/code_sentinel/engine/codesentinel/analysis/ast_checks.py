"""
Python AST checks - precise where regex would guess.

Covers the functional-correctness and maintainability checks that need
real syntax awareness: parse-failure gate, swallowed exceptions, mutable
default arguments, long functions/parameter lists, deep loop nesting,
the N+1 query pattern, and exit-aware infinite-loop detection (an
unconditional loop with no reachable exit, and a loop whose condition
can never change).
"""

from __future__ import annotations

import ast
import re
import threading
import warnings

from ..domain.models import Finding, RiskCategory, Severity
from . import pybugs, pyflow
from .pyflow import guarded_ranges as _guarded_ranges, _in_ranges

TOOL_NAME = "sentinel-ast"

#: Method names that indicate a database round-trip.
_DB_CALL_NAMES = frozenset(
    {"execute", "executemany", "fetchone", "fetchall", "query", "commit"}
)
#: Receiver names that make a `<receiver>.execute()` style call a near-certain
#: database round-trip; any other receiver is reported with LOW confidence.
_DB_RECEIVER_HINTS = re.compile(
    r"(^|_)(cur|cursor|conn|connection|con|db|database|session|engine|"
    r"client|collection|table|pool|orm)s?($|_)", re.IGNORECASE)

#: Constructors that return a fresh mutable object - as a default argument
#: value the ONE object is shared by every call, exactly like `[]`/`{}`.
_MUTABLE_BUILTIN_FACTORIES = frozenset({"list", "dict", "set", "bytearray"})
_MUTABLE_COLLECTIONS_FACTORIES = frozenset(
    {"defaultdict", "deque", "OrderedDict", "Counter"})

#: Any of these calls can bind names invisibly - undefined-name analysis is
#: unsound in such a file and is skipped entirely.
_DYNAMIC_SCOPE_CALLS = frozenset(
    {"globals", "locals", "vars", "exec", "eval", "execfile"})

#: Compile validation runs under one lock: warnings.catch_warnings swaps
#: process-global state, and concurrent scans must not capture each other's
#: compiler warnings (a warning attributed to the wrong file).
_COMPILE_LOCK = threading.Lock()
_COMPILE_FILENAME = "<code-sentinel>"

MAX_FUNCTION_LINES = 60
MAX_PARAMETERS = 7
MAX_LOOP_DEPTH = 3
#: SonarSource's default cognitive-complexity gate for one function.
MAX_COGNITIVE_COMPLEXITY = 15


def cognitive_complexity(func) -> int:
    """
    Cognitive complexity of one function (the SonarSource metric): unlike
    cyclomatic complexity it charges extra for NESTING - the cost model of a
    human reader, not a test-case counter.

      * +1 (+nesting) for if / loops / except / ternary;
      * +1 flat for else and elif (their bodies still nest);
      * +1 per sequence of like boolean operators (a and b and c == +1 -
        Python's AST collapses a chain into one BoolOp, mixed operators
        produce nested BoolOps and cost one each);
      * +1 per direct recursive call;
      * nested function bodies count at one deeper nesting level.
    """

    def walk(node, nesting: int) -> int:
        total = 0
        for child in ast.iter_child_nodes(node):
            total += _score(child, nesting)
        return total

    def _score(node, nesting: int) -> int:
        if isinstance(node, ast.If):
            total = 1 + nesting + _score(node.test, nesting)
            for stmt in node.body:
                total += _score(stmt, nesting + 1)
            orelse = node.orelse
            if len(orelse) == 1 and isinstance(orelse[0], ast.If):
                total += _score(orelse[0], nesting) - nesting  # elif: +1 flat
            elif orelse:
                total += 1                                     # else: +1 flat
                for stmt in orelse:
                    total += _score(stmt, nesting + 1)
            return total
        if isinstance(node, (ast.For, ast.AsyncFor, ast.While)):
            total = 1 + nesting
            for child in ast.iter_child_nodes(node):
                total += _score(child, nesting + 1)
            return total
        if isinstance(node, ast.ExceptHandler):
            return 1 + nesting + walk(node, nesting + 1)
        if isinstance(node, ast.IfExp):
            return 1 + nesting + walk(node, nesting + 1)
        if isinstance(node, ast.BoolOp):
            return 1 + walk(node, nesting)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            return walk(node, nesting + 1)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) \
                and node.func.id == func.name:
            return 1 + walk(node, nesting)
        return walk(node, nesting)

    return walk(func, 0)

#: Scope boundaries: a break/return inside one of these does NOT exit an
#: enclosing loop, and names bound inside them live in a different scope.
_SCOPE_TYPES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ClassDef)
_LOOP_NODE_TYPES = (ast.For, ast.AsyncFor, ast.While)
#: Calls that terminate the process - a legitimate way out of any loop.
_EXIT_CALL_NAMES = frozenset({"exit", "quit", "sys.exit", "os._exit", "os.abort"})


def _iter_scoped(nodes, skip_types):
    """
    Walk `nodes` and their descendants, yielding every node reached but
    never descending INTO a `skip_types` node (the node itself is yielded).
    """
    stack = list(nodes)
    while stack:
        node = stack.pop()
        yield node
        if isinstance(node, skip_types):
            continue
        stack.extend(ast.iter_child_nodes(node))


def _dotted_call_name(func: ast.expr) -> str:
    parts = []
    while isinstance(func, ast.Attribute):
        parts.append(func.attr)
        func = func.value
    if isinstance(func, ast.Name):
        parts.append(func.id)
        return ".".join(reversed(parts))
    return ""


def _loop_has_exit(loop: ast.While) -> bool:
    """
    True when the loop body contains a construct that can leave the loop:
    a break at the loop's own level, or a return/raise/yield/process-exit
    anywhere outside nested function/class scopes. yield counts because the
    consumer of an infinite generator controls when iteration stops.
    """
    for node in _iter_scoped(loop.body, _SCOPE_TYPES + _LOOP_NODE_TYPES):
        if isinstance(node, ast.Break):
            return True
    for node in _iter_scoped(loop.body, _SCOPE_TYPES):
        if isinstance(node, (ast.Return, ast.Raise, ast.Yield, ast.YieldFrom)):
            return True
        if isinstance(node, ast.Call) and \
                _dotted_call_name(node.func) in _EXIT_CALL_NAMES:
            return True
    return False


def _parse_and_compile(text: str):
    """
    Parse `text` and run the bytecode compiler over the tree WITHOUT
    executing it. `ast.parse` accepts trees the compiler rejects ('return'
    outside a function, 'await' outside async, misplaced __future__ imports,
    'nonlocal' at module level), so a parse alone is not a validity check.

    Returns (tree, compile_error_or_None, warnings). Parse-level SyntaxError
    and ValueError propagate to the caller, as before.
    """
    with _COMPILE_LOCK, warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        tree = ast.parse(text, filename=_COMPILE_FILENAME)
        compile_error = None
        try:
            compile(tree, _COMPILE_FILENAME, "exec", dont_inherit=True)
        except SyntaxError as exc:
            compile_error = exc
        except (ValueError, RecursionError, MemoryError):
            pass  # pathological input; the parse-level checks still ran
    compiler_warnings = [
        w for w in caught
        if w.filename == _COMPILE_FILENAME and (
            issubclass(w.category, SyntaxWarning)
            or (issubclass(w.category, DeprecationWarning)
                and "invalid escape sequence" in str(w.message)))
    ]
    return tree, compile_error, compiler_warnings


def _is_number(value) -> bool:
    return isinstance(value, (int, float, complex)) and not isinstance(value, bool)


def _parameter_count(node, is_method: bool) -> int:
    """
    Parameters a caller must supply by position or keyword: positional-only,
    ordinary and keyword-only. *args/**kwargs are not counted, and the
    receiver (self/cls) of a non-static method is excluded - callers never
    pass it explicitly.
    """
    args = node.args
    positional = list(getattr(args, "posonlyargs", [])) + list(args.args)
    static = any(_dotted_call_name(d) in {"staticmethod", "builtins.staticmethod"}
                 for d in node.decorator_list)
    if is_method and positional and not static:
        positional = positional[1:]
    return len(positional) + len(args.kwonlyargs)


class _ModuleContext:
    """File-wide facts several checks need: every bound name and import."""

    def __init__(self, tree: ast.AST) -> None:
        self.bound: set = set()
        self.from_imports: dict = {}   # local name -> "module.attr"
        self.module_imports: set = set()
        self.star_import = False
        self.dynamic_scope = False
        self.local_functions: dict = {}  # name -> FunctionDef (top level + nested)
        self.db_function_cache: dict = {}  # name -> N+1 confidence or None
        #: Every node, walked once and shared by the checks that need it.
        self.nodes: list = list(ast.walk(tree))
        for node in self.nodes:
            if isinstance(node, ast.Name):
                if isinstance(node.ctx, (ast.Store, ast.Del)):
                    self.bound.add(node.id)
            elif isinstance(node, ast.arg):
                self.bound.add(node.arg)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.bound.add(node.name)
                self.local_functions.setdefault(node.name, node)
            elif isinstance(node, ast.ClassDef):
                self.bound.add(node.name)
            elif isinstance(node, ast.ExceptHandler) and node.name:
                self.bound.add(node.name)
            elif isinstance(node, (ast.Global, ast.Nonlocal)):
                self.bound.update(node.names)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    local = alias.asname or alias.name.split(".")[0]
                    self.bound.add(local)
                    self.module_imports.add(alias.asname or alias.name)
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    if alias.name == "*":
                        self.star_import = True
                        continue
                    local = alias.asname or alias.name
                    self.bound.add(local)
                    self.from_imports[local] = f"{node.module or ''}.{alias.name}"
            elif isinstance(node, ast.Call) and (
                    (isinstance(node.func, ast.Name)
                     and node.func.id in _DYNAMIC_SCOPE_CALLS)
                    # Enum._convert_ injects members into module globals.
                    or (isinstance(node.func, ast.Attribute)
                        and node.func.attr == "_convert_")):
                self.dynamic_scope = True
            elif isinstance(node, ast.Attribute) and node.attr == "modules" \
                    and _dotted_call_name(node) == "sys.modules":
                self.dynamic_scope = True   # sys.modules[__name__] tricks
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) \
                    and any(_dotted_call_name(d.func if isinstance(d, ast.Call) else d)
                            .rsplit(".", 1)[-1] == "global_enum"
                            for d in node.decorator_list):
                self.dynamic_scope = True   # @global_enum exports members
            else:
                # match-statement captures and PEP 695 type parameters carry
                # their bound name as a plain string attribute.
                for attr in ("name", "rest"):
                    value = getattr(node, attr, None)
                    if isinstance(value, str) and type(node).__name__ in {
                            "MatchAs", "MatchStar", "MatchMapping", "TypeVar",
                            "ParamSpec", "TypeVarTuple"}:
                        self.bound.add(value)
        if "builtins" in self.module_imports or "__builtin__" in self.module_imports:
            self.dynamic_scope = True  # the file may inject new builtins

    def is_mutable_factory(self, call: ast.Call) -> bool:
        """True when `call` provably constructs a fresh mutable container."""
        name = _dotted_call_name(call.func)
        if name in _MUTABLE_BUILTIN_FACTORIES:
            return name not in self.bound        # not shadowed in this file
        if name in _MUTABLE_COLLECTIONS_FACTORIES:
            return self.from_imports.get(name) == f"collections.{name}"
        module, _, attr = name.rpartition(".")
        return module == "collections" and attr in _MUTABLE_COLLECTIONS_FACTORIES \
            and "collections" in self.module_imports


class PythonAstChecker:
    """AST-level correctness/maintainability/performance checks."""

    def scan(self, text: str, path_name: str = "") -> list[Finding]:
        try:
            tree, compile_error, compiler_warnings = _parse_and_compile(text)
        except SyntaxError as exc:
            return [Finding(
                tool=TOOL_NAME, rule_id="PY-Q000", severity=Severity.HIGH,
                line=exc.lineno or 1, category=RiskCategory.RELIABILITY,
                cwe="CWE-1078",
                message=f"File does not parse: {exc.msg}. Nothing below this "
                        f"point can be trusted to run.",
                remediation="Fix the syntax error first - a file that does "
                            "not parse fails every functional-correctness "
                            "requirement.",
            )]
        except (ValueError, RecursionError) as exc:
            return [Finding(
                tool=TOOL_NAME, rule_id="PY-Q000", severity=Severity.MEDIUM,
                line=1, category=RiskCategory.RELIABILITY, cwe="CWE-1078",
                message=f"File could not be analysed as Python: {exc}",
                remediation="Inspect the file manually; it may be generated "
                            "or intentionally pathological.",
            )]

        context = _ModuleContext(tree)
        findings: list[Finding] = self._compiler_findings(
            compile_error, compiler_warnings)
        methods = {id(stmt) for node in context.nodes
                   if isinstance(node, ast.ClassDef) for stmt in node.body}
        for node in context.nodes:
            if isinstance(node, ast.ExceptHandler):
                findings.extend(self._check_handler(node))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                findings.extend(self._check_function(
                    node, context, is_method=id(node) in methods))

        findings.extend(self._loop_checks(tree, context))
        findings.extend(self._infinite_loop_checks(tree))
        findings.extend(self._control_flow_checks(tree))
        findings.extend(self._constant_error_checks(context.nodes))
        findings.extend(pyflow.analyze(tree, context.nodes, context.dynamic_scope))
        findings.extend(pybugs.analyze(tree, context.nodes, path_name))
        return findings

    # ---- Compiler validity -------------------------------------------------

    @staticmethod
    def _compiler_findings(compile_error, compiler_warnings) -> list[Finding]:
        """Diagnostics from the bytecode compiler (no code is executed)."""
        findings: list[Finding] = []
        if compile_error is not None:
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="PY-E001", severity=Severity.HIGH,
                line=compile_error.lineno or 1, category=RiskCategory.RELIABILITY,
                cwe="CWE-1078",
                message=f"Python compiler rejects this file: "
                        f"{compile_error.msg}. The file parses but can never "
                        f"be imported or run.",
                remediation="Fix the statement the compiler reports; the "
                            "module fails with SyntaxError on import.",
            ))
        seen: set = set()
        for warning in compiler_warnings:
            text = str(warning.message)
            key = (warning.lineno, text)
            if key in seen:
                continue
            seen.add(key)
            if "invalid escape sequence" in text:
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="PY-E003", severity=Severity.LOW,
                    line=warning.lineno or 1, category=RiskCategory.STANDARDS,
                    message=f"Compiler warning: {text}. Newer Python versions "
                            f"reject this as a syntax error.",
                    remediation="Use a raw string (r'...') for regular "
                                "expressions and paths, or escape the "
                                "backslash ('\\\\').",
                ))
            else:
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="PY-E002", severity=Severity.MEDIUM,
                    line=warning.lineno or 1, category=RiskCategory.RELIABILITY,
                    cwe="CWE-480",
                    message=f"Compiler warning: {text}. The statement almost "
                            f"certainly does not do what it appears to.",
                    remediation="Rewrite the flagged expression (e.g. '==' "
                                "instead of 'is' for literals, remove the "
                                "parentheses around an assert, add the "
                                "missing comma).",
                ))
        return findings

    # ---- Certain runtime errors -------------------------------------------

    _ZERO_GUARDS = frozenset({"ZeroDivisionError", "ArithmeticError"})

    def _constant_error_checks(self, nodes: list) -> list[Finding]:
        """
        PY-Q007 (CWE-369): division or modulo by a literal zero - raises
        ZeroDivisionError every time the expression runs. Skipped where the
        code deliberately provokes the error (tests, explicit handlers).
        `x % 0` is only reported with a numeric left operand, because `%` on
        a string is formatting, not modulo.
        """
        guarded = None          # computed only if a candidate is found
        findings: list[Finding] = []
        for node in nodes:
            if isinstance(node, ast.BinOp):
                left, op, right = node.left, node.op, node.right
            elif isinstance(node, ast.AugAssign):
                left, op, right = None, node.op, node.value
            else:
                continue
            if not isinstance(op, (ast.Div, ast.FloorDiv, ast.Mod)):
                continue
            if not (isinstance(right, ast.Constant) and _is_number(right.value)
                    and right.value == 0):
                continue
            if isinstance(op, ast.Mod) and not (
                    isinstance(left, ast.Constant) and _is_number(left.value)):
                continue
            if guarded is None:
                guarded = _guarded_ranges(nodes, self._ZERO_GUARDS)
            if _in_ranges(node.lineno, guarded):
                continue
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="PY-Q007", severity=Severity.HIGH,
                line=node.lineno, category=RiskCategory.RELIABILITY,
                cwe="CWE-369",
                message="Division by a literal zero - this expression raises "
                        "ZeroDivisionError every time it runs.",
                remediation="Divide by the intended variable, or guard the "
                            "divisor ('if d: ... else: ...').",
            ))
        return findings

    # ---- Individual checks -------------------------------------------------

    @staticmethod
    def _check_handler(node: ast.ExceptHandler) -> list[Finding]:
        swallowed = len(node.body) == 1 and isinstance(node.body[0], ast.Pass)
        if swallowed:
            return [Finding(
                tool=TOOL_NAME, rule_id="PY-Q001", severity=Severity.MEDIUM,
                line=node.lineno, category=RiskCategory.RELIABILITY,
                cwe="CWE-390",
                message="Exception caught and silently discarded "
                        "(except: pass) - failures vanish without logging "
                        "or context.",
                remediation="Log the exception with context "
                            "(logging.exception(...)) and handle or re-raise "
                            "it; never discard it.",
            )]
        if node.type is None:
            return [Finding(
                tool=TOOL_NAME, rule_id="PY-Q006", severity=Severity.LOW,
                line=node.lineno, category=RiskCategory.RELIABILITY,
                cwe="CWE-396",
                message="Bare 'except:' catches everything including "
                        "SystemExit/KeyboardInterrupt.",
                remediation="Catch the narrowest exception type the code can "
                            "actually handle (e.g. 'except OSError as exc:').",
            )]
        return []

    @staticmethod
    def _check_function(node: ast.FunctionDef | ast.AsyncFunctionDef,
                        context: _ModuleContext | None = None,
                        is_method: bool = False) -> list[Finding]:
        findings: list[Finding] = []
        end = getattr(node, "end_lineno", node.lineno) or node.lineno
        length = end - node.lineno + 1
        if length > MAX_FUNCTION_LINES:
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="MET-FN1", severity=Severity.LOW,
                line=node.lineno, category=RiskCategory.MAINTAINABILITY,
                cwe="CWE-1120",
                message=f"Function '{node.name}' is {length} lines long - "
                        f"hard to review, test, and modify safely.",
                remediation="Decompose into smaller single-purpose functions; "
                            "each extracted step becomes individually testable.",
            ))
        params = _parameter_count(node, is_method)
        if params > MAX_PARAMETERS:
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="MET-FN2", severity=Severity.LOW,
                line=node.lineno, category=RiskCategory.MAINTAINABILITY,
                cwe="CWE-1064",
                message=f"Function '{node.name}' takes {params} parameters - "
                        f"callers will pass them in the wrong order eventually.",
                remediation="Group related parameters into a dataclass/config "
                            "object, or split the function by responsibility.",
            ))
        cognitive = cognitive_complexity(node)
        if cognitive > MAX_COGNITIVE_COMPLEXITY:
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="MET-FN3", severity=Severity.MEDIUM,
                line=node.lineno, category=RiskCategory.MAINTAINABILITY,
                cwe="CWE-1120",
                message=f"Function '{node.name}' has cognitive complexity "
                        f"{cognitive} (limit {MAX_COGNITIVE_COMPLEXITY}) - "
                        f"the nesting and branching exceed what a reader can "
                        f"hold in working memory.",
                remediation="Flatten the structure: extract nested blocks "
                            "into named helper functions, replace deep "
                            "if-chains with early returns or a dispatch "
                            "table, and simplify compound boolean "
                            "conditions.",
            ))
        for default in list(node.args.defaults) + [
            d for d in node.args.kw_defaults if d is not None
        ]:
            mutable = isinstance(default, (ast.List, ast.Dict, ast.Set,
                                           ast.ListComp, ast.DictComp, ast.SetComp))
            if not mutable and context is not None and isinstance(default, ast.Call):
                mutable = context.is_mutable_factory(default)
            if mutable:
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="PY-Q003", severity=Severity.MEDIUM,
                    line=node.lineno, category=RiskCategory.RELIABILITY,
                    cwe="CWE-1188",
                    message=f"Function '{node.name}' has a mutable default "
                            f"argument - the same object is shared across "
                            f"every call, causing state to leak between "
                            f"invocations.",
                    remediation="Default to None and create the list/dict "
                                "inside the function: 'def f(items=None): "
                                "if items is None: items = []'.",
                ))
        return findings

    @staticmethod
    def _db_call_confidence(call: ast.Call, context: _ModuleContext | None) -> str | None:
        """
        Whether `call` is a database round-trip, and how sure we are:
        "HIGH" (a DB method on a cursor/connection/session-like receiver),
        "MEDIUM" (a DB-named function imported from another module), "LOW"
        (a DB-named method on an unrecognised receiver), or None (not a DB
        call - including a same-file function whose body makes no DB call).
        """
        func = call.func
        if isinstance(func, ast.Attribute):
            if func.attr not in _DB_CALL_NAMES:
                return None
            receiver = _dotted_call_name(func.value).rsplit(".", 1)[-1]
            return "HIGH" if receiver and _DB_RECEIVER_HINTS.search(receiver) else "LOW"
        if not isinstance(func, ast.Name):
            return None
        name = func.id
        local = context.local_functions.get(name) if context else None
        if local is not None:
            # Resolve the callee: it is a DB call only if its own body makes
            # one. Memoised per function (linear overall); a recursive call
            # resolves to "not DB" while its function is being evaluated.
            cache = context.db_function_cache
            if name not in cache:
                cache[name] = None
                cache[name] = "MEDIUM" if any(
                    isinstance(inner, ast.Call)
                    and PythonAstChecker._db_call_confidence(inner, context)
                    in ("HIGH", "MEDIUM")
                    for inner in ast.walk(local)) else None
            return cache[name]
        if name not in _DB_CALL_NAMES:
            return None
        return "MEDIUM" if context and name in context.from_imports else "LOW"

    @staticmethod
    def _loop_checks(tree: ast.AST, context: _ModuleContext | None = None) -> list[Finding]:
        """Deep loop nesting and DB calls inside loops (the N+1 pattern)."""
        findings: list[Finding] = []
        flagged_nesting: set[int] = set()
        flagged_n_plus_1: set[int] = set()

        def visit(node: ast.AST, loop_depth: int) -> None:
            if isinstance(node, (ast.For, ast.AsyncFor, ast.While)):
                loop_depth += 1
                if loop_depth >= MAX_LOOP_DEPTH and node.lineno not in flagged_nesting:
                    flagged_nesting.add(node.lineno)
                    findings.append(Finding(
                        tool=TOOL_NAME, rule_id="PERF-L1", severity=Severity.MEDIUM,
                        line=node.lineno, category=RiskCategory.PERFORMANCE,
                        cwe="CWE-1050",
                        message=f"Loops nested {loop_depth} levels deep - "
                        f"review iteration bounds and measured cost as input "
                                f"size grows; nesting alone does not establish runtime complexity.",
                        remediation="Restructure with lookup dictionaries/sets, "
                                    "vectorised operations, or a single "
                                    "pre-computed join instead of nested "
                                    "iteration.",
                    ))

            confidence = None
            if loop_depth >= 1 and isinstance(node, ast.Call) \
                    and node.lineno not in flagged_n_plus_1:
                confidence = PythonAstChecker._db_call_confidence(node, context)
            if confidence:
                name = node.func.attr if isinstance(node.func, ast.Attribute) \
                    else node.func.id
                flagged_n_plus_1.add(node.lineno)
                certain = confidence == "HIGH"
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="PERF-N1", severity=Severity.MEDIUM,
                    line=node.lineno, category=RiskCategory.PERFORMANCE,
                    cwe="CWE-1073", confidence=confidence,
                    message=(f"Database call '{name}()' inside a loop - the "
                             if certain else
                             f"Possible database call '{name}()' inside a "
                             f"loop (receiver not confirmed as a DB "
                             f"handle) - the ")
                            + "N+1 query pattern: one round-trip per item "
                              "instead of one per batch.",
                    remediation="Move the query outside the loop: fetch "
                                "with a single IN (...) / JOIN, or use "
                                "executemany for batched writes.",
                ))

            for child in ast.iter_child_nodes(node):
                visit(child, loop_depth)

        visit(tree, 0)
        return findings

    # ---- Infinite-loop detection (exit-aware, replaces the PY-L001 regex) ---

    def _infinite_loop_checks(self, tree: ast.AST) -> list[Finding]:
        """
        Two checks the old line regex could not make:

          * PY-L001 - `while True:` (any truthy constant) with NO reachable
            exit in the body. Loops WITH a break/return/raise/yield stay
            silent - the classic false positive on idiomatic poll loops.
          * PY-L002 - a conditional `while` whose condition can never change:
            every name in the condition is a local that the body neither
            reassigns nor passes to any call, and the loop has no other exit.
        """
        findings: list[Finding] = []

        # Each function is a scope; the module body is one too. While loops
        # are examined in the scope that owns them (nested defs excluded -
        # they are their own entries).
        scopes: list[tuple[list[ast.stmt], object]] = [(tree.body, None)] \
            if isinstance(tree, ast.Module) else []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                scopes.append((node.body, node))

        for body, func in scopes:
            local_names = self._scope_locals(body, func)
            for node in _iter_scoped(body, _SCOPE_TYPES):
                if isinstance(node, ast.While):
                    findings.extend(
                        self._check_while(node, func, local_names))
        return findings

    @staticmethod
    def _scope_locals(body: list[ast.stmt], func) -> set:
        """Names local to the scope: params + stores, minus global/nonlocal."""
        names: set = set()
        if func is not None:
            args = func.args
            for arg in (args.args + args.kwonlyargs
                        + getattr(args, "posonlyargs", [])):
                names.add(arg.arg)
            for var in (args.vararg, args.kwarg):
                if var is not None:
                    names.add(var.arg)
        escaping: set = set()
        for node in _iter_scoped(body, _SCOPE_TYPES):
            if isinstance(node, ast.Name) and \
                    isinstance(node.ctx, (ast.Store, ast.Del)):
                names.add(node.id)
            elif isinstance(node, (ast.Global, ast.Nonlocal)):
                escaping.update(node.names)
        return names - escaping

    def _check_while(self, loop: ast.While, func, local_names: set) -> list[Finding]:
        test = loop.test

        # Unconditional loop (while True / while 1 / any truthy constant).
        if isinstance(test, ast.Constant) and bool(test.value):
            if _loop_has_exit(loop):
                return []
            return [Finding(
                tool=TOOL_NAME, rule_id="PY-L001", severity=Severity.MEDIUM,
                line=loop.lineno, category=RiskCategory.RELIABILITY,
                cwe="CWE-835",
                message="Unconditional loop with no reachable exit - the body "
                        "contains no break, return, raise, yield, or process "
                        "exit, so the loop can never terminate.",
                remediation="Add a reachable exit (break on a condition, "
                            "return, or a real loop condition). If this is an "
                            "intentional daemon loop, suppress with "
                            "'nosast: PY-L001'.",
            )]

        # Conditional loop whose condition can never change. Only simple
        # name/constant/boolean/arithmetic/comparison conditions are analysed;
        # anything dynamic (calls, attributes, subscripts, walrus) is skipped.
        allowed = (ast.Name, ast.Constant, ast.BoolOp, ast.BinOp, ast.UnaryOp,
                   ast.Compare, ast.expr_context, ast.boolop, ast.operator,
                   ast.unaryop, ast.cmpop)
        if not all(isinstance(n, allowed) for n in ast.walk(test)):
            return []
        cond_names = {n.id for n in ast.walk(test) if isinstance(n, ast.Name)}
        if not cond_names or _loop_has_exit(loop):
            return []

        # Any write to a condition name anywhere in the body - including
        # inside nested functions (closures may rebind via nonlocal) - or a
        # condition name flowing into any call (which could mutate the object
        # it names) means the condition can change: stay silent.
        writes: set = set()
        has_call = False
        for node in ast.walk(loop):
            if isinstance(node, ast.Name) and \
                    isinstance(node.ctx, (ast.Store, ast.Del)):
                writes.add(node.id)
            elif isinstance(node, ast.ExceptHandler) and node.name:
                writes.add(node.name)
            elif isinstance(node, ast.Call):
                has_call = True
                for inner in ast.walk(node):
                    if isinstance(inner, ast.Name) and inner.id in cond_names:
                        return []
        if cond_names & writes:
            return []

        # Scope soundness: inside a function, every condition name must be a
        # true local (a call cannot rebind another frame's local). At module
        # level the names are globals any call could mutate, so only a
        # call-free body is provably stuck.
        if func is not None:
            if not cond_names <= local_names:
                return []
        elif has_call:
            return []

        names = ", ".join(sorted(cond_names))
        return [Finding(
            tool=TOOL_NAME, rule_id="PY-L002", severity=Severity.HIGH,
            line=loop.lineno, category=RiskCategory.RELIABILITY,
            cwe="CWE-835",
            message=f"Infinite loop: the condition depends only on "
                    f"({names}), which the body never modifies - the "
                    f"condition's value is fixed on entry, so the loop "
                    f"either never runs or never ends.",
            remediation="Update the condition variable inside the loop "
                        "(increment, reassignment) or add a break; if "
                        "another thread changes it, use a threading.Event "
                        "or make the shared state explicit.",
        )]

    # ---- Control-flow checks: unreachable code + dead stores ---------------

    #: A statement after one of these in the same block can never execute.
    _TERMINATORS = (ast.Return, ast.Raise, ast.Break, ast.Continue)
    #: Statement lists hanging off a node - each is one straight-line block.
    _BLOCK_FIELDS = ("body", "orelse", "finalbody")

    def _control_flow_checks(self, tree: ast.AST) -> list[Finding]:
        """
        Statement-level control flow (roadmap Stage 3, first increment):

          * PY-Q004 (CWE-561) - unreachable code: any statement following a
            return/raise/break/continue in the same block. Python does not
            hoist, so unlike JS there are no reachable-after-return cases.
          * PY-Q005 (CWE-563) - dead store: a simple local assignment
            overwritten by a later assignment in the same block with no
            possible read in between (no intervening call, control flow, or
            use of the name). Function scopes only - module globals and
            underscore names are exempt by design.
        """
        findings: list[Finding] = []

        # Unreachable code: every statement block in the file.
        for node in ast.walk(tree):
            for block in self._blocks_of(node):
                findings.extend(self._check_unreachable(block))

        # Dead stores: only blocks inside function scopes (module globals
        # are externally observable; nested defs are their own scope entry).
        for func in ast.walk(tree):
            if not isinstance(func, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            # global/nonlocal names are not locals: their writes are
            # observable outside this frame, so no store to them is dead.
            escaping = {name for node in _iter_scoped(func.body, _SCOPE_TYPES)
                        if isinstance(node, (ast.Global, ast.Nonlocal))
                        for name in node.names}
            findings.extend(self._check_dead_stores(func.body, escaping))
            for node in _iter_scoped(func.body, _SCOPE_TYPES):
                if not isinstance(node, _SCOPE_TYPES):
                    for block in self._blocks_of(node):
                        findings.extend(self._check_dead_stores(block, escaping))
        return findings

    def _blocks_of(self, node: ast.AST) -> list:
        blocks = []
        for field_name in self._BLOCK_FIELDS:
            block = getattr(node, field_name, None)
            if isinstance(block, list) and block and \
                    isinstance(block[0], ast.stmt):
                blocks.append(block)
        return blocks

    def _check_unreachable(self, block: list) -> list[Finding]:
        for index, stmt in enumerate(block[:-1]):
            if isinstance(stmt, self._TERMINATORS):
                unreachable = block[index + 1]
                return [Finding(
                    tool=TOOL_NAME, rule_id="PY-Q004", severity=Severity.MEDIUM,
                    line=unreachable.lineno, category=RiskCategory.RELIABILITY,
                    cwe="CWE-561",
                    message=f"Unreachable code: this statement follows a "
                            f"'{type(stmt).__name__.lower()}' on line "
                            f"{stmt.lineno} in the same block and can never "
                            f"execute.",
                    remediation="Delete the dead statements, or move them "
                                "before the terminating statement if they "
                                "were meant to run.",
                )]
        return []

    @staticmethod
    def _check_dead_stores(block: list, escaping: "set | frozenset" = frozenset()) -> list[Finding]:
        findings: list[Finding] = []
        pending: dict = {}      # name -> line of the store awaiting a read

        for stmt in block:
            # Reads happen before the statement's own store takes effect.
            reads = {n.id for n in ast.walk(stmt)
                     if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
            for name in reads:
                pending.pop(name, None)

            simple_target = None
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 \
                    and isinstance(stmt.targets[0], ast.Name):
                simple_target = stmt.targets[0].id
            elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None \
                    and isinstance(stmt.target, ast.Name):
                simple_target = stmt.target.id

            if simple_target is None:
                # Control flow, calls, complex targets, nested defs - any of
                # these may read a pending name invisibly. Start over.
                pending.clear()
                continue

            has_call = any(isinstance(n, (ast.Call, ast.Await, ast.Yield,
                                          ast.YieldFrom))
                           for n in ast.walk(stmt))
            if has_call:
                # The value expression can read closures/globals - every
                # pending store might be observed. Its own store still counts.
                pending.clear()
            if simple_target in escaping:
                continue
            if not has_call and simple_target in pending \
                    and not simple_target.startswith("_"):
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="PY-Q005", severity=Severity.LOW,
                    line=pending[simple_target],
                    category=RiskCategory.MAINTAINABILITY, cwe="CWE-563",
                    message=f"Dead store: the value assigned to "
                            f"'{simple_target}' here is overwritten on line "
                            f"{stmt.lineno} without ever being read.",
                    remediation="Remove the first assignment, or use its "
                                "value before reassigning; a dead store "
                                "usually signals a logic slip.",
                ))
            pending[simple_target] = stmt.lineno
        return findings


class ShellFileChecker:
    """
    Shell scanning:
      * file-level hygiene - strict-mode flags (set -e / set -u); and
      * line-level security - command injection (`eval` of an expansion) and
        download-and-execute pipelines (`curl ... | sh`).
    """

    #: `eval` given a line that contains a variable expansion - the classic
    #: shell command-injection sink (the expansion is re-parsed as a command).
    _EVAL_EXPANSION = re.compile(r"(^|;|\||&|\bthen\b|\bdo\b)\s*eval\b[^\n]*\$")
    #: Piping a network download straight into a shell - remote code execution.
    _CURL_PIPE_SH = re.compile(
        r"\b(curl|wget)\b[^\n|]*\|\s*(sudo\s+)?(sh|bash|zsh|ksh)\b",
        re.IGNORECASE,
    )

    def scan(self, lines: list[str]) -> list[Finding]:
        findings = self._hygiene(lines)
        findings.extend(self._injection(lines))
        return findings

    def _injection(self, lines: list[str]) -> list[Finding]:
        """Line-level command-injection and download-execute detection."""
        findings: list[Finding] = []
        for line_no, raw in enumerate(lines, start=1):
            stripped = raw.lstrip()
            if stripped.startswith("#"):
                continue
            if self._EVAL_EXPANSION.search(raw):
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="SH-I001", severity=Severity.HIGH,
                    line=line_no, category=RiskCategory.CODE_EXECUTION,
                    cwe="CWE-78", owasp="A03:2021-Injection",
                    message="'eval' runs a string containing a variable "
                            "expansion as a command - any attacker-influenced "
                            "value becomes shell command injection.",
                    remediation="Avoid 'eval'. Use arrays for dynamic "
                                "arguments (cmd=(git commit -m \"$msg\"); "
                                "\"${cmd[@]}\") or a case/dispatch block for "
                                "known actions.",
                ))
            if self._CURL_PIPE_SH.search(raw):
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="SH-I002", severity=Severity.HIGH,
                    line=line_no, category=RiskCategory.CODE_EXECUTION,
                    cwe="CWE-494", owasp="A08:2021",
                    message="Downloaded content is piped straight into a shell "
                            "- a compromised or spoofed endpoint gains remote "
                            "code execution, with no integrity check.",
                    remediation="Download to a file, verify it (checksum / "
                                "signature) against a pinned value, then "
                                "execute the verified copy.",
                ))
        return findings

    def _hygiene(self, lines: list[str]) -> list[Finding]:
        body = "\n".join(lines[:40])  # options are conventionally near the top
        findings: list[Finding] = []
        if not re.search(r"set\s+-\w*e|set\s+-o\s+errexit", body):
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="SH-R001", severity=Severity.LOW,
                line=1, category=RiskCategory.RELIABILITY, cwe="CWE-754",
                message="Script does not enable 'set -e' - it will keep "
                        "running after a command fails, which is how partial "
                        "state and destructive follow-on commands happen.",
                remediation="Add 'set -euo pipefail' near the top of the "
                            "script (exit on error, error on unset variables, "
                            "fail pipelines properly).",
            ))
        elif not re.search(r"set\s+-\w*u|set\s+-o\s+nounset", body):
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="SH-R002", severity=Severity.LOW,
                line=1, category=RiskCategory.RELIABILITY, cwe="CWE-754",
                message="Script does not enable 'set -u' - unset variables "
                        "silently expand to empty strings (the root cause of "
                        "'rm -rf $DIR/' wiping the wrong path).",
                remediation="Add 'set -u' (or upgrade to 'set -euo pipefail') "
                            "so unset variables abort the script.",
            ))
        return findings


class SqlStatementChecker:
    """
    Statement-level SQL scan: DELETE/UPDATE with no WHERE clause, and basic
    (bare) PL/SQL LOOP blocks that close without any EXIT / RETURN / RAISE /
    GOTO inside them - the exit-aware replacement for the old SQL-L001 line
    regex, which fired on every bare LOOP regardless of the EXIT below it.
    """

    #: `LOOP` (optionally labelled) alone on a line - a basic loop opener.
    _BARE_LOOP = re.compile(r"^\s*(?:<<\s*\w+\s*>>\s*)?LOOP\s*$", re.IGNORECASE)
    #: `FOR ... LOOP` / `WHILE ... LOOP` - conditioned loops, never flagged.
    _COND_LOOP = re.compile(r"\bLOOP\s*$", re.IGNORECASE)
    _END_LOOP = re.compile(r"\bEND\s+LOOP\b", re.IGNORECASE)
    #: `EXIT;` / `EXIT WHEN ...` leaves the innermost loop.
    _EXIT = re.compile(r"\bEXIT\b", re.IGNORECASE)
    #: `EXIT <label>` and terminal statements leave every open loop.
    _EXIT_LABEL = re.compile(r"\bEXIT\s+(?!WHEN\b)\w+", re.IGNORECASE)
    _TERMINAL = re.compile(r"\b(RETURN|RAISE|GOTO)\b", re.IGNORECASE)

    def scan(self, text: str) -> list[Finding]:
        import re

        findings: list[Finding] = []

        # Strip comments, preserving newlines so line numbers stay accurate.
        # Mask SQL literals and comments as lexical regions. Semicolons,
        # comment markers and WHERE inside a value are not SQL syntax.
        regions = r"'(?:''|[^'])*'|\"(?:\"\"|[^\"])*\"|`[^`]*`|\[[^\]]*\]|--[^\n]*|/\*[\s\S]*?\*/"
        clean = re.sub(regions, lambda m: ''.join('\n' if c == '\n' else ' ' for c in m.group()), text)

        offset = 0
        for statement in clean.split(";"):
            leading = len(statement) - len(statement.lstrip())
            line_no = clean.count("\n", 0, offset + leading) + 1
            offset += len(statement) + 1
            body = statement.strip()
            if not body:
                continue

            upper = re.sub(r"\s+", " ", body.upper())
            depth = 0
            has_where = False
            for token in re.findall(r'\(|\)|\b\w+\b', upper):
                if token == '(':
                    depth += 1
                elif token == ')':
                    depth = max(0, depth - 1)
                elif token == 'WHERE' and depth == 0:
                    has_where = True
            if re.match(r'DELETE\b', upper) and not has_where:
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="SQL-D004", severity=Severity.HIGH,
                    line=line_no, category=RiskCategory.DESTRUCTIVE, cwe="CWE-676",
                    message="DELETE has no top-level WHERE filter and may affect the entire target table.",
                    remediation="Add the intended restrictive predicate and verify the row count. "
                                "For intentional bulk deletion, require review and a tested recovery plan.",
                ))
            elif re.match(r'UPDATE\b', upper) and " SET " in upper and not has_where:
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="SQL-D005", severity=Severity.HIGH,
                    line=line_no, category=RiskCategory.DESTRUCTIVE, cwe="CWE-676",
                    message="UPDATE statement with no WHERE clause - modifies "
                            "every row in the table.",
                    remediation="Add a WHERE clause, and wrap ad-hoc updates in "
                                "a transaction with a verified row count before "
                                "COMMIT.",
                ))

        findings.extend(self._basic_loop_exits(clean))
        return findings

    def _basic_loop_exits(self, clean: str) -> list[Finding]:
        """Flag bare LOOP blocks whose span contains no way out."""
        findings: list[Finding] = []
        stack: list[list] = []  # [opener line, is_bare, has_exit]

        for line_no, line in enumerate(clean.splitlines(), start=1):
            # Exits are credited before END LOOP so `EXIT WHEN x; END LOOP;`
            # on one line still counts.
            if stack and self._EXIT.search(line):
                if self._EXIT_LABEL.search(line):
                    for entry in stack:       # EXIT <label> can leave any loop
                        entry[2] = True
                else:
                    stack[-1][2] = True       # EXIT / EXIT WHEN: innermost
            if stack and self._TERMINAL.search(line):
                for entry in stack:           # RETURN/RAISE/GOTO leave them all
                    entry[2] = True

            if self._END_LOOP.search(line):
                if stack:
                    opener, bare, has_exit = stack.pop()
                    if bare and not has_exit:
                        findings.append(Finding(
                            tool=TOOL_NAME, rule_id="SQL-L001",
                            severity=Severity.MEDIUM, line=opener,
                            category=RiskCategory.RELIABILITY, cwe="CWE-835",
                            message="Basic LOOP block with no EXIT, RETURN, "
                                    "RAISE, or GOTO anywhere inside it - the "
                                    "loop can never terminate.",
                            remediation="Add EXIT WHEN <condition>, or use a "
                                        "bounded FOR/WHILE loop instead of a "
                                        "basic LOOP.",
                        ))
            elif self._BARE_LOOP.match(line):
                stack.append([line_no, True, False])
            elif self._COND_LOOP.search(line):
                stack.append([line_no, False, False])
        return findings


class PlsqlDynamicSqlChecker:
    """
    PL/SQL dynamic-SQL injection: SQL text built by string concatenation and
    then run through a dynamic-execution sink (EXECUTE IMMEDIATE, OPEN ... FOR,
    DBMS_SQL.PARSE). This is the canonical Oracle SQL-injection pattern - the
    concatenated identifier lands in the SQL text unparameterised.
    """

    #: Dynamic-execution sinks, matched at statement start / clause boundary.
    _SINKS = re.compile(
        r"\b(EXECUTE\s+IMMEDIATE|OPEN\s+[\w.$]+\s+FOR|DBMS_SQL\.PARSE)\b",
        re.IGNORECASE,
    )
    #: `||` concatenation with at least one identifier (variable) operand -
    #: `'a' || 'b'` (literal-only) does not match, so constants are ignored.
    _VAR_CONCAT = re.compile(r"\|\|\s*[A-Za-z_]|[A-Za-z_]\w*\s*\|\|")

    def scan(self, text: str) -> list[Finding]:
        findings: list[Finding] = []

        no_block = re.sub(
            r"/\*.*?\*/",
            lambda m: "\n" * m.group(0).count("\n"),
            text,
            flags=re.DOTALL,
        )
        clean = re.sub(r"--[^\n]*", "", no_block)

        start = 0
        for statement in clean.split(";"):
            if statement.strip():
                sink = self._SINKS.search(statement)
                if sink and self._VAR_CONCAT.search(statement):
                    # Anchor to the sink keyword's line, not the statement
                    # start - a CREATE PROCEDURE body can begin many lines
                    # above the sink.
                    line_no = clean.count("\n", 0, start + sink.start()) + 1
                    findings.append(Finding(
                        tool=TOOL_NAME, rule_id="PLSQL-I001",
                        severity=Severity.HIGH, line=line_no,
                        category=RiskCategory.INJECTION, cwe="CWE-89",
                        owasp="A03:2021-Injection",
                        message=f"Dynamic SQL assembled by '||' concatenation "
                                f"and run via {sink.group(1).upper()} - any "
                                f"attacker-influenced value is injected into "
                                f"the SQL text, not bound as data.",
                        remediation="Parameterise with bind variables: EXECUTE "
                                    "IMMEDIATE 'SELECT ... WHERE id = :1' USING "
                                    "p_id (or DBMS_SQL bind calls). Never "
                                    "concatenate values into the statement "
                                    "text; validate any dynamic identifier "
                                    "against an allow-list.",
                    ))
            start += len(statement) + 1
        return findings


class PowerShellSecurityChecker:
    """
    PowerShell dataflow security checks - the value single-line regex cannot
    provide: an untrusted input tracked across statements into a code/command
    sink, plus sinks the rule pack does not cover (the call operator `& $var`,
    `[scriptblock]::Create`, and SQL built by PowerShell string interpolation).

    Taint is a light forward analysis over logical lines: variables assigned
    from a source (Read-Host, $args, a param() parameter) - or from an
    expression that references a tainted variable - become tainted, and a sink
    referencing a tainted variable is reported.
    """

    _ASSIGN = re.compile(r"^\s*(\$\w+)\s*=\s*(.+?)\s*$")
    _VARREF = re.compile(r"\$(\w+)")
    _LITERAL = re.compile(r"""^\s*(?:(['"]).*\1|-?\d+(?:\.\d+)?|\$(?:true|false|null))\s*$""",
                          re.IGNORECASE)
    #: PowerShell automatic variables that must never count as a param source.
    _AUTOMATIC = frozenset({
        "true", "false", "null", "_", "args", "psitem", "pscmdlet",
        "psboundparameters", "myinvocation", "host", "pwd", "error", "psversiontable",
    })

    # Sources.
    _READ_HOST = re.compile(r"\bRead-Host\b", re.IGNORECASE)
    _ARGS = re.compile(r"\$args\b", re.IGNORECASE)

    # Sinks.
    _IEX = re.compile(r"\b(?:Invoke-Expression|iex)\b", re.IGNORECASE)
    _SCRIPTBLOCK = re.compile(r"\[scriptblock\]::Create\s*\(", re.IGNORECASE)
    _CALL_OP = re.compile(r"(?:^|[|;{(&])\s*[&.]\s+(\$\w+)")
    _START_PROC = re.compile(r"\bStart-Process\b", re.IGNORECASE)
    _SQL_CTX = re.compile(r"SqlCommand\s*\(|\.CommandText\s*=|Invoke-Sqlcmd\b|-Query\b",
                          re.IGNORECASE)
    _SQL_STRING = re.compile(r'"[^"]*\$\{?\w+[^"]*"')

    def scan(self, text: str) -> list[Finding]:
        raw_lines = text.splitlines()
        lines = [self._strip_comment(line) for line in raw_lines]

        tainted = self._collect_tainted(text, lines)
        findings: list[Finding] = []

        for index, line in enumerate(lines):
            line_no = index + 1

            iex = self._IEX.search(line) or self._SCRIPTBLOCK.search(line)
            if iex and self._refs_tainted(line[iex.start():], tainted):
                findings.append(self._finding(
                    "PS-I010", Severity.CRITICAL, line_no,
                    RiskCategory.CODE_EXECUTION, "CWE-95",
                    "Untrusted input flows into Invoke-Expression / "
                    "[scriptblock]::Create - the value is executed as "
                    "PowerShell code (code injection).",
                    "Never execute input as code. Use a validated dispatch "
                    "(switch/hashtable of allowed actions) or call the cmdlet "
                    "directly with bound parameters."))
                continue

            call = self._CALL_OP.search(line)
            if call and self._name(call.group(1)) in tainted:
                findings.append(self._finding(
                    "PS-I011", Severity.HIGH, line_no,
                    RiskCategory.CODE_EXECUTION, "CWE-78",
                    "The call operator (& / .) invokes a variable holding "
                    "untrusted input - command injection: the attacker chooses "
                    "the command that runs.",
                    "Invoke a fixed executable and pass data as separate "
                    "arguments (& 'git' 'status' $safeArg); validate any "
                    "dynamic command against an allow-list."))
                continue

            if self._START_PROC.search(line) and self._refs_tainted(line, tainted):
                findings.append(self._finding(
                    "PS-I011", Severity.MEDIUM, line_no,
                    RiskCategory.CODE_EXECUTION, "CWE-78",
                    "Start-Process is given an untrusted value - a crafted "
                    "value can launch an unintended command.",
                    "Pass a fixed -FilePath and supply data via -ArgumentList "
                    "as separate, validated arguments."))
                continue

            if self._SQL_CTX.search(line):
                sql_string = self._SQL_STRING.search(line)
                if sql_string and self._VARREF.search(sql_string.group(0)):
                    findings.append(self._finding(
                        "PS-I012", Severity.HIGH, line_no,
                        RiskCategory.INJECTION, "CWE-89",
                        "SQL text is built with PowerShell string interpolation "
                        "of a variable ($var inside the query) - SQL injection; "
                        "interpolation is not parameterisation.",
                        "Use a parameterised command: "
                        "$cmd.Parameters.AddWithValue('@id', $id) with "
                        "'... WHERE id = @id', or Invoke-Sqlcmd -Variable."))
        return findings

    # ---- Taint collection --------------------------------------------------

    def _collect_tainted(self, text: str, lines: list) -> set:
        tainted = set(self._param_vars(text))
        for _ in range(2):     # two passes approximate order-independence
            for line in lines:
                match = self._ASSIGN.match(line)
                if not match:
                    continue
                name = self._name(match.group(1))
                rhs = match.group(2)
                if self._READ_HOST.search(rhs) or self._ARGS.search(rhs) \
                        or self._refs_tainted(rhs, tainted):
                    tainted.add(name)
                elif self._LITERAL.match(rhs):
                    tainted.discard(name)
        return tainted

    def _param_vars(self, text: str) -> set:
        """Variables declared in a param(...) block - script input sources."""
        names: set = set()
        for match in re.finditer(r"\bparam\b", text, re.IGNORECASE):
            open_paren = text.find("(", match.end())
            if open_paren < 0:
                continue
            depth, i = 0, open_paren
            while i < len(text):
                if text[i] == "(":
                    depth += 1
                elif text[i] == ")":
                    depth -= 1
                    if depth == 0:
                        break
                i += 1
            for var in self._VARREF.finditer(text[open_paren:i]):
                name = var.group(1).lower()
                if name not in self._AUTOMATIC:
                    names.add(name)
        return names

    # ---- Helpers -----------------------------------------------------------

    @staticmethod
    def _name(token: str) -> str:
        return token.lstrip("$").lower()

    def _refs_tainted(self, fragment: str, tainted: set) -> bool:
        return any(var.group(1).lower() in tainted
                   for var in self._VARREF.finditer(fragment))

    @staticmethod
    def _strip_comment(line: str) -> str:
        hash_pos = line.find("#")
        return line[:hash_pos] if hash_pos >= 0 else line

    @staticmethod
    def _finding(rule_id, severity, line_no, category, cwe, message,
                 remediation) -> Finding:
        return Finding(
            tool=TOOL_NAME, rule_id=rule_id, severity=severity, line=line_no,
            category=category, cwe=cwe, owasp="A03:2021-Injection",
            message=message, remediation=remediation)


def _template_finding(rule_id, severity, line_no, cwe, message,
                      remediation) -> Finding:
    return Finding(
        tool=TOOL_NAME, rule_id=rule_id, severity=severity, line=line_no,
        category=RiskCategory.INJECTION, cwe=cwe, owasp="A03:2021-Injection",
        message=message, remediation=remediation)


def _is_literal_expr(text: str) -> bool:
    """True when a template expression is a single quoted string literal."""
    return bool(re.match(r"""^\s*@?\s*(['"]).*\1\s*$""", text.strip()))


class JinjaTemplateChecker:
    """
    Jinja2 template XSS. Jinja auto-escapes ``{{ }}`` output by default, so the
    findings are the ways that protection is turned off or side-stepped:

      * ``{{ value | safe }}`` - escaping explicitly bypassed;
      * ``{% autoescape false %}`` - escaping disabled for a whole region;
      * ``{{ value }}`` inside ``<script>`` - HTML-escaping does not make a
        value safe in a JavaScript context (use ``| tojson``).
    """

    _COMMENT = re.compile(r"\{#.*?#\}", re.DOTALL)
    _OUTPUT = re.compile(r"\{\{(?P<expr>.*?)\}\}", re.DOTALL)
    _HAS_SAFE = re.compile(r"\|\s*safe\b", re.IGNORECASE)
    _AUTOESCAPE_OFF = re.compile(r"\{%\s*autoescape\s+false\s*%\}", re.IGNORECASE)
    _SCRIPT_BLOCK = re.compile(r"<script\b[^>]*>(.*?)</script\s*>",
                               re.IGNORECASE | re.DOTALL)

    def scan(self, text: str) -> list[Finding]:
        clean = self._COMMENT.sub(
            lambda m: "\n" * m.group(0).count("\n"), text)
        findings: list[Finding] = []

        for match in self._AUTOESCAPE_OFF.finditer(clean):
            findings.append(_template_finding(
                "JINJA-X002", Severity.HIGH,
                clean.count("\n", 0, match.start()) + 1, "CWE-79",
                "Jinja auto-escaping is disabled for this block "
                "({% autoescape false %}) - every {{ }} inside outputs raw, "
                "unescaped HTML (stored/reflected XSS).",
                "Remove the block and escape by default; wrap only the "
                "specific trusted fragment in |safe, or sanitise the HTML "
                "server-side (e.g. bleach) before rendering."))

        for match in self._OUTPUT.finditer(clean):
            expr = match.group("expr")
            if not self._HAS_SAFE.search(expr):
                continue
            before = expr.split("|", 1)[0]
            if _is_literal_expr(before):
                continue                     # {{ "static" | safe }} is inert
            findings.append(_template_finding(
                "JINJA-X001", Severity.HIGH,
                clean.count("\n", 0, match.start()) + 1, "CWE-79",
                "The 'safe' filter bypasses Jinja auto-escaping - the value is "
                "written as raw HTML, so any attacker-controlled content "
                "becomes XSS.",
                "Drop |safe and let Jinja escape it; if the value is genuinely "
                "trusted HTML, sanitise it server-side (bleach) first, and "
                "never apply |safe to user input."))

        for block in self._SCRIPT_BLOCK.finditer(clean):
            base = block.start(1)
            for out in self._OUTPUT.finditer(block.group(1)):
                if "tojson" in out.group("expr").lower():
                    continue                 # | tojson is the safe JS encoding
                findings.append(_template_finding(
                    "JINJA-X003", Severity.MEDIUM,
                    clean.count("\n", 0, base + out.start()) + 1, "CWE-79",
                    "Template value rendered into a <script> block - Jinja's "
                    "HTML escaping does not make it safe in JavaScript "
                    "context (breaking out of the string still runs code).",
                    "Serialise data for JavaScript with the 'tojson' filter "
                    "(var data = {{ value | tojson }};), never bare {{ }}."))
        return findings


class RazorTemplateChecker:
    """
    Razor (.cshtml/.razor) template XSS. Razor HTML-encodes ``@expr`` by
    default, so the findings are the encoding bypasses. Ids match the razor
    pack, so one id keeps one meaning across pattern and analyzer findings:

      * RAZOR-X001 ``@Html.Raw(value)`` / ``new HtmlString(value)`` /
        ``MvcHtmlString`` - raw, unencoded markup output;
      * RAZOR-X002 ``@expr`` inside ``<script>`` - encoded, but not safe for
        JS context.
    """

    _COMMENT = re.compile(r"@\*.*?\*@", re.DOTALL)
    _HTML_RAW = re.compile(r"@?Html\.Raw\s*\(\s*(?P<arg>[^)]*)\)", re.IGNORECASE)
    _HTML_STRING = re.compile(
        r"new\s+(?:System\.Web\.)?(?:Mvc)?HtmlString\s*\(\s*(?P<arg>[^)]*)\)",
        re.IGNORECASE)
    _SCRIPT_BLOCK = re.compile(r"<script\b[^>]*>(.*?)</script\s*>",
                               re.IGNORECASE | re.DOTALL)
    _RAZOR_EXPR = re.compile(r"@(?:Model|ViewBag|ViewData|Html\.Encode)\b[\w.\[\]]*")
    _JSON = re.compile(r"Json\.Serialize|JsonConvert\.Serialize|@Json\b",
                       re.IGNORECASE)

    def scan(self, text: str) -> list[Finding]:
        clean = self._COMMENT.sub(
            lambda m: "\n" * m.group(0).count("\n"), text)
        findings: list[Finding] = []

        for match in self._HTML_RAW.finditer(clean):
            arg = match.group("arg")
            if _is_literal_expr(arg) or self._JSON.search(arg):
                continue                     # constant, or JSON-encoded for JS
            findings.append(_template_finding(
                "RAZOR-X001", Severity.HIGH,
                clean.count("\n", 0, match.start()) + 1, "CWE-79",
                "@Html.Raw() bypasses Razor's automatic HTML encoding - the "
                "value is written as raw markup, so attacker-controlled data "
                "becomes XSS.",
                "Output the value with plain @value so Razor encodes it; if "
                "raw HTML is genuinely required, sanitise it server-side "
                "(e.g. HtmlSanitizer) before Html.Raw."))

        for match in self._HTML_STRING.finditer(clean):
            arg = match.group("arg")
            if _is_literal_expr(arg) or self._JSON.search(arg):
                continue
            findings.append(_template_finding(
                "RAZOR-X001", Severity.MEDIUM,
                clean.count("\n", 0, match.start()) + 1, "CWE-79",
                "new HtmlString()/MvcHtmlString emits its argument as raw, "
                "unencoded markup - an XSS sink for any dynamic value.",
                "Return an encoded string, or sanitise the HTML server-side "
                "before wrapping it."))

        for block in self._SCRIPT_BLOCK.finditer(clean):
            if self._JSON.search(block.group(1)):
                continue
            base = block.start(1)
            for expr in self._RAZOR_EXPR.finditer(block.group(1)):
                findings.append(_template_finding(
                    "RAZOR-X002", Severity.MEDIUM,
                    clean.count("\n", 0, base + expr.start()) + 1, "CWE-79",
                    "Razor value rendered into a <script> block - HTML "
                    "encoding does not make it safe in JavaScript context.",
                    "Emit data for JavaScript as JSON "
                    "(@Html.Raw(Json.Serialize(model))), not a bare @expr."))
        return findings
