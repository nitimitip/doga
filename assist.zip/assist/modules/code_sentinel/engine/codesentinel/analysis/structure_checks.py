"""
Structural syntax validation for languages without a bundled parser:
shell scripts, SQL / PL/SQL, VB.NET, Classic ASP (VBScript) and ASP.NET
Web Forms markup.

Each checker runs a small lexer (strings, comments, here-documents and
server-script delimiters are understood) and then verifies what a compiler
or interpreter would reject outright:

  * a string, comment, here-string or substitution that never closes,
  * block keywords that do not pair up (if/fi, LOOP/END LOOP, For/Next ...),
  * unbalanced parentheses in SQL, unclosed <% %> server blocks.

Only the FIRST structural error of a file is reported - like a compiler,
everything after it would be noise. The checks are deliberately
conservative: a construct the lexer does not model is skipped rather than
guessed at, because a false syntax failure fails the quality gate.

The module also hosts the file-level bug checks for the same languages
that need statement context rather than a single line (PL/SQL cursor leaks
and trigger commits, Classic ASP error-suppression scope, missing
Option Explicit).
"""

from __future__ import annotations

import re

from ..domain.models import Finding, RiskCategory, Severity

TOOL_NAME = "sentinel-syntax"

#: Rule ids whose finding means the file cannot be parsed or run.
SYNTAX_RULE_IDS = frozenset({
    "SYN-SH001", "SYN-SH002",
    "SYN-SQL001", "SYN-SQL002", "SYN-PLSQL001",
    "SYN-VB001", "SYN-ASP001", "SYN-ASP002", "SYN-ASPX001",
})


def _syntax(rule_id: str, line: int, message: str, remediation: str,
            severity: Severity = Severity.HIGH) -> Finding:
    return Finding(tool=TOOL_NAME, rule_id=rule_id, severity=severity,
                   line=max(1, line), category=RiskCategory.RELIABILITY,
                   cwe="CWE-1078", message=message, remediation=remediation)


def _line_of(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


# ===========================================================================
# Shell (POSIX sh / bash / ksh)
# ===========================================================================

_SH_CLOSERS = {"fi": "if", "done": "loop", "esac": "case"}
_SH_OPEN = {"if": "if", "for": "loop", "while": "loop", "until": "loop",
            "select": "loop", "case": "case"}
_SH_EXPECT = {"if": "fi", "loop": "done", "case": "esac"}
_SH_WORD_END = set(" \t\n;&|()<>")
_HEREDOC = re.compile(r"<<(-?)[ \t]*(?:'([^'\n]+)'|\"([^\"\n]+)\"|\\?([A-Za-z_0-9.\-]+))")


class ShellSyntaxChecker:
    """
    Quote / substitution / here-document termination and block-keyword
    pairing (if..fi, case..esac, for|while|until|select..done) for shell
    scripts - what `bash -n` rejects, without running a shell.
    """

    def scan(self, text: str) -> list[Finding]:
        try:
            error = self._check(text)
        except RecursionError:
            return []
        return [error] if error else []

    def _check(self, text: str):
        n = len(text)
        i = 0
        # Context stack: ("top"|"subst"|"dq"|"sq"|"ansi"|"bt"|"brace"|"arith", start, depth)
        ctx = [["top", 0, 0]]
        blocks: list = []        # [kind, line, case_mode]
        cmd_pos = True
        pending_heredocs: list = []
        line_start = True

        def fail(rule, index, message, remediation):
            return _syntax(rule, _line_of(text, index), message, remediation)

        while i < n:
            c = text[i]
            kind = ctx[-1][0]

            if kind == "sq":
                if c == "'":
                    ctx.pop()
                i += 1
                continue
            if kind == "ansi":
                if c == "\\":
                    i += 2
                    continue
                if c == "'":
                    ctx.pop()
                i += 1
                continue
            if kind == "dq":
                if c == "\\":
                    i += 2
                    continue
                if c == '"':
                    ctx.pop()
                    i += 1
                    continue
                if text.startswith("$((", i):
                    ctx.append(["arith", i, 2])
                    i += 3
                    continue
                if text.startswith("$(", i):
                    ctx.append(["subst", i, 1])
                    cmd_pos = True
                    i += 2
                    continue
                if text.startswith("${", i):
                    ctx.append(["brace", i, 1])
                    i += 2
                    continue
                if c == "`":
                    ctx.append(["bt", i, 0])
                    cmd_pos = True
                    i += 1
                    continue
                i += 1
                continue
            if kind == "brace":
                if c == "\\":
                    i += 2
                    continue
                if c == "{":
                    ctx[-1][2] += 1
                elif c == "}":
                    ctx[-1][2] -= 1
                    if ctx[-1][2] == 0:
                        ctx.pop()
                elif c == '"':
                    ctx.append(["dq", i, 0])
                elif c == "'":
                    ctx.append(["sq", i, 0])
                i += 1
                continue
            if kind == "arith":
                if c == "(":
                    ctx[-1][2] += 1
                elif c == ")":
                    ctx[-1][2] -= 1
                    if ctx[-1][2] == 0:
                        ctx.pop()
                i += 1
                continue

            # ---- top / subst / bt: shell command syntax ---------------------
            if c == "\n":
                if pending_heredocs:
                    i = self._skip_heredocs(text, i + 1, pending_heredocs)
                    pending_heredocs = []
                    if i < 0:
                        return None      # unterminated here-doc: bash only warns
                else:
                    i += 1
                cmd_pos = True
                line_start = True
                continue
            if c in " \t":
                i += 1
                continue
            if c == "\\":
                i += 2
                continue
            if c == "#" and (line_start or text[i - 1] in " \t;&|()"):
                end = text.find("\n", i)
                i = n if end < 0 else end
                continue
            line_start = False
            if c == "'":
                ctx.append(["sq", i, 0])
                cmd_pos = False
                i += 1
                continue
            if c == '"':
                ctx.append(["dq", i, 0])
                cmd_pos = False
                i += 1
                continue
            if text.startswith("$'", i):
                ctx.append(["ansi", i, 0])
                cmd_pos = False
                i += 2
                continue
            if text.startswith("$((", i):
                ctx.append(["arith", i, 2])
                cmd_pos = False
                i += 3
                continue
            if text.startswith("$(", i):
                ctx.append(["subst", i, 1])
                cmd_pos = True
                i += 2
                continue
            if text.startswith("${", i):
                ctx.append(["brace", i, 1])
                cmd_pos = False
                i += 2
                continue
            if c == "`":
                if kind == "bt":
                    ctx.pop()
                else:
                    ctx.append(["bt", i, 0])
                    cmd_pos = True
                i += 1
                continue
            if c == "(":
                if blocks and blocks[-1][0] == "case" and blocks[-1][2] == "pattern" \
                        and blocks[-1][3] == len(ctx):
                    i += 1              # optional '(' before a case pattern
                    continue
                if kind == "subst":
                    ctx[-1][2] += 1
                cmd_pos = True
                i += 1
                continue
            if c == ")":
                if blocks and blocks[-1][0] == "case" and blocks[-1][2] == "pattern" \
                        and blocks[-1][3] == len(ctx):
                    blocks[-1][2] = "body"
                    cmd_pos = True
                    i += 1
                    continue
                if kind == "subst":
                    ctx[-1][2] -= 1
                    if ctx[-1][2] == 0:
                        ctx.pop()
                        cmd_pos = False
                        i += 1
                        continue
                cmd_pos = True
                i += 1
                continue
            if c in ";&|":
                if text.startswith(";;", i) and blocks and blocks[-1][0] == "case":
                    blocks[-1][2] = "pattern"
                    i += 3 if text.startswith((";;&",), i) else 2
                    cmd_pos = True
                    continue
                if text.startswith(";&", i) and blocks and blocks[-1][0] == "case":
                    blocks[-1][2] = "pattern"
                    i += 2
                    cmd_pos = True
                    continue
                cmd_pos = True
                i += 1
                continue
            if c == "<":
                match = _HEREDOC.match(text, i)
                if match and not text.startswith("<<<", i):
                    delimiter = match.group(2) or match.group(3) or match.group(4)
                    pending_heredocs.append((delimiter, match.group(1) == "-"))
                    i = match.end()
                    continue
                i += 1
                continue
            if c in ">{}":
                if c == "{" and cmd_pos:
                    pass
                i += 1
                continue

            # ---- a word -----------------------------------------------------
            start = i
            while i < n and text[i] not in _SH_WORD_END and text[i] not in "'\"`$\\":
                i += 1
            if i == start:          # a lone '$' or similar
                i += 1
                cmd_pos = False
                continue
            word = text[start:i]
            boundary = i >= n or text[i] in _SH_WORD_END
            in_pattern = blocks and blocks[-1][0] == "case" and blocks[-1][2] == "pattern" \
                and blocks[-1][3] == len(ctx)
            if in_pattern:
                if word == "esac" and boundary:
                    blocks.pop()
                    cmd_pos = False
                continue
            if not (cmd_pos and boundary):
                if blocks and blocks[-1][0] == "case" and blocks[-1][2] == "subject" \
                        and word == "in" and boundary:
                    blocks[-1][2] = "pattern"
                    cmd_pos = True
                    continue
                cmd_pos = cmd_pos and "=" in word and re.match(r"[A-Za-z_]\w*(\[[^\]]*\])?\+?=", word) is not None
                continue
            line = _line_of(text, start)
            if word in _SH_OPEN:
                opener = _SH_OPEN[word]
                blocks.append([opener, line, "subject" if opener == "case" else "", len(ctx)])
                cmd_pos = word == "if" or word in ("while", "until")
                if opener == "loop" and word in ("for", "select"):
                    cmd_pos = False
                continue
            if word in _SH_CLOSERS:
                expected = _SH_CLOSERS[word]
                if not blocks or blocks[-1][3] != len(ctx):
                    return fail("SYN-SH002", start,
                                f"'{word}' without a matching '{self._opener_word(expected)}' "
                                f"- the shell rejects the script with a syntax error.",
                                f"Remove the stray '{word}' or add the missing opening keyword.")
                top = blocks[-1]
                if top[0] != expected:
                    return fail("SYN-SH002", start,
                                f"'{word}' closes a block, but the innermost open block is "
                                f"'{self._opener_word(top[0])}' from line {top[1]}, which "
                                f"needs '{_SH_EXPECT[top[0]]}' first.",
                                f"Close the '{self._opener_word(top[0])}' block with "
                                f"'{_SH_EXPECT[top[0]]}' before this line.")
                blocks.pop()
                cmd_pos = False
                continue
            if word in ("then", "do", "else", "elif"):
                if word in ("else", "elif", "then") and (
                        not blocks or blocks[-1][0] != "if" or blocks[-1][3] != len(ctx)):
                    return fail("SYN-SH002", start,
                                f"'{word}' outside an if-block - the shell rejects the "
                                f"script with a syntax error.",
                                "Check the if/then/else/fi structure around this line.")
                if word == "do" and (not blocks or blocks[-1][0] != "loop"
                                     or blocks[-1][3] != len(ctx)):
                    return fail("SYN-SH002", start,
                                "'do' outside a for/while/until loop - the shell rejects "
                                "the script with a syntax error.",
                                "Check the loop header before this line.")
                cmd_pos = True
                continue
            if word in ("!", "time", "function", "coproc", "exec", "command", "builtin", "sudo"):
                cmd_pos = word in ("!", "time")
                continue
            cmd_pos = "=" in word and re.match(r"[A-Za-z_]\w*(\[[^\]]*\])?\+?=", word) is not None

        # ---- end of file ----------------------------------------------------
        if len(ctx) > 1:
            kind, start, _ = ctx[-1]
            what = {"sq": "single-quoted string", "dq": "double-quoted string",
                    "ansi": "$'...' string", "bt": "backtick command substitution",
                    "subst": "$( ) command substitution", "brace": "${ } expansion",
                    "arith": "$(( )) arithmetic expansion"}[kind]
            return fail("SYN-SH001", start,
                        f"Unterminated {what} opened here - the shell reports "
                        f"'unexpected EOF' and the script does not run.",
                        "Close the quote / substitution. Check for an apostrophe "
                        "inside single quotes (use '\\'' or double quotes).")
        if blocks:
            kind, line = blocks[-1][0], blocks[-1][1]
            return _syntax("SYN-SH002", line,
                           f"'{self._opener_word(kind)}' opened here is never closed with "
                           f"'{_SH_EXPECT[kind]}' - the shell reports a syntax error at "
                           f"end of file.",
                           f"Add the missing '{_SH_EXPECT[kind]}'.")
        return None

    @staticmethod
    def _opener_word(kind: str) -> str:
        return {"if": "if", "loop": "for/while/until", "case": "case"}[kind]

    @staticmethod
    def _skip_heredocs(text: str, i: int, pending: list) -> int:
        """Skip the bodies of pending here-documents; -1 when one never ends."""
        for delimiter, strip_tabs in pending:
            while True:
                if i >= len(text):
                    return -1
                end = text.find("\n", i)
                line = text[i:] if end < 0 else text[i:end]
                i = len(text) if end < 0 else end + 1
                candidate = line.lstrip("\t") if strip_tabs else line
                if candidate.rstrip("\r") == delimiter:
                    break
        return i


# ===========================================================================
# SQL / PL/SQL
# ===========================================================================

#: SQL*Plus client commands - not SQL, may contain unbalanced quotes.
_SQLPLUS_LINE = re.compile(
    r"^[ \t]*(?:REM(?:ARK)?\b|PRO(?:MPT)?\b|ACC(?:EPT)?\b|HOST\b|SPO(?:OL)?\b|"
    r"DEF(?:INE)?\b|UNDEF(?:INE)?\b|COL(?:UMN)?\b|TTI(?:TLE)?\b|BTI(?:TLE)?\b|"
    r"@@?[\w.\\/&$~-]+(?=[ \t]|$)(?![^\n]*\()|WHENEVER\b|CONN(?:ECT)?\b|SHO(?:W)?\b|VAR(?:IABLE)?\b|PAU(?:SE)?\b|"
    r"SET[ \t]+(?:SERVEROUT(?:PUT)?|ECHO|FEED(?:BACK)?|DEF(?:INE)?|VER(?:IFY)?|"
    r"LIN(?:ESIZE)?|PAGES(?:IZE)?|HEA(?:DING)?|TERM(?:OUT)?|TIMI(?:NG)?|TRIMS(?:POOL)?|"
    r"SQLBL(?:ANKLINES)?|SCAN|LONG|ARRAY(?:SIZE)?|COLSEP|NEWP(?:AGE)?|WRA(?:P)?|"
    r"TAB|TRIM(?:OUT)?|AUTO(?:COMMIT)?|ESC(?:APE)?|CON(?:CAT)?|NUMW(?:IDTH)?|"
    r"MARK(?:UP)?|APPI(?:NFO)?|SQLP(?:ROMPT)?|TIME)\b)[^\n]*",
    re.IGNORECASE | re.MULTILINE)
_Q_CLOSE = {"[": "]", "{": "}", "(": ")", "<": ">"}


def mask_sql(text: str, backslash_escapes: bool = False,
             bracket_identifiers: bool = False):
    """
    Blank SQL string literals, quoted identifiers and comments (newlines
    kept). Returns (masked_text, error) where error is (index, what) for a
    region that never closes.
    """
    text = _SQLPLUS_LINE.sub(lambda m: " " * len(m.group()), text)
    out = list(text)
    n = len(text)
    i = 0

    def blank(a, b):
        for k in range(a, min(b, n)):
            if out[k] != "\n":
                out[k] = " "

    while i < n:
        c = text[i]
        if text.startswith("--", i):
            end = text.find("\n", i)
            end = n if end < 0 else end
            blank(i, end)
            i = end
            continue
        if text.startswith("/*", i):
            end = text.find("*/", i + 2)
            if end < 0:
                return "".join(out), (i, "block comment")
            blank(i, end + 2)
            i = end + 2
            continue
        if c in "qQnN" and i + 2 < n and text[i + 1] == "'" and c in "qQ" \
                and (i == 0 or not (text[i - 1].isalnum() or text[i - 1] == "_")):
            opener = text[i + 2]
            closer = _Q_CLOSE.get(opener, opener) + "'"
            end = text.find(closer, i + 3)
            if end < 0:
                return "".join(out), (i, "q-quoted string")
            blank(i, end + 2)
            i = end + 2
            continue
        if c == "'":
            j = i + 1
            while j < n:
                if backslash_escapes and text[j] == "\\":
                    j += 2
                    continue
                if text[j] == "'":
                    if j + 1 < n and text[j + 1] == "'":
                        j += 2
                        continue
                    break
                j += 1
            if j >= n:
                return "".join(out), (i, "string literal")
            blank(i, j + 1)
            i = j + 1
            continue
        if c == "[" and bracket_identifiers:
            end = text.find("]", i + 1)
            newline = text.find("\n", i + 1)
            if end >= 0 and (newline < 0 or end < newline):
                blank(i, end + 1)
                i = end + 1
                continue
        if c == '"':
            end = text.find('"', i + 1)
            if end < 0:
                return "".join(out), (i, "quoted identifier")
            blank(i, end + 1)
            i = end + 1
            continue
        i += 1
    return "".join(out), None


class SqlSyntaxChecker:
    """
    Termination of strings/comments, parenthesis balance, and for PL/SQL
    the pairing of IF..END IF and LOOP..END LOOP.

    Plain .sql files can come from any dialect; a MySQL dump escapes quotes
    with a backslash, ANSI SQL doubles them. A plain SQL file is only
    reported when BOTH readings agree that the text is broken.
    """

    def __init__(self, plsql: bool) -> None:
        self.plsql = plsql

    def scan(self, text: str) -> list[Finding]:
        brackets = not self.plsql
        masked, error = mask_sql(text, bracket_identifiers=brackets)
        if error and not self.plsql:
            alt_masked, alt_error = mask_sql(text, backslash_escapes=True,
                                             bracket_identifiers=brackets)
            if alt_error is None:
                masked, error = alt_masked, None
        if error:
            index, what = error
            return [_syntax("SYN-SQL001", _line_of(text, index),
                            f"Unterminated {what} opened here - the statement cannot be "
                            f"parsed and everything after it is swallowed.",
                            "Close the literal/comment. Inside a string, write a "
                            "single quote as two quotes ('')."
                            )]
        paren = self._paren_error(masked)
        if paren and not self.plsql:
            alt_masked, alt_error = mask_sql(text, backslash_escapes=True,
                                             bracket_identifiers=True)
            if alt_error is None and self._paren_error(alt_masked) is None:
                paren = None
        if paren:
            index, message = paren
            return [_syntax("SYN-SQL002", _line_of(text, index), message,
                            "Balance the parentheses of this statement.")]
        if self.plsql:
            block = self._block_error(masked)
            if block:
                return [block]
        return []

    @staticmethod
    def _paren_error(masked: str):
        stack = []
        for index, c in enumerate(masked):
            if c == "(":
                stack.append(index)
            elif c == ")":
                if not stack:
                    return index, "Closing parenthesis without a matching '(' - the statement does not parse."
                stack.pop()
        if stack:
            return stack[-1], "Parenthesis opened here is never closed - the statement does not parse."
        return None

    #: `$IF/$ELSIF/$END` (conditional compilation) is matched first as a
    #: unit so `$END` is never read as the END of a following IF.
    _TOKENS = re.compile(r"\$[A-Z]+\b|\bEND\s+(IF|LOOP)\b|\b(IF|LOOP|ELSIF|ELSE)\b",
                         re.IGNORECASE)

    def _block_error(self, masked: str):
        stack: list = []
        for match in self._TOKENS.finditer(masked):
            if match.group().startswith("$"):
                continue            # conditional compilation: $IF ... $END
            line = _line_of(masked, match.start())
            if match.group(2) and match.group(2).upper() == "IF" and \
                    re.match(r"\s+(NOT\s+)?EXISTS\b", masked[match.end():], re.IGNORECASE):
                continue            # DROP/CREATE ... IF [NOT] EXISTS (23ai)
            if match.group(1):
                kind = match.group(1).upper()
                if not stack:
                    return _syntax("SYN-PLSQL001", line,
                                   f"END {kind} without a matching {kind} - the unit does not "
                                   f"compile (PLS-00103).",
                                   f"Remove the stray END {kind}, or restore the {kind} it closes.")
                if stack[-1][0] != kind:
                    open_kind, open_line = stack[-1]
                    return _syntax("SYN-PLSQL001", line,
                                   f"END {kind} found while the {open_kind} opened at line "
                                   f"{open_line} is still open - the unit does not compile "
                                   f"(PLS-00103).",
                                   f"Close the {open_kind} with END {open_kind} first.")
                stack.pop()
                continue
            word = match.group(2).upper()
            if word in ("IF", "LOOP"):
                stack.append((word, line))
            elif word == "ELSIF" and (not stack or stack[-1][0] != "IF"):
                return _syntax("SYN-PLSQL001", line,
                               "ELSIF outside an IF block - the unit does not compile "
                               "(PLS-00103).",
                               "Check the IF / ELSIF / END IF structure.")
        if stack:
            kind, line = stack[-1]
            return _syntax("SYN-PLSQL001", line,
                           f"{kind} opened here is never closed with END {kind} - the unit "
                           f"does not compile (PLS-00103).",
                           f"Add the missing END {kind};")
        return None


class PlsqlBugChecker:
    """
    PL/SQL defects that need statement context:

      PLSQL-B011  cursor OPENed but never CLOSEd in the file (ORA-01000)
      PLSQL-B013  COMMIT/ROLLBACK in a trigger without an autonomous
                  transaction (ORA-04092 at run time)
    """

    _OPEN = re.compile(r"\bOPEN\s+([A-Za-z_][\w$#]*)\b(?!\s*\.)", re.IGNORECASE)
    _CREATE_TRIGGER = re.compile(r"\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:EDITIONABLE\s+|NONEDITIONABLE\s+)?TRIGGER\b",
                                 re.IGNORECASE)
    _CREATE_ANY = re.compile(r"\bCREATE\s+(?:OR\s+REPLACE\s+)?", re.IGNORECASE)

    def scan(self, text: str) -> list[Finding]:
        masked, error = mask_sql(text)
        if error:
            return []
        findings: list[Finding] = []
        upper = masked.upper()
        for match in self._OPEN.finditer(masked):
            name = match.group(1).upper()
            if name in ("FOR", "CURSOR"):
                continue
            if not re.search(r"\bCLOSE\s+" + re.escape(name) + r"\b", upper) \
                    and not re.search(r"\bFOR\s+\w+\s+IN\s+" + re.escape(name) + r"\b", upper):
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="PLSQL-B011", severity=Severity.MEDIUM,
                    line=_line_of(masked, match.start()),
                    category=RiskCategory.RELIABILITY, cwe="CWE-772",
                    message=f"Cursor {match.group(1)} is opened but never closed in this "
                            f"file - each call leaks an open cursor until the session "
                            f"hits ORA-01000 (maximum open cursors exceeded).",
                    remediation="CLOSE the cursor on every path, including the exception "
                                "handler (IF c%ISOPEN THEN CLOSE c; END IF;), or use a "
                                "cursor FOR loop which closes automatically.",
                ))
        starts = [m.start() for m in self._CREATE_ANY.finditer(masked)] + [len(masked)]
        for index, start in enumerate(starts[:-1]):
            unit = masked[start:starts[index + 1]]
            if not self._CREATE_TRIGGER.match(unit):
                continue
            if re.search(r"PRAGMA\s+AUTONOMOUS_TRANSACTION", unit, re.IGNORECASE):
                continue
            commit = re.search(r"\b(COMMIT|ROLLBACK)\b(?!\s+TO\b)", unit, re.IGNORECASE)
            if commit:
                findings.append(Finding(
                    tool=TOOL_NAME, rule_id="PLSQL-B013", severity=Severity.HIGH,
                    line=_line_of(masked, start + commit.start()),
                    category=RiskCategory.RELIABILITY, cwe="CWE-662",
                    message=f"{commit.group(1).upper()} inside a trigger - Oracle raises "
                            f"ORA-04092 when the trigger fires, so the triggering DML "
                            f"fails.",
                    remediation="Let the calling transaction commit. If an independent "
                                "commit is really needed (audit logging), move it into a "
                                "procedure declared PRAGMA AUTONOMOUS_TRANSACTION.",
                ))
        return findings


# ===========================================================================
# VB family: VB.NET and Classic ASP (VBScript)
# ===========================================================================

_VB_STRING = re.compile(r'"(?:[^"\n]|"")*"?')


def _vb_logical_lines(lines):
    """
    Yield (line_no, code) per logical VB line: comments removed, strings
    blanked, `_` continuations joined. Code is upper-cased for matching.
    """
    buffer, first = "", None
    for line_no, raw in lines:
        code = _VB_STRING.sub(lambda m: '"' + " " * max(0, len(m.group()) - 2) + '"', raw)
        quote = code.find("'")
        if quote >= 0:
            code = code[:quote]
        stripped = code.strip()
        if re.match(r"REM(\s|$)", stripped, re.IGNORECASE):
            stripped = ""
        if first is None:
            first = line_no
        if stripped.endswith(" _") or stripped == "_":
            buffer += stripped[:-1] + " "
            continue
        yield first, (buffer + stripped).upper()
        buffer, first = "", None
    if buffer:
        yield first, buffer.upper()


def _split_statements(code: str):
    """Split a logical line on ':' statement separators (strings are blanked)."""
    parts, depth, current = [], 0, []
    for index, c in enumerate(code):
        if c == "(":
            depth += 1
        elif c == ")":
            depth = max(0, depth - 1)
        if c == ":" and depth == 0 and not code.startswith(":=", index) \
                and not (index > 0 and code[index - 1] == ":"):
            parts.append("".join(current).strip())
            current = []
            continue
        current.append(c)
    parts.append("".join(current).strip())
    return [p for p in parts if p]


class VbBlockChecker:
    """
    Block pairing for VBScript (Classic ASP) and VB.NET: If/End If,
    For/Next, Do/Loop, While/Wend|End While, Select Case/End Select,
    With/End With, plus Sub/Function/Property/Class (VBScript) and
    Try/Using/SyncLock (VB.NET).

    Single-line If (`If x Then y`) is recognised; VB.NET Sub/Function are
    not tracked because multi-line lambdas share their End keywords.
    """

    def __init__(self, dialect: str) -> None:
        self.dialect = dialect          # "vbscript" | "vbnet"
        self.rule_id = "SYN-VB001" if dialect == "vbnet" else "SYN-ASP002"
        self.label = "VB.NET" if dialect == "vbnet" else "VBScript"

    def check(self, lines) -> Finding | None:
        stack: list = []                # [kind, line]
        self._pending_if = None
        for line_no, code in _vb_logical_lines(lines):
            if not code or code.startswith("#"):
                continue
            error = self._logical_line(line_no, code, stack)
            if error:
                return error
        if stack:
            kind, line = stack[-1]
            return self._error(line, f"'{self._opener_text(kind)}' opened here is never closed "
                                     f"with '{self._closer_text(kind)}'.",
                               f"Add the missing '{self._closer_text(kind)}'.")
        return None

    def _error(self, line: int, detail: str, remediation: str) -> Finding:
        return _syntax(self.rule_id, line,
                       f"{self.label} block structure error: {detail} The "
                       f"{'project does not compile' if self.dialect == 'vbnet' else 'page fails with a compilation error'}.",
                       remediation)

    @staticmethod
    def _opener_text(kind: str) -> str:
        return {"IF": "If ... Then", "FOR": "For", "DO": "Do", "WHILE": "While",
                "SELECT": "Select Case", "WITH": "With", "SUB": "Sub",
                "FUNCTION": "Function", "PROPERTY": "Property", "CLASS": "Class",
                "TRY": "Try", "USING": "Using", "SYNCLOCK": "SyncLock"}[kind]

    def _closer_text(self, kind: str) -> str:
        if kind == "WHILE":
            return "End While" if self.dialect == "vbnet" else "Wend"
        return {"FOR": "Next", "DO": "Loop"}.get(kind, "End " + self._opener_text(kind).split()[0])

    def _logical_line(self, line_no: int, code: str, stack: list):
        if self._pending_if is not None:
            # VB.NET implicit line continuation: the If condition spans
            # lines until its Then.
            opener_line, is_elseif, waited = self._pending_if
            then = re.search(r"\bTHEN\b(.*)$", code)
            if then:
                self._pending_if = None
                if not is_elseif and not then.group(1).strip():
                    stack.append(["IF", opener_line])
            elif waited >= 20:
                self._pending_if = None     # not an If we understand; stop waiting
            else:
                self._pending_if = (opener_line, is_elseif, waited + 1)
            return None
        if re.match(r"ELSEIF\b", code):
            if not stack or stack[-1][0] != "IF":
                return self._error(line_no, "'ElseIf' without an open 'If' block.",
                                   "Check the If / ElseIf / End If structure.")
            if not re.search(r"\bTHEN\b", code):
                self._pending_if = (line_no, True, 0)
            return None
        if re.match(r"ELSE\s+IF\b", code):
            # `Else If` = Else followed by a NESTED If needing its own End If.
            if not stack or stack[-1][0] != "IF":
                return self._error(line_no, "'Else' without an open 'If' block.",
                                   "Check the If / Else / End If structure.")
            code = code[4:].strip()
        # The If statement owns the rest of the line (including ':' parts):
        # anything after Then makes it a single-line If.
        head = re.search(r"(?:^|:)\s*IF\b", code)
        if head:
            for statement in _split_statements(code[:head.start()]):
                error = self._statement(line_no, statement, stack)
                if error:
                    return error
            then = re.search(r"\bTHEN\b(.*)$", code[head.end():])
            if then is None:
                self._pending_if = (line_no, False, 0)
            elif not then.group(1).strip():
                stack.append(["IF", line_no])
            return None
        for statement in _split_statements(code):
            error = self._statement(line_no, statement, stack)
            if error:
                return error
        return None

    def _statement(self, line_no: int, s: str, stack: list):
        s = re.sub(r"^(?:(?:PUBLIC|PRIVATE|PROTECTED|FRIEND|SHARED|DEFAULT|STATIC|OVERRIDES|"
                   r"OVERRIDABLE|OVERLOADS|NOTOVERRIDABLE|MUSTOVERRIDE|SHADOWS|READONLY|"
                   r"PARTIAL|ASYNC|ITERATOR|WITHEVENTS|WIDENING|NARROWING)\s+)+", "", s)
        word = re.match(r"[A-Z_]\w*", s)
        if not word:
            return None
        token = word.group()
        after = s[word.end():word.end() + 1]
        if after in ("(", ".", "=") and token not in ("IF", "SELECT"):
            if not (token in ("FOR", "DO", "WHILE", "WITH", "USING", "SYNCLOCK")
                    and after == "("):
                return None             # member access / call / assignment
        if after == ":" and self.dialect == "vbnet":
            return None                 # label
        rest = s[word.end():].strip()
        vbnet = self.dialect == "vbnet"

        def push(kind):
            stack.append([kind, line_no])
            return None

        def pop(kind, text):
            if not stack:
                return self._error(line_no, f"'{text}' without a matching "
                                            f"'{self._opener_text(kind)}'.",
                                   f"Remove the stray '{text}' or restore its opening statement.")
            if stack[-1][0] != kind:
                open_kind, open_line = stack[-1]
                return self._error(line_no, f"'{text}' found while '{self._opener_text(open_kind)}' "
                                            f"from line {open_line} is still open.",
                                   f"Close '{self._opener_text(open_kind)}' with "
                                   f"'{self._closer_text(open_kind)}' first.")
            stack.pop()
            return None

        if token == "IF":
            return None                 # If without Then: handled in _logical_line / expression
        if token in ("ELSE", "ELSEIF"):
            if not stack or stack[-1][0] != "IF":
                if vbnet and stack and stack[-1][0] == "SELECT":
                    return None         # Case Else
                return self._error(line_no, f"'{token.title()}' without an open 'If' block.",
                                   "Check the If / Else / End If structure.")
            return None
        if token == "END":
            what = re.match(r"([A-Z]+)", rest)
            if not what:
                return None             # bare End statement
            target = what.group(1)
            mapping = {"IF": "IF", "SELECT": "SELECT", "WITH": "WITH"}
            if vbnet:
                mapping.update({"WHILE": "WHILE", "TRY": "TRY", "USING": "USING",
                                "SYNCLOCK": "SYNCLOCK"})
            else:
                mapping.update({"SUB": "SUB", "FUNCTION": "FUNCTION",
                                "PROPERTY": "PROPERTY", "CLASS": "CLASS"})
            if target in mapping:
                return pop(mapping[target], "End " + target.title())
            return None
        if token == "FOR":
            return push("FOR")
        if token == "NEXT":
            count = max(1, len([v for v in rest.split(",") if v.strip()]))
            for _ in range(count):
                error = pop("FOR", "Next")
                if error:
                    return error
            return None
        if token == "DO":
            return push("DO")
        if token == "LOOP":
            return pop("DO", "Loop")
        if token == "WHILE":
            return push("WHILE")
        if token == "WEND" and not vbnet:
            return pop("WHILE", "Wend")
        if token == "SELECT" and rest.startswith("CASE"):
            return push("SELECT")
        if token == "WITH" and rest and not rest.startswith("{"):
            return push("WITH")
        if vbnet:
            if token == "TRY" and not rest:
                return push("TRY")
            if token in ("CATCH", "FINALLY"):
                if not stack or stack[-1][0] != "TRY":
                    return self._error(line_no, f"'{token.title()}' without an open 'Try' block.",
                                       "Check the Try / Catch / Finally / End Try structure.")
                return None
            if token == "USING" and rest:
                return push("USING")
            if token == "SYNCLOCK" and rest:
                return push("SYNCLOCK")
            return None
        if token in ("SUB", "FUNCTION") and re.match(r"[A-Z_]\w*", rest):
            return push(token)
        if token == "PROPERTY" and re.match(r"(GET|LET|SET)\s+[A-Z_]", rest):
            return push("PROPERTY")
        if token == "CLASS" and re.match(r"[A-Z_]\w*", rest):
            return push("CLASS")
        return None


class VbNetChecker:
    """VB.NET structural validation."""

    def scan(self, text: str) -> list[Finding]:
        error = VbBlockChecker("vbnet").check(enumerate(text.splitlines(), start=1))
        return [error] if error else []


# ===========================================================================
# Classic ASP
# ===========================================================================

_SERVER_SCRIPT = re.compile(
    r"<script\b[^>]*\brunat\s*=\s*[\"']?server[\"']?[^>]*>", re.IGNORECASE)


def asp_code_lines(text: str):
    """
    (line_no, code) for every VBScript line inside <% %> blocks and
    <script runat="server" language="vbscript"> elements, with the
    position of the first unclosed delimiter (or None).
    """
    regions = []
    unclosed = None
    i = 0
    n = len(text)
    while i < n:
        start = text.find("<%", i)
        script = _SERVER_SCRIPT.search(text, i)
        if script and (start < 0 or script.start() < start):
            end = text.lower().find("</script>", script.end())
            if end < 0:
                unclosed = (script.start(), "<script runat=\"server\">")
                break
            language = re.search(r"language\s*=\s*[\"']?(\w+)", script.group(), re.IGNORECASE)
            if language is None or language.group(1).lower() in ("vbscript", "vbs"):
                regions.append((script.end(), end))
            i = end + 9
            continue
        if start < 0:
            break
        end = text.find("%>", start + 2)
        if end < 0:
            unclosed = (start, "<%")
            break
        body_start = start + 2
        marker = text[body_start:body_start + 1]
        if marker not in ("@", "=", "#", "-", ":"):
            regions.append((body_start, end))
        i = end + 2
    lines = []
    for a, b in regions:
        first = _line_of(text, a)
        for offset, line in enumerate(text[a:b].split("\n")):
            lines.append((first + offset, line))
    return lines, unclosed


class ClassicAspChecker:
    """
    Classic ASP: delimiter pairing (<% %>, server <script>), VBScript block
    structure, and the page-level bug checks:

      ASP-Q002  page without Option Explicit (typos become new variables)
      ASP-B010  On Error Resume Next with no Err check anywhere after it
    """

    def scan(self, text: str, path_name: str = "") -> list[Finding]:
        lines, unclosed = asp_code_lines(text)
        findings: list[Finding] = []
        if unclosed:
            index, what = unclosed
            findings.append(_syntax(
                "SYN-ASP001", _line_of(text, index),
                f"Server-script block '{what}' opened here is never closed - ASP "
                f"fails the whole page with a compilation error.",
                "Add the closing '%>' (or '</script>')."))
            return findings
        error = VbBlockChecker("vbscript").check(lines)
        if error:
            findings.append(error)
        code = "\n".join(line for _, line in lines)
        code_upper = re.sub(r"'[^\n]*", "", code).upper()
        if path_name.lower().endswith(".asp") and re.search(r"\b(DIM|SET)\b|=", code_upper) \
                and not re.search(r"^\s*OPTION\s+EXPLICIT\b", code_upper, re.MULTILINE):
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="ASP-Q002", severity=Severity.LOW,
                line=lines[0][0] if lines else 1, category=RiskCategory.MAINTAINABILITY,
                cwe="CWE-457",
                message="Page does not declare 'Option Explicit' - a mistyped variable "
                        "name silently creates a new, empty variable instead of an "
                        "error.",
                remediation="Add <% Option Explicit %> as the first statement of the page "
                            "and declare every variable with Dim.",
            ))
        for line_no, raw in lines:
            if re.match(r"\s*ON\s+ERROR\s+RESUME\s+NEXT\b", raw, re.IGNORECASE):
                tail = "\n".join(l for n_, l in lines if n_ > line_no).upper()
                if not re.search(r"\bERR\s*(\.\s*NUMBER|\s*<>|\s*=|\s*\.\s*CLEAR|\.DESCRIPTION)|"
                                 r"\bON\s+ERROR\s+GOTO\s+0\b|\bIF\s+ERR\b", tail):
                    findings.append(Finding(
                        tool=TOOL_NAME, rule_id="ASP-B010", severity=Severity.MEDIUM,
                        line=line_no, category=RiskCategory.RELIABILITY, cwe="CWE-391",
                        message="'On Error Resume Next' with no Err.Number check after it - "
                                "every runtime error in the rest of the scope (failed "
                                "database calls included) is silently ignored and "
                                "execution continues with bad state.",
                        remediation="Check Err.Number immediately after the statement that "
                                    "may fail, then restore normal handling with "
                                    "'On Error GoTo 0'.",
                    ))
                break
        return findings


# ===========================================================================
# ASP.NET Web Forms markup
# ===========================================================================

class AspNetMarkupChecker:
    """<% %> / <%-- --%> / server <script> pairing in .aspx/.ascx/.master."""

    def scan(self, text: str) -> list[Finding]:
        i, n = 0, len(text)
        while i < n:
            start = text.find("<%", i)
            script = _SERVER_SCRIPT.search(text, i)
            if script and (start < 0 or script.start() < start):
                end = text.lower().find("</script>", script.end())
                if end < 0:
                    return [self._error(text, script.start(), '<script runat="server">',
                                        "</script>")]
                i = end + 9
                continue
            if start < 0:
                return []
            if text.startswith("<%--", start):
                end = text.find("--%>", start + 4)
                if end < 0:
                    return [self._error(text, start, "<%--", "--%>")]
                i = end + 4
                continue
            end = text.find("%>", start + 2)
            if end < 0:
                return [self._error(text, start, "<%", "%>")]
            i = end + 2
        return []

    @staticmethod
    def _error(text: str, index: int, opener: str, closer: str) -> Finding:
        return _syntax("SYN-ASPX001", _line_of(text, index),
                       f"'{opener}' opened here is never closed with '{closer}' - the "
                       f"page parser rejects the file (HTTP 500 at first request).",
                       f"Add the missing '{closer}'.")


def aspnet_code_language(text: str) -> str:
    """Language id of the inline server code of an ASP.NET page."""
    directive = re.search(r"<%@\s*(?:Page|Control|Master|WebHandler|WebService|Application)\b[^%]*?"
                          r"\bLanguage\s*=\s*[\"']?(\w+)", text, re.IGNORECASE)
    if directive and directive.group(1).lower() in ("vb", "vbnet", "visualbasic"):
        return "vbnet"
    return "csharp"


# ===========================================================================
# C# composite format strings
# ===========================================================================

_FORMAT_CALL = re.compile(
    r"\b(?:[Ss]tring\.Format|Console\.Write(?:Line)?|\w+\.AppendFormat|"
    r"\w+\.(?:WriteLine|Write)|\w+\.Log(?:Information|Warning|Error|Debug|Trace|Critical))\s*\(")
def _cs_literal_end(text: str, i: int, verbatim: bool) -> int:
    """Index just past a C# string literal whose body starts at `i`; -1 if open."""
    while i < len(text):
        c = text[i]
        if verbatim:
            if c == '"':
                if text.startswith('""', i):
                    i += 2
                    continue
                return i + 1
        else:
            if c == "\\":
                i += 2
                continue
            if c == "\n":
                return -1
            if c == '"':
                return i + 1
        i += 1
    return -1


def _split_args(text: str, start: int):
    """Top-level comma-separated arguments from `start` (just after '(')."""
    args, depth, current, i = [], 0, [], start
    while i < len(text):
        c = text[i]
        prefix = next((p for p in ('$@"', '@$"', '$"', '@"', '"') if text.startswith(p, i)), None)
        if prefix:
            end = _cs_literal_end(text, i + len(prefix), "@" in prefix)
            if end < 0:
                return None
            current.append(text[i:end])
            i = end
            continue
        if c == "'":
            end = text.find("'", i + 2 if text[i + 1:i + 2] == "\\" else i + 1)
            if end < 0:
                return None
            current.append(text[i:end + 1])
            i = end + 1
            continue
        if c in "([{":
            depth += 1
        elif c in ")]}":
            if depth == 0:
                args.append("".join(current).strip())
                return [a for a in args if a] if any(args) else []
            depth -= 1
        elif c == "," and depth == 0:
            args.append("".join(current).strip())
            current = []
            i += 1
            continue
        elif c == ";" and depth == 0:
            return None
        current.append(c)
        i += 1
    return None


class CSharpFormatChecker:
    """
    CS-B013: a composite format string refers to an argument index that is
    not supplied - FormatException every time the line runs. Only literal
    format strings are checked; a single non-literal argument may be an
    object[] and is skipped.
    """

    def scan(self, text: str) -> list[Finding]:
        findings: list[Finding] = []
        for match in _FORMAT_CALL.finditer(text):
            args = _split_args(text, match.end())
            if not args:
                continue
            first = 1 if args and not args[0].startswith(('"', '@"')) and len(args) > 1 \
                and args[1].startswith(('"', '@"')) else 0     # IFormatProvider first
            fmt = args[first]
            if not fmt.startswith(('"', '@"')):
                continue
            body = fmt[2:-1] if fmt.startswith('@') else fmt[1:-1]
            body = body.replace("{{", "").replace("}}", "")
            indexes = [int(m.group(1)) for m in re.finditer(r"\{(\d+)(?:,[^}]*)?(?::[^}]*)?\}", body)]
            if not indexes:
                continue
            values = args[first + 1:]
            if "Log" in match.group() and not match.group().startswith(("String", "string")):
                continue            # structured logging uses named holes
            if len(values) == 1 and not re.match(r'^(?:"|@"|\d|true\b|false\b|null\b)', values[0]):
                continue            # may be an object[]
            if max(indexes) >= len(values):
                findings.append(Finding(
                    tool="sentinel-ast", rule_id="CS-B013", severity=Severity.HIGH,
                    line=_line_of(text, match.start()), category=RiskCategory.RELIABILITY,
                    cwe="CWE-685",
                    message=f"The format string uses {{{max(indexes)}}} but only "
                            f"{len(values)} argument(s) follow it - this throws "
                            f"FormatException every time it runs.",
                    remediation="Pass a value for every placeholder, or renumber the "
                                "placeholders (or use an interpolated string).",
                ))
        return findings
