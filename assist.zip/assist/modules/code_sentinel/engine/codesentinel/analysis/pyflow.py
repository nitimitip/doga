"""
Python scope resolution and intraprocedural value tracking.

Two analyses share one scope model:

  * Scope resolution (PY-Q008). Bindings are tracked separately for module,
    function, class and comprehension scopes and names are resolved with
    Python's real rules: a nested function or comprehension does NOT see the
    names of an enclosing class body, `global`/`nonlocal` redirect a binding,
    and the first iterator of a comprehension is evaluated in the enclosing
    scope. A read that resolves nowhere (and is not a builtin) is a NameError.

  * Value tracking (PY-Q009, PY-Q010, PY-Q007). Each local of a function
    (and each module-level name) carries an abstract value drawn from five
    kinds - unbound, None, zero, nonzero number, anything else - propagated
    through assignments and merged across branches, loops (to a fixpoint)
    and exception handlers. Conditions narrow the value on each branch
    (`if x is None: return`, `if not count:`). Findings are reported only
    when the value is DEFINITE on every path reaching the read: a variable
    that is possibly zero is never reported, one that is always zero is.

Nothing is executed. The analyses are deliberately sound-leaning: anything
they cannot model (nested closures that rebind a name, `global` writes from
other functions, dynamic scope manipulation) makes the affected name
untracked rather than guessed.
"""

from __future__ import annotations

import ast
import builtins

from ..domain.models import Finding, RiskCategory, Severity

TOOL_NAME = "sentinel-flow"

# ---- Abstract value kinds -------------------------------------------------

U = "unbound"
N = "none"
Z = "zero"
P = "nonzero"
T = "other"

_UNBOUND = frozenset({U})
_NONE = frozenset({N})
_ZERO = frozenset({Z})
_NONZERO = frozenset({P})
_ANY = frozenset({T})
_NUMERIC = frozenset({Z, P})

#: Loop fixpoint iterations before the changed names are widened to "any".
_MAX_LOOP_ITERATIONS = 12
#: Statement evaluations allowed per scope; beyond it the scope is skipped
#: (no findings) rather than slowing a scan on pathological input.
_STEP_BUDGET = 60_000

#: Names that exist without a binding in the file (see ast_checks).
KNOWN_GLOBALS = frozenset(dir(builtins)) | frozenset({
    "aiter", "anext", "EncodingWarning", "ExceptionGroup",
    "BaseExceptionGroup", "PythonFinalizationError", "WindowsError",
    "reveal_type", "reveal_locals", "get_ipython", "display", "_",
    "unicode", "basestring", "xrange", "long", "raw_input", "unichr",
    "execfile", "reduce", "file", "cmp", "buffer", "intern", "apply",
})

_MODULE, _FUNCTION, _CLASS, _COMPREHENSION = "module", "function", "class", "comprehension"
_COMPREHENSIONS = (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)
_PATTERN_BINDERS = {"MatchAs", "MatchStar"}
_TYPE_PARAMS = {"TypeVar", "ParamSpec", "TypeVarTuple"}


def _is_dunder(name: str) -> bool:
    return name.startswith("__") and name.endswith("__")


def _dotted(node) -> str:
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return ""


def guarded_ranges(nodes, exception_names: frozenset) -> list:
    """
    Line ranges where code deliberately provokes one of `exception_names`:
    try bodies with a matching handler, and `with pytest.raises(...)` /
    `self.assertRaises(...)` blocks.
    """
    ranges = []
    for node in nodes:
        if isinstance(node, ast.Try) or type(node).__name__ == "TryStar":
            for handler in node.handlers:
                types = handler.type.elts if isinstance(handler.type, ast.Tuple) \
                    else [handler.type]
                names = {_dotted(t).rsplit(".", 1)[-1] for t in types if t is not None}
                if names & exception_names and node.body:
                    ranges.append((node.body[0].lineno,
                                   getattr(node.body[-1], "end_lineno", node.body[-1].lineno)))
        elif isinstance(node, (ast.With, ast.AsyncWith)):
            for item in node.items:
                expr = item.context_expr
                if isinstance(expr, ast.Call) and _dotted(expr.func).rsplit(
                        ".", 1)[-1].lower().startswith(("raises", "assertraises")):
                    ranges.append((node.lineno, getattr(node, "end_lineno", node.lineno)))
    return ranges


def _in_ranges(line: int, ranges: list) -> bool:
    return any(start <= line <= end for start, end in ranges)


# ---------------------------------------------------------------------------
# Scope model
# ---------------------------------------------------------------------------

class Scope:
    """One Python namespace and the names bound in it."""

    def __init__(self, kind: str, node, parent: "Scope | None") -> None:
        self.kind = kind
        self.node = node
        self.parent = parent
        self.bindings: set = set()
        self.globals: set = set()
        self.nonlocals: set = set()
        self.star = False
        self.children: list = []
        if parent is not None:
            parent.children.append(self)

    def descendants(self):
        stack = list(self.children)
        while stack:
            scope = stack.pop()
            yield scope
            stack.extend(scope.children)


class ScopeModel:
    """Builds every scope of a module and resolves name reads."""

    def __init__(self, tree: ast.Module) -> None:
        self.module = Scope(_MODULE, tree, None)
        self.scopes: list = [self.module]
        self.loads: list = []            # (Name node, Scope) for every read
        self.annotation_ids: set = set() # Name nodes inside annotations
        self.scope_of: dict = {}         # id(def/lambda/class node) -> Scope
        self._annotation_depth = 0
        for stmt in tree.body:
            self._visit(stmt, self.module)
        for scope in self.scopes:
            if scope.kind == _MODULE:
                continue
            # A store to a name declared global binds the MODULE name; a
            # store to a nonlocal binds the enclosing function's name.
            self.module.bindings |= scope.bindings & scope.globals
            scope.bindings -= scope.globals | scope.nonlocals

    # ---- construction -------------------------------------------------------

    def _new(self, kind: str, node, parent: Scope) -> Scope:
        scope = Scope(kind, node, parent)
        self.scopes.append(scope)
        self.scope_of[id(node)] = scope
        return scope

    def _annotation(self, node, scope: Scope) -> None:
        if node is None:
            return
        self._annotation_depth += 1
        try:
            self._visit(node, scope)
        finally:
            self._annotation_depth -= 1

    def _arguments_outer(self, args: ast.arguments, scope: Scope) -> None:
        """Defaults and annotations are evaluated in the DEFINING scope."""
        for default in list(args.defaults) + [d for d in args.kw_defaults if d is not None]:
            self._visit(default, scope)
        for arg in self._all_args(args):
            self._annotation(arg.annotation, scope)

    @staticmethod
    def _all_args(args: ast.arguments) -> list:
        out = list(getattr(args, "posonlyargs", [])) + list(args.args) + list(args.kwonlyargs)
        out.extend(a for a in (args.vararg, args.kwarg) if a is not None)
        return out

    def _bind_type_params(self, node, scope: Scope) -> None:
        for param in getattr(node, "type_params", None) or []:
            name = getattr(param, "name", None)
            if isinstance(name, str):
                scope.bindings.add(name)

    def _function_scope(self, scope: Scope) -> Scope:
        """Nearest enclosing non-comprehension scope (walrus target scope)."""
        while scope.kind == _COMPREHENSION and scope.parent is not None:
            scope = scope.parent
        return scope

    def _visit(self, node, scope: Scope) -> None:
        kind = type(node).__name__
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            scope.bindings.add(node.name)
            for decorator in node.decorator_list:
                self._visit(decorator, scope)
            self._arguments_outer(node.args, scope)
            self._annotation(node.returns, scope)
            inner = self._new(_FUNCTION, node, scope)
            inner.bindings.update(a.arg for a in self._all_args(node.args))
            self._bind_type_params(node, inner)
            for stmt in node.body:
                self._visit(stmt, inner)
        elif isinstance(node, ast.Lambda):
            self._arguments_outer(node.args, scope)
            inner = self._new(_FUNCTION, node, scope)
            inner.bindings.update(a.arg for a in self._all_args(node.args))
            self._visit(node.body, inner)
        elif isinstance(node, ast.ClassDef):
            scope.bindings.add(node.name)
            for expr in list(node.decorator_list) + list(node.bases) + \
                    [k.value for k in node.keywords]:
                self._visit(expr, scope)
            inner = self._new(_CLASS, node, scope)
            self._bind_type_params(node, inner)
            for stmt in node.body:
                self._visit(stmt, inner)
        elif isinstance(node, _COMPREHENSIONS):
            generators = node.generators
            # The first iterable is evaluated in the enclosing scope.
            self._visit(generators[0].iter, scope)
            inner = self._new(_COMPREHENSION, node, scope)
            for index, generator in enumerate(generators):
                if index:
                    self._visit(generator.iter, inner)
                self._visit(generator.target, inner)
                for condition in generator.ifs:
                    self._visit(condition, inner)
            if isinstance(node, ast.DictComp):
                self._visit(node.key, inner)
                self._visit(node.value, inner)
            else:
                self._visit(node.elt, inner)
        elif isinstance(node, ast.NamedExpr):
            self._visit(node.value, scope)
            self._function_scope(scope).bindings.add(node.target.id)
        elif isinstance(node, ast.Name):
            if isinstance(node.ctx, ast.Load):
                self.loads.append((node, scope))
                if self._annotation_depth:
                    self.annotation_ids.add(id(node))
            else:
                scope.bindings.add(node.id)
        elif isinstance(node, ast.Global):
            scope.globals.update(node.names)
        elif isinstance(node, ast.Nonlocal):
            scope.nonlocals.update(node.names)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                scope.bindings.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == "*":
                    scope.star = True
                else:
                    scope.bindings.add(alias.asname or alias.name)
        elif isinstance(node, ast.ExceptHandler):
            if node.name:
                scope.bindings.add(node.name)
            for child in ast.iter_child_nodes(node):
                self._visit(child, scope)
        elif isinstance(node, ast.AnnAssign):
            # `x: int` (no value) still makes x local to a function.
            self._visit(node.target, scope)
            self._annotation(node.annotation, scope)
            if node.value is not None:
                self._visit(node.value, scope)
        elif kind == "TypeAlias":
            self._visit(node.name, scope)
            self._annotation(node.value, scope)
        elif kind in _PATTERN_BINDERS or kind == "MatchMapping":
            for attr in ("name", "rest"):
                value = getattr(node, attr, None)
                if isinstance(value, str):
                    scope.bindings.add(value)
            for child in ast.iter_child_nodes(node):
                self._visit(child, scope)
        else:
            for child in ast.iter_child_nodes(node):
                self._visit(child, scope)

    # ---- resolution -----------------------------------------------------------

    def module_defines(self, name: str) -> bool:
        return (name in self.module.bindings or self.module.star
                or name in KNOWN_GLOBALS or _is_dunder(name))

    def resolves(self, name: str, scope: Scope) -> bool:
        """True when a read of `name` in `scope` finds a binding at runtime."""
        if name in scope.globals:
            return self.module_defines(name)
        if name in scope.bindings or name in scope.nonlocals:
            return True
        parent = scope.parent
        while parent is not None and parent.kind != _MODULE:
            # Class bodies are invisible to the scopes nested inside them.
            if parent.kind != _CLASS:
                if name in parent.globals:
                    return self.module_defines(name)
                if name in parent.bindings or name in parent.nonlocals:
                    return True
            parent = parent.parent
        return self.module_defines(name)

    def global_writes(self) -> set:
        """Module names some function/class rebinds via `global`."""
        names: set = set()
        for scope in self.scopes:
            if scope.kind != _MODULE:
                names |= scope.globals
        return names


# ---------------------------------------------------------------------------
# Value tracking
# ---------------------------------------------------------------------------

class _BudgetExceeded(Exception):
    pass


def _join(*states):
    live = [s for s in states if s is not None]
    if not live:
        return None
    out = dict(live[0])
    for state in live[1:]:
        for name, kinds in state.items():
            out[name] = out.get(name, frozenset()) | kinds
    return out


def _numeric_kind(value):
    if value is None:
        return _NONE
    if isinstance(value, bool):
        return _NONZERO if value else _ZERO
    if isinstance(value, (int, float, complex)):
        return _NONZERO if value else _ZERO
    return _ANY


def _arith(op, left: frozenset, right: frozenset) -> frozenset:
    """Zero/nonzero arithmetic for operands known to be numeric."""
    if not (left and right and left <= _NUMERIC and right <= _NUMERIC):
        return _ANY
    if isinstance(op, ast.Mult):
        if left == _ZERO or right == _ZERO:
            return _ZERO
        if left == _NONZERO and right == _NONZERO:
            return _NONZERO
        return _NUMERIC
    if isinstance(op, (ast.Add, ast.Sub)):
        if left == _ZERO:
            return right
        if right == _ZERO:
            return left
        return _NUMERIC
    return _NUMERIC


class _Flow:
    """Abstract interpreter over one scope's statements."""

    def __init__(self, analyzer: "FlowAnalyzer", scope: Scope, tracked: set) -> None:
        self.analyzer = analyzer
        self.scope = scope
        self.tracked = tracked
        self.reporting = True
        self.loops: list = []
        #: One [joined state] cell per enclosing try/with body: every
        #: statement entered inside it (at any depth) is a point an exception
        #: can leave from, so the handler/suppression state joins them all.
        self.exits: list = []
        self.steps = 0
        self.findings: dict = {}

    # ---- reporting ------------------------------------------------------------

    def _report(self, rule: str, node, name: str) -> None:
        if not self.reporting:
            return
        key = (rule, node.lineno, getattr(node, "col_offset", 0), name)
        if key not in self.findings:
            self.findings[key] = (rule, node, name)

    # ---- statements -----------------------------------------------------------

    def block(self, statements, state):
        for statement in statements:
            if state is None:
                return None
            state = self.statement(statement, state)
        return state

    def statement(self, node, state):
        self.steps += 1
        if self.steps > _STEP_BUDGET:
            raise _BudgetExceeded()
        state = dict(state)
        for cell in self.exits:
            cell[0] = _join(cell[0], state)

        if isinstance(node, ast.Expr):
            self.eval(node.value, state)
        elif isinstance(node, ast.Assign):
            value = self.eval(node.value, state)
            for target in node.targets:
                self.assign(target, value, state)
        elif isinstance(node, ast.AnnAssign):
            if node.value is not None:
                self.assign(node.target, self.eval(node.value, state), state)
        elif isinstance(node, ast.AugAssign):
            self.aug_assign(node, state)
        elif isinstance(node, (ast.Return, ast.Raise)):
            for child in ast.iter_child_nodes(node):
                self.eval(child, state)
            return None
        elif isinstance(node, ast.Assert):
            self.eval(node.test, state)
            if node.msg is not None:
                self.eval(node.msg, state)
            return self.refine(node.test, state)[0]
        elif isinstance(node, ast.Break):
            if self.loops:
                self.loops[-1][0].append(state)
            return None
        elif isinstance(node, ast.Continue):
            if self.loops:
                self.loops[-1][1].append(state)
            return None
        elif isinstance(node, ast.Delete):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    self.read(target, state)
                    if target.id in self.tracked:
                        state[target.id] = _UNBOUND
                else:
                    self.store_target(target, state)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                if alias.name != "*":
                    self.bind(alias.asname or alias.name.split(".")[0], _ANY, state)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            self.definition(node, state)
        elif isinstance(node, ast.If):
            self.eval(node.test, state)
            true_state, false_state = self.refine(node.test, state)
            return _join(self.block(node.body, true_state),
                         self.block(node.orelse, false_state))
        elif isinstance(node, (ast.While, ast.For, ast.AsyncFor)):
            return self.loop(node, state)
        elif isinstance(node, ast.Try) or type(node).__name__ == "TryStar":
            return self.try_statement(node, state)
        elif isinstance(node, (ast.With, ast.AsyncWith)):
            return self.with_statement(node, state)
        elif type(node).__name__ == "Match":
            return self.match_statement(node, state)
        elif type(node).__name__ == "TypeAlias":
            self.assign(node.name, _ANY, state)
        # Pass / Global / Nonlocal: no effect on tracked values.
        return state

    def definition(self, node, state) -> None:
        """A def/class statement runs its decorators/defaults/bases now."""
        for decorator in node.decorator_list:
            self.eval(decorator, state)
        if isinstance(node, ast.ClassDef):
            for expr in list(node.bases) + [k.value for k in node.keywords]:
                self.eval(expr, state)
        else:
            for default in list(node.args.defaults) + \
                    [d for d in node.args.kw_defaults if d is not None]:
                self.eval(default, state)
        self.bind(node.name, _ANY, state)

    def loop(self, node, state):
        is_for = not isinstance(node, ast.While)
        if is_for:
            self.eval(node.iter, state)
            self.deref(node.iter, state, "iterated over")

        def entry(head):
            if is_for:
                body = dict(head)
                self.assign(node.target, _ANY, body)
                return body, head
            self.eval(node.test, head)
            return self.refine(node.test, head)

        saved = self.reporting
        self.reporting = False
        head = state
        try:
            for _ in range(_MAX_LOOP_ITERATIONS):
                body_state, _ = entry(dict(head))
                self.loops.append(([], []))
                end = self.block(node.body, body_state)
                _, continues = self.loops.pop()
                new_head = _join(state, end, *continues)
                if new_head == head:
                    break
                head = new_head
            else:
                head = {name: kinds | _ANY for name, kinds in head.items()}
        finally:
            self.reporting = saved

        # Final pass over the fixpoint state - the only one that reports.
        body_state, exit_state = entry(dict(head))
        self.loops.append(([], []))
        self.block(node.body, body_state)
        breaks, _ = self.loops.pop()
        return _join(self.block(node.orelse, exit_state), *breaks)

    def try_statement(self, node, state):
        # An exception can leave the body after any statement: handlers see
        # the join of the entry state and the state after each statement.
        cell = [state]
        self.exits.append(cell)
        try:
            body_end = self.block(node.body, state)
        finally:
            self.exits.pop()
        handler_entry = _join(cell[0], body_end)

        ends = [self.block(node.orelse, body_end)]
        for handler in node.handlers:
            handler_state = dict(handler_entry)
            if handler.type is not None:
                self.eval(handler.type, handler_state)
            if handler.name:
                self.bind(handler.name, _ANY, handler_state)
            end = self.block(handler.body, handler_state)
            if end is not None and handler.name and handler.name in self.tracked:
                # Python deletes the `except ... as name` binding on exit.
                end = dict(end)
                end[handler.name] = _UNBOUND
            ends.append(end)
        normal = _join(*ends)

        if node.finalbody:
            # Report from every way into `finally` (including an exception
            # escaping the handlers), continue from the normal paths only.
            self.block(node.finalbody, _join(normal, handler_entry))
            saved = self.reporting
            self.reporting = False
            try:
                normal = self.block(node.finalbody, normal) if normal is not None else None
            finally:
                self.reporting = saved
        return normal

    def with_statement(self, node, state):
        for item in node.items:
            self.eval(item.context_expr, state)
            if item.optional_vars is not None:
                self.assign(item.optional_vars, _ANY, state)
        # Any context manager may suppress an exception raised part-way
        # through the body, so execution can resume from any statement.
        cell = [state]
        self.exits.append(cell)
        try:
            body_end = self.block(node.body, state)
        finally:
            self.exits.pop()
        return _join(cell[0], body_end)

    def match_statement(self, node, state):
        self.eval(node.subject, state)
        ends = [state]                       # no case matched
        for case in node.cases:
            case_state = dict(state)
            for child in ast.walk(case.pattern):
                if type(child).__name__ in _PATTERN_BINDERS | {"MatchMapping"}:
                    for attr in ("name", "rest"):
                        value = getattr(child, attr, None)
                        if isinstance(value, str):
                            self.bind(value, _ANY, case_state)
                elif isinstance(child, ast.expr):
                    self.eval(child, case_state)
            if case.guard is not None:
                self.eval(case.guard, case_state)
                case_state = self.refine(case.guard, case_state)[0]
            ends.append(self.block(case.body, case_state))
        return _join(*ends)

    # ---- assignment -----------------------------------------------------------

    def bind(self, name: str, kinds: frozenset, state) -> None:
        if name in self.tracked:
            state[name] = (kinds - _UNBOUND) or _ANY

    def assign(self, target, kinds: frozenset, state) -> None:
        if isinstance(target, ast.Name):
            self.bind(target.id, kinds, state)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for element in target.elts:
                self.assign(element, _ANY, state)
        elif isinstance(target, ast.Starred):
            self.assign(target.value, _ANY, state)
        else:
            self.store_target(target, state)

    def store_target(self, target, state) -> None:
        """`x.attr = ...` / `x[i] = ...` / `del x[i]` dereference x."""
        if isinstance(target, ast.Attribute):
            self.eval(target.value, state)
            self.deref(target.value, state, f"has attribute '{target.attr}' set")
        elif isinstance(target, ast.Subscript):
            self.eval(target.value, state)
            self.eval(target.slice, state)
            self.deref(target.value, state, "is subscripted")

    def aug_assign(self, node, state) -> None:
        target = node.target
        if isinstance(target, ast.Name):
            left = self.read(target, state)
        else:
            self.store_target(target, state)
            left = _ANY
        right = self.eval(node.value, state)
        self.division(node, node.op, target, node.value, left, right, state)
        if isinstance(target, ast.Name):
            self.bind(target.id, _arith(node.op, left, right), state)

    # ---- expressions ------------------------------------------------------------

    def raw(self, node, state) -> frozenset:
        if isinstance(node, ast.Name) and node.id in self.tracked:
            return state.get(node.id, _ANY)
        return frozenset()

    def read(self, node: ast.Name, state) -> frozenset:
        if node.id not in self.tracked:
            return _ANY
        kinds = state.get(node.id, _ANY)
        if kinds == _UNBOUND:
            self._report("PY-Q009", node, node.id)
            return _ANY
        return (kinds - _UNBOUND) or _ANY

    def deref(self, node, state, how: str) -> None:
        if isinstance(node, ast.Name) and self.raw(node, state) == _NONE:
            self._report("PY-Q010", node, f"{node.id}\x00{how}")

    def division(self, node, op, left_node, right_node, left, right, state) -> None:
        if not isinstance(op, (ast.Div, ast.FloorDiv, ast.Mod)):
            return
        if isinstance(right_node, ast.Constant):
            return          # literal divisors are reported by PythonAstChecker
        if self.raw(right_node, state) != _ZERO:
            return
        # `%` on a string is formatting: only report numeric modulo.
        if isinstance(op, ast.Mod) and not (left and left <= _NUMERIC):
            return
        self._report("PY-Q007", node, right_node.id)

    def eval(self, node, state) -> frozenset:
        if node is None:
            return _ANY
        if isinstance(node, ast.Constant):
            return _numeric_kind(node.value)
        if isinstance(node, ast.Name):
            return self.read(node, state) if isinstance(node.ctx, ast.Load) else _ANY
        if isinstance(node, ast.Attribute):
            self.eval(node.value, state)
            self.deref(node.value, state, f"has attribute '{node.attr}' read")
            return _ANY
        if isinstance(node, ast.Subscript):
            self.eval(node.value, state)
            self.eval(node.slice, state)
            self.deref(node.value, state, "is subscripted")
            return _ANY
        if isinstance(node, ast.Call):
            self.eval(node.func, state)
            self.deref(node.func, state, "is called")
            for arg in node.args:
                self.eval(arg, state)
            for keyword in node.keywords:
                self.eval(keyword.value, state)
            return _ANY
        if isinstance(node, ast.BinOp):
            left = self.eval(node.left, state)
            right = self.eval(node.right, state)
            self.division(node, node.op, node.left, node.right, left, right, state)
            return _arith(node.op, left, right)
        if isinstance(node, ast.UnaryOp):
            value = self.eval(node.operand, state)
            if isinstance(node.op, (ast.USub, ast.UAdd)) and value <= _NUMERIC:
                return value
            return _ANY
        if isinstance(node, ast.BoolOp):
            # Short-circuit: later operands only run under the narrowing of
            # the earlier ones (`x is not None and x.attr`).
            current = state
            for value in node.values:
                if current is None:
                    break
                self.eval(value, current)
                true_state, false_state = self.refine(value, current)
                current = true_state if isinstance(node.op, ast.And) else false_state
            return _ANY
        if isinstance(node, ast.IfExp):
            self.eval(node.test, state)
            true_state, false_state = self.refine(node.test, state)
            body = self.eval(node.body, true_state) if true_state is not None else frozenset()
            other = self.eval(node.orelse, false_state) if false_state is not None else frozenset()
            return (body | other) or _ANY
        if isinstance(node, ast.NamedExpr):
            value = self.eval(node.value, state)
            self.bind(node.target.id, value, state)
            return value
        if isinstance(node, ast.Lambda):
            for default in list(node.args.defaults) + \
                    [d for d in node.args.kw_defaults if d is not None]:
                self.eval(default, state)
            return _ANY
        if isinstance(node, _COMPREHENSIONS):
            self.comprehension(node, state)
            return _ANY
        for child in ast.iter_child_nodes(node):
            if isinstance(child, ast.expr):
                self.eval(child, state)
            elif isinstance(child, ast.keyword):
                self.eval(child.value, state)
        return _ANY

    def comprehension(self, node, state) -> None:
        generators = node.generators
        self.eval(generators[0].iter, state)
        # A walrus inside the comprehension binds in THIS scope, possibly
        # (the comprehension may run zero times, or lazily).
        for inner_node in ast.walk(node):
            if isinstance(inner_node, ast.NamedExpr) and inner_node.target.id in self.tracked:
                name = inner_node.target.id
                state[name] = state.get(name, _ANY) | _ANY
        if isinstance(node, ast.GeneratorExp):
            return          # the rest runs lazily, after this point
        inner = dict(state)
        for index, generator in enumerate(generators):
            if index:
                self.eval(generator.iter, inner)
            for name in ast.walk(generator.target):
                if isinstance(name, ast.Name) and name.id in inner:
                    inner[name.id] = _ANY
            for condition in generator.ifs:
                self.eval(condition, inner)
                inner = self.refine(condition, inner)[0]
                if inner is None:
                    return
        for part in ((node.key, node.value) if isinstance(node, ast.DictComp) else (node.elt,)):
            self.eval(part, inner)

    # ---- narrowing ------------------------------------------------------------

    def refine(self, test, state):
        """(state when `test` is true, state when false); None = impossible."""
        if state is None:
            return None, None
        if isinstance(test, ast.Constant):
            return (state, None) if test.value else (None, state)
        if isinstance(test, ast.NamedExpr):
            test = test.target
        if isinstance(test, ast.Name) and test.id in self.tracked:
            kinds = state.get(test.id, _ANY) - _UNBOUND
            truthy = kinds - {Z, N}
            falsy = kinds & frozenset({Z, N, T})
            return self._narrow(state, test.id, truthy), self._narrow(state, test.id, falsy)
        if isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not):
            true_state, false_state = self.refine(test.operand, state)
            return false_state, true_state
        if isinstance(test, ast.BoolOp):
            if isinstance(test.op, ast.And):
                current, falses = state, []
                for value in test.values:
                    true_state, false_state = self.refine(value, current)
                    falses.append(false_state)
                    current = true_state
                    if current is None:
                        break
                return current, _join(*falses)
            current, trues = state, []
            for value in test.values:
                true_state, false_state = self.refine(value, current)
                trues.append(true_state)
                current = false_state
                if current is None:
                    break
            return _join(*trues), current
        if isinstance(test, ast.Compare) and len(test.ops) == 1:
            return self._refine_compare(test, state)
        if isinstance(test, ast.Call) and isinstance(test.func, ast.Name) \
                and test.func.id == "isinstance" and test.args \
                and isinstance(test.args[0], ast.Name) and test.args[0].id in self.tracked:
            name = test.args[0].id
            kinds = state.get(name, _ANY) - _UNBOUND
            return self._narrow(state, name, kinds - _NONE), state
        return state, state

    def _refine_compare(self, test, state):
        left, op, right = test.left, test.ops[0], test.comparators[0]
        if isinstance(left, ast.Constant) and isinstance(right, ast.Name):
            left, right = right, left
            op = {ast.Lt: ast.Gt(), ast.Gt: ast.Lt(), ast.LtE: ast.GtE(),
                  ast.GtE: ast.LtE()}.get(type(op), op)
        if not (isinstance(left, ast.Name) and left.id in self.tracked
                and isinstance(right, ast.Constant)):
            return state, state
        name, value = left.id, right.value
        kinds = state.get(name, _ANY) - _UNBOUND
        if value is None and isinstance(op, (ast.Is, ast.Eq, ast.IsNot, ast.NotEq)):
            is_none = self._narrow(state, name, _NONE if kinds & {N, T} else frozenset())
            not_none = self._narrow(state, name, kinds - _NONE)
            return (is_none, not_none) if isinstance(op, (ast.Is, ast.Eq)) \
                else (not_none, is_none)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return state, state
        if value == 0 and isinstance(op, (ast.Eq, ast.NotEq)):
            zero = self._narrow(state, name, _ZERO if kinds & {Z, T} else frozenset())
            nonzero = self._narrow(state, name, kinds - _ZERO)
            return (zero, nonzero) if isinstance(op, ast.Eq) else (nonzero, zero)
        # x > 0, x < 0, x >= 1, x > 5 ... : when true, x is a nonzero number.
        excludes_zero = (isinstance(op, (ast.Gt, ast.Lt)) and value == 0) or \
            (isinstance(op, (ast.Gt, ast.GtE)) and value > 0) or \
            (isinstance(op, (ast.Lt, ast.LtE)) and value < 0)
        if excludes_zero:
            return self._narrow(state, name, kinds - {Z, N}), state
        return state, state

    @staticmethod
    def _narrow(state, name: str, kinds: frozenset):
        if not kinds:
            return None
        narrowed = dict(state)
        narrowed[name] = frozenset(kinds)
        return narrowed


class FlowAnalyzer:
    """Runs scope resolution and value tracking over one module."""

    def __init__(self, tree: ast.Module, nodes: list, dynamic_scope: bool = False) -> None:
        self.tree = tree
        self.nodes = nodes
        self.dynamic_scope = dynamic_scope
        self.model = ScopeModel(tree)

    def findings(self) -> list:
        return self.undefined_names() + self.value_findings()

    # ---- PY-Q008 -------------------------------------------------------------

    def undefined_names(self) -> list:
        if self.dynamic_scope:
            return []
        guarded = None
        first: dict = {}
        count: dict = {}
        for node, scope in self.model.loads:
            name = node.id
            if id(node) in self.model.annotation_ids or self.model.resolves(name, scope):
                continue
            if guarded is None:
                guarded = guarded_ranges(self.nodes, frozenset({"NameError"}))
            if _in_ranges(node.lineno, guarded):
                continue
            count[name] = count.get(name, 0) + 1
            if name not in first or node.lineno < first[name][0]:
                first[name] = (node.lineno, scope)

        findings = []
        for name, (line, scope) in sorted(first.items(), key=lambda item: item[1][0]):
            also = f" ({count[name]} uses in this file)" if count[name] > 1 else ""
            hint = ""
            if any(name in s.bindings for s in self.model.scopes if s.kind == _CLASS):
                hint = (" A class body defines it, but class attributes are not "
                        "visible as bare names inside methods or comprehensions - "
                        "use self./cls./ClassName. to reach it.")
            elif any(name in s.bindings for s in self.model.scopes):
                hint = (" It is bound in a different function, which is not "
                        "visible from here.")
            findings.append(Finding(
                tool=TOOL_NAME, rule_id="PY-Q008", severity=Severity.HIGH,
                line=line, category=RiskCategory.RELIABILITY, cwe="CWE-457",
                message=f"Undefined name '{name}'{also}: no binding is visible "
                        f"from this scope and it is not a builtin, so reaching "
                        f"this line raises NameError.{hint}",
                remediation="Import or define the name in a scope visible from "
                            "here, pass it in as a parameter, or correct the "
                            "spelling of the intended variable.",
            ))
        return findings

    # ---- PY-Q009 / PY-Q010 / PY-Q007 ----------------------------------------

    def value_findings(self) -> list:
        model = self.model
        collected: dict = {}
        global_writes = model.global_writes()
        for scope in model.scopes:
            if scope.kind == _FUNCTION and isinstance(scope.node, ast.Lambda):
                continue
            if scope.kind == _FUNCTION:
                rebound = set()
                for inner in scope.descendants():
                    rebound |= inner.nonlocals
                tracked = scope.bindings - rebound
                params = {a.arg for a in ScopeModel._all_args(scope.node.args)}
                body = scope.node.body
            elif scope.kind == _MODULE:
                if self.dynamic_scope or scope.star:
                    continue
                # An unbound module name falls back to builtins, so shadowed
                # builtins (TimeoutError = TimeoutError) are never unbound.
                tracked = {n for n in scope.bindings - global_writes
                           if not _is_dunder(n) and n not in KNOWN_GLOBALS}
                params = set()
                body = scope.node.body
            else:
                continue            # class bodies and comprehensions
            if not tracked:
                continue
            state = {name: (_ANY if name in params else _UNBOUND) for name in tracked}
            flow = _Flow(self, scope, tracked)
            try:
                flow.block(body, state)
            except (_BudgetExceeded, RecursionError):
                continue
            for key, value in flow.findings.items():
                collected.setdefault(key, (value, scope))
        return self._build(collected)

    def _build(self, collected: dict) -> list:
        guards = {
            "PY-Q007": frozenset({"ZeroDivisionError", "ArithmeticError"}),
            "PY-Q009": frozenset({"NameError", "UnboundLocalError"}),
            "PY-Q010": frozenset({"AttributeError", "TypeError"}),
        }
        ranges: dict = {}
        findings = []
        for (rule, line, _col, _name), ((_, node, name), scope) in sorted(
                collected.items(), key=lambda item: (item[0][1], item[0][2])):
            if rule not in ranges:
                ranges[rule] = guarded_ranges(self.nodes, guards[rule])
            if _in_ranges(line, ranges[rule]):
                continue
            findings.append(self._finding(rule, line, name, scope))
        return findings

    def _finding(self, rule: str, line: int, name: str, scope: Scope) -> Finding:
        at_module = scope.kind == _MODULE
        if rule == "PY-Q009":
            if at_module:
                message = (f"'{name}' is used before it is defined: no statement "
                           f"above this line binds it on any path, so importing "
                           f"the module raises NameError here.")
                remediation = ("Move the definition above its first use, or "
                               "defer the use into a function called later.")
            else:
                shadow = self.model.module_defines(name) and name not in KNOWN_GLOBALS
                message = (f"Local variable '{name}' is read before it is "
                           f"assigned on every path to this line - this raises "
                           f"UnboundLocalError."
                           + (" A later assignment in this function makes the "
                              "name local, so the module-level name of the same "
                              "name is NOT used here." if shadow else ""))
                remediation = ("Assign the variable before this read, or declare "
                               "'global'/'nonlocal' if the outer name was meant.")
            return Finding(
                tool=TOOL_NAME, rule_id=rule, severity=Severity.HIGH, line=line,
                category=RiskCategory.RELIABILITY, cwe="CWE-457",
                message=message, remediation=remediation)
        if rule == "PY-Q010":
            variable, _, how = name.partition("\x00")
            return Finding(
                tool=TOOL_NAME, rule_id=rule, severity=Severity.HIGH, line=line,
                category=RiskCategory.RELIABILITY, cwe="CWE-476",
                message=f"'{variable}' is None on every path to this line and "
                        f"{how} - this raises AttributeError/TypeError.",
                remediation="Assign the real object before this use, or guard "
                            f"it ('if {variable} is not None:').")
        return Finding(
            tool=TOOL_NAME, rule_id=rule, severity=Severity.HIGH, line=line,
            category=RiskCategory.RELIABILITY, cwe="CWE-369",
            message=f"Division by '{name}', which is zero on every path to this "
                    f"line - this raises ZeroDivisionError.",
            remediation=f"Update '{name}' before dividing (a missing increment "
                        f"is the usual cause), or guard the division "
                        f"('if {name}: ...').")


def analyze(tree: ast.Module, nodes: list, dynamic_scope: bool = False) -> list:
    """All flow/scope findings for one parsed module."""
    return FlowAnalyzer(tree, nodes, dynamic_scope).findings()
