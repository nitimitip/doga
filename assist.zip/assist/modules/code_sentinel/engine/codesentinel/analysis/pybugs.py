"""
Python bug patterns - statements that are valid syntax but cannot do what
the author meant (the "Bug" rule family of SonarQube / pyflakes / bugbear).

Every check here reports a DEFINITE defect visible in one file: a call that
raises TypeError on its argument count, a format string with the wrong
number of values, a handler that can never be reached, a condition that is
constant. Anything that depends on run-time types this analysis cannot see
is left alone, so the rule set stays quiet on correct code.

Rules (all category Reliability unless noted):
  PY-B001  duplicate key in a dict literal
  PY-B002  same condition repeated in an if/elif chain
  PY-B003  if/else (or conditional expression) with identical branches
  PY-B004  expression compared with itself
  PY-B005  variable or attribute assigned to itself
  PY-B006  exception object created but never raised
  PY-B007  __init__ returns a value / is a generator
  PY-B008  same-file function called with the wrong arguments
  PY-B009  except clause unreachable (broader handler earlier)
  PY-B010  boolean expression used as the exception type in except
  PY-B011  raise NotImplemented (not an exception)
  PY-B012  len() compared so the result is constant
  PY-B013  %-format / str.format placeholders do not match the values
  PY-B014  instance method declared without any parameter
  PY-B015  comparison used as a statement (result discarded)
  PY-B016  result of a pure str method discarded
  PY-B017  assert on a non-empty string literal (always passes)
  PY-B018  time/uuid/random value frozen in a default argument
  PY-B019  loop 'else' without any 'break' (Maintainability)
  PY-B020  f-string without placeholders (Coding Standards)
  PY-B021  comparison to None with == / != (Coding Standards)
  PY-B022  unused import (Maintainability)
  PY-B023  comparison with NaN (always False)
  PY-B024  identical operands of 'and' / 'or'
  PY-B025  coroutine called without await (never runs)
"""

from __future__ import annotations

import ast
import builtins
import re
import string

from ..domain.models import Finding, RiskCategory, Severity

TOOL_NAME = "sentinel-ast"

#: str methods with no side effects: calling one as a statement is a no-op.
_PURE_STR_METHODS = frozenset({
    "strip", "lstrip", "rstrip", "casefold", "capitalize",
    "swapcase", "zfill", "removeprefix", "removesuffix", "expandtabs",
})
#: Pure on str, but common side-effecting names elsewhere (plt.title(),
#: widget.center()) - only reported on a string literal receiver.
_PURE_ON_LITERAL = frozenset({"replace", "title", "center", "ljust", "rjust",
                              "format", "join", "split", "upper", "lower"})
#: Query-builder calls where `col == None` is the required spelling
#: (SQLAlchemy renders it as IS NULL; `is None` would not work).
_QUERY_BUILDERS = frozenset({"filter", "filter_by", "where", "having",
                             "and_", "or_", "not_", "case", "join",
                             "outerjoin", "exclude", "query"})
#: Calls whose value changes on every call - frozen when used as a default.
_VOLATILE_DEFAULTS = frozenset({
    "datetime.now", "datetime.utcnow", "datetime.today", "date.today",
    "datetime.datetime.now", "datetime.datetime.utcnow",
    "datetime.datetime.today", "datetime.date.today", "time.time",
    "time.monotonic", "time.perf_counter", "uuid.uuid1", "uuid.uuid4",
    "random.random", "random.randint", "random.choice", "random.uniform",
    "secrets.token_hex", "secrets.token_urlsafe",
})
_NAN_SPELLINGS = frozenset({"math.nan", "numpy.nan", "np.nan", "float.nan"})
_COMPARE_ALWAYS = {ast.Lt: "False", ast.GtE: "True"}


def _finding(rule_id: str, severity: Severity, line: int, message: str,
             remediation: str, category: str = RiskCategory.RELIABILITY,
             cwe: str = "", confidence: str = "HIGH") -> Finding:
    return Finding(tool=TOOL_NAME, rule_id=rule_id, severity=severity,
                   line=line, category=category, cwe=cwe, message=message,
                   remediation=remediation, confidence=confidence)


def _dotted(node) -> str:
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return ""


def _callee_name(func) -> str:
    """Last name of a callee: `where` for both `q.where` and `select(t).where`."""
    if isinstance(func, ast.Attribute):
        return func.attr
    return func.id if isinstance(func, ast.Name) else ""


def _same(a, b) -> bool:
    return ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False)


def _has_side_effects(node) -> bool:
    """Calls, awaits, yields and walrus can differ between two evaluations."""
    return any(isinstance(n, (ast.Call, ast.Await, ast.Yield, ast.YieldFrom,
                              ast.NamedExpr)) for n in ast.walk(node))


def _is_builtin_exception(name: str) -> bool:
    obj = getattr(builtins, name, None)
    return isinstance(obj, type) and issubclass(obj, BaseException)


def _parent_map(nodes: list) -> dict:
    parents = {}
    for node in nodes:
        for child in ast.iter_child_nodes(node):
            parents[child] = node
    return parents


class PythonBugChecker:
    """Definite-defect checks over one parsed module."""

    def __init__(self, tree: ast.AST, nodes: list | None = None,
                 path_name: str = "", bound_names: set | None = None) -> None:
        self.tree = tree
        self.nodes = nodes if nodes is not None else list(ast.walk(tree))
        self.path_name = path_name.lower()
        self.parents = _parent_map(self.nodes)
        self.findings: list[Finding] = []
        self.shadowed_builtins = {
            n.id for n in self.nodes
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)
        } | {n.name for n in self.nodes
             if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}

    def run(self) -> list[Finding]:
        top_functions = self._unique_top_level_functions()
        for node in self.nodes:
            if isinstance(node, ast.Dict):
                self._duplicate_keys(node)
            elif isinstance(node, ast.If):
                self._if_chain(node)
            elif isinstance(node, ast.IfExp):
                self._ternary(node)
            elif isinstance(node, ast.Compare):
                self._compare(node)
            elif isinstance(node, ast.Assign):
                self._self_assignment(node)
            elif isinstance(node, ast.Expr):
                self._expression_statement(node, top_functions)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._function(node)
            elif isinstance(node, ast.Try):
                self._handlers(node)
            elif isinstance(node, ast.Raise):
                self._raise(node)
            elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mod):
                self._percent_format(node)
            elif isinstance(node, ast.Call):
                self._call(node, top_functions)
            elif isinstance(node, ast.Assert):
                self._assert(node)
            elif isinstance(node, (ast.For, ast.AsyncFor, ast.While)):
                self._loop_else(node)
            elif isinstance(node, ast.JoinedStr):
                self._fstring(node)
            elif isinstance(node, ast.BoolOp):
                self._bool_operands(node)
        self._unused_imports()
        return self.findings

    # ---- helpers -----------------------------------------------------------

    def _add(self, *args, **kwargs) -> None:
        self.findings.append(_finding(*args, **kwargs))

    def _unique_top_level_functions(self) -> dict:
        """Module-level defs whose name is bound exactly once in the file."""
        body = getattr(self.tree, "body", [])
        defs = {}
        counts: dict = {}
        for stmt in body:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                defs[stmt.name] = stmt
        for node in self.nodes:
            name = None
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = node.name
            elif isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
                name = node.id
            elif isinstance(node, ast.alias):
                name = node.asname or node.name.split(".")[0]
            elif isinstance(node, ast.arg):
                name = node.arg
            elif isinstance(node, (ast.Global, ast.Nonlocal)):
                for item in node.names:
                    counts[item] = counts.get(item, 0) + 2
            if name:
                counts[name] = counts.get(name, 0) + 1
        return {name: fn for name, fn in defs.items()
                if counts.get(name) == 1 and not fn.decorator_list}

    # ---- PY-B001 -----------------------------------------------------------

    def _duplicate_keys(self, node: ast.Dict) -> None:
        seen = {}
        for key in node.keys:
            if key is None:          # **spread
                continue
            if isinstance(key, ast.Constant):
                ident = ("c", type(key.value).__name__, repr(key.value))
            elif isinstance(key, ast.Name):
                ident = ("n", key.id)
            else:
                continue
            if ident in seen:
                self._add("PY-B001", Severity.MEDIUM, key.lineno,
                          f"Dictionary key {ast.unparse(key) if hasattr(ast, 'unparse') else ''} "
                          f"is repeated (first at line {seen[ident]}) - the "
                          f"earlier value is silently overwritten.",
                          "Remove the duplicate entry or rename the key that "
                          "was meant.", cwe="CWE-462")
            else:
                seen[ident] = key.lineno

    # ---- PY-B002 / PY-B003 -------------------------------------------------

    def _if_chain(self, node: ast.If) -> None:
        parent = self.parents.get(node)
        if isinstance(parent, ast.If) and parent.orelse == [node]:
            return                       # handled from the head of the chain
        tests = []
        current = node
        while True:
            tests.append(current.test)
            if len(current.orelse) == 1 and isinstance(current.orelse[0], ast.If):
                current = current.orelse[0]
                continue
            break
        for index, test in enumerate(tests):
            if _has_side_effects(test):
                continue
            for earlier in tests[:index]:
                if _same(test, earlier):
                    self._add("PY-B002", Severity.MEDIUM, test.lineno,
                              f"This condition repeats the one at line "
                              f"{earlier.lineno} in the same if/elif chain - "
                              f"its branch can never run.",
                              "Correct the condition to the case that was "
                              "intended, or remove the dead branch.",
                              cwe="CWE-561")
                    break
        if node.orelse and not (len(node.orelse) == 1 and isinstance(node.orelse[0], ast.If)) \
                and len(node.body) == len(node.orelse) \
                and all(_same(a, b) for a, b in zip(node.body, node.orelse)):
            self._add("PY-B003", Severity.MEDIUM, node.lineno,
                      "Both branches of this if/else execute identical code - "
                      "the condition has no effect.",
                      "Change the branch that is wrong, or remove the "
                      "condition if both cases really are the same.",
                      cwe="CWE-1164")

    def _ternary(self, node: ast.IfExp) -> None:
        if _same(node.body, node.orelse):
            self._add("PY-B003", Severity.MEDIUM, node.lineno,
                      "Both outcomes of this conditional expression are "
                      "identical - the condition has no effect.",
                      "Correct one of the two values, or drop the condition.",
                      cwe="CWE-1164")

    # ---- PY-B004 / B012 / B021 / B023 ---------------------------------------

    def _compare(self, node: ast.Compare) -> None:
        operands = [node.left, *node.comparators]
        for op, left, right in zip(node.ops, operands, operands[1:]):
            nan_idiom = isinstance(op, (ast.Eq, ast.NotEq)) and isinstance(left, ast.Name)
            if not isinstance(op, ast.NotEq) and not nan_idiom and _same(left, right) \
                    and not _has_side_effects(left) \
                    and not isinstance(left, ast.Constant):
                self._add("PY-B004", Severity.MEDIUM, node.lineno,
                          "An expression is compared with itself - the result "
                          "is constant, so this is almost certainly a typo.",
                          "Compare against the value that was intended.",
                          cwe="CWE-570")
            if isinstance(left, ast.Call) and _dotted(left.func) == "len" \
                    and isinstance(right, ast.Constant) and right.value == 0 \
                    and type(op) in _COMPARE_ALWAYS:
                self._add("PY-B012", Severity.MEDIUM, node.lineno,
                          f"len(...) is never negative, so this comparison is "
                          f"always {_COMPARE_ALWAYS[type(op)]}.",
                          "Use '== 0' / '> 0' (or truthiness) for the check "
                          "that was intended.", cwe="CWE-570")
            if isinstance(op, (ast.Eq, ast.NotEq)):
                other = right if isinstance(left, ast.Constant) else left
                for side in (left, right):
                    if isinstance(side, ast.Constant) and side.value is None \
                            and not self._query_expression(node, other):
                        self._add("PY-B021", Severity.LOW, node.lineno,
                                  "Comparison to None with '=='/'!=' - it "
                                  "calls __eq__, which objects can override.",
                                  "Use 'is None' / 'is not None'.",
                                  category=RiskCategory.STANDARDS)
                        break
                for side in (left, right):
                    if self._is_nan(side):
                        self._add("PY-B023", Severity.MEDIUM, node.lineno,
                                  "Comparison with NaN - NaN is never equal "
                                  "to anything, including itself, so this is "
                                  "always " + ("True" if isinstance(op, ast.NotEq) else "False") + ".",
                                  "Use math.isnan(x) (or numpy.isnan / "
                                  "pandas.isna).", cwe="CWE-570")
                        break

    def _query_expression(self, node, other) -> bool:
        """`Model.column == None` inside a query builder is idiomatic ORM."""
        root = other
        while isinstance(root, ast.Attribute):
            root = root.value
        if isinstance(root, ast.Name) and root.id[:1].isupper():
            return True
        current = self.parents.get(node)
        while current is not None and not isinstance(current, ast.stmt):
            if isinstance(current, ast.Call) and _callee_name(current.func) in _QUERY_BUILDERS:
                return True
            current = self.parents.get(current)
        return False

    @staticmethod
    def _is_nan(node) -> bool:
        if _dotted(node) in _NAN_SPELLINGS:
            return True
        return (isinstance(node, ast.Call) and _dotted(node.func) == "float"
                and len(node.args) == 1 and isinstance(node.args[0], ast.Constant)
                and isinstance(node.args[0].value, str)
                and node.args[0].value.strip().lower() == "nan")

    # ---- PY-B005 -----------------------------------------------------------

    def _self_assignment(self, node: ast.Assign) -> None:
        if len(node.targets) != 1:
            return
        target, value = node.targets[0], node.value
        if isinstance(target, ast.Name) and isinstance(value, ast.Name):
            if target.id != value.id:
                return
            scope = self._scope_of(node)
            # Module and class bodies legitimately re-bind an outer name
            # (`TimeoutError = TimeoutError`, `name = name` in a class body).
            if not isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef)):
                return
        elif isinstance(target, ast.Attribute) and isinstance(value, ast.Attribute):
            if not _same(target, value) or _has_side_effects(target):
                return
        else:
            return
        self._add("PY-B005", Severity.MEDIUM, node.lineno,
                  "A variable is assigned to itself - the statement does "
                  "nothing, and usually hides a typo in one of the names.",
                  "Assign the value that was intended (often a parameter "
                  "with a similar name).", cwe="CWE-1164")

    def _scope_of(self, node):
        current = self.parents.get(node)
        while current is not None and not isinstance(
                current, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef,
                          ast.Lambda, ast.Module)):
            current = self.parents.get(current)
        return current

    # ---- Expression statements: B006 / B015 / B016 / B025 -------------------

    def _expression_statement(self, node: ast.Expr, top_functions: dict) -> None:
        value = node.value
        if isinstance(value, ast.Call):
            name = _dotted(value.func).rsplit(".", 1)[-1]
            builtin_exc = _is_builtin_exception(name) and name not in self.shadowed_builtins
            custom_exc = (name not in ("Error", "Exception") and name[:1].isupper()
                          and name.endswith(("Error", "Exception")))
            if name and (builtin_exc or custom_exc):
                self._add("PY-B006", Severity.MEDIUM, node.lineno,
                          f"{name}(...) creates an exception object but never "
                          f"raises it - the error condition is silently "
                          f"ignored.",
                          f"Add 'raise': raise {name}(...).", cwe="CWE-755")
                return
            func = value.func
            if isinstance(func, ast.Attribute) and func.attr in _PURE_STR_METHODS \
                    and not value.keywords:
                self._add("PY-B016", Severity.MEDIUM, node.lineno,
                          f"The result of .{func.attr}() is discarded - "
                          f"strings are immutable, so this line changes "
                          f"nothing.",
                          f"Assign the result: s = s.{func.attr}(...).",
                          cwe="CWE-252", confidence="MEDIUM")
                return
            if isinstance(func, ast.Attribute) and func.attr in _PURE_ON_LITERAL \
                    and (isinstance(func.value, ast.JoinedStr)
                         or (isinstance(func.value, ast.Constant)
                             and isinstance(func.value.value, str))):
                self._add("PY-B016", Severity.MEDIUM, node.lineno,
                          f"The result of str.{func.attr}() is discarded - "
                          f"strings are immutable, so this line changes "
                          f"nothing.",
                          f"Assign or use the result of {func.attr}().",
                          cwe="CWE-252")
                return
            self._unawaited(node, value, top_functions)
        elif isinstance(value, ast.Compare) and len(value.ops) == 1 \
                and isinstance(value.ops[0], (ast.Eq, ast.NotEq, ast.Lt, ast.Gt,
                                              ast.LtE, ast.GtE, ast.Is, ast.IsNot)):
            self._add("PY-B015", Severity.MEDIUM, node.lineno,
                      "A comparison is used as a statement - its result is "
                      "thrown away. This is usually a mistyped assignment "
                      "('==' for '=') or a missing 'assert'.",
                      "Use '=' to assign, or 'assert' to check.",
                      cwe="CWE-482")

    def _unawaited(self, stmt: ast.Expr, call: ast.Call, top_functions: dict) -> None:
        target = None
        if isinstance(call.func, ast.Name):
            fn = top_functions.get(call.func.id)
            if isinstance(fn, ast.AsyncFunctionDef):
                target = call.func.id
        elif isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name) \
                and call.func.value.id in ("self", "cls"):
            cls = self._enclosing_class(stmt)
            if cls is not None:
                methods = [s for s in cls.body if isinstance(
                    s, (ast.FunctionDef, ast.AsyncFunctionDef)) and s.name == call.func.attr]
                if len(methods) == 1 and isinstance(methods[0], ast.AsyncFunctionDef) \
                        and not methods[0].decorator_list:
                    target = f"{call.func.value.id}.{call.func.attr}"
        if target:
            self._add("PY-B025", Severity.HIGH, stmt.lineno,
                      f"Coroutine {target}() is called but not awaited - the "
                      f"call only creates a coroutine object; its body never "
                      f"runs.",
                      f"Write 'await {target}(...)', or schedule it with "
                      f"asyncio.create_task(...).", cwe="CWE-1164")

    def _enclosing_class(self, node):
        current = self.parents.get(node)
        while current is not None and not isinstance(current, ast.ClassDef):
            current = self.parents.get(current)
        return current

    # ---- Functions: B007 / B014 / B018 --------------------------------------

    def _function(self, node) -> None:
        parent = self.parents.get(node)
        if isinstance(parent, ast.ClassDef):
            args = node.args
            positional = [*getattr(args, "posonlyargs", []), *args.args]
            # Namespace classes call such functions on the class itself
            # (getattr(cls, name)()); only instance classes are reported.
            instance_class = any(
                isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)) and s is not node
                and not s.decorator_list and s.args.args and s.args.args[0].arg == "self"
                for s in parent.body)
            if not positional and args.vararg is None and not node.decorator_list \
                    and instance_class:
                self._add("PY-B014", Severity.HIGH, node.lineno,
                          f"Method {node.name}() takes no parameters, so "
                          f"calling it on an instance raises TypeError (the "
                          f"instance is always passed first).",
                          "Add 'self' as the first parameter, or decorate "
                          "the method with @staticmethod.", cwe="CWE-628")
            if node.name == "__init__":
                self._init_returns(node)
        for default in [*node.args.defaults, *[d for d in node.args.kw_defaults if d]]:
            if isinstance(default, ast.Call) and _dotted(default.func) in _VOLATILE_DEFAULTS:
                self._add("PY-B018", Severity.MEDIUM, default.lineno,
                          f"{_dotted(default.func)}() in a default argument is "
                          f"evaluated ONCE, when the function is defined - "
                          f"every call reuses that same value.",
                          "Default to None and compute the value inside the "
                          "function body.", cwe="CWE-1188")

    def _init_returns(self, node) -> None:
        for child in self._own_nodes(node):
            if isinstance(child, ast.Return) and child.value is not None and not (
                    isinstance(child.value, ast.Constant) and child.value.value is None):
                self._add("PY-B007", Severity.HIGH, child.lineno,
                          "__init__ returns a value - constructing the object "
                          "raises TypeError.",
                          "Remove the return value; store results on self.",
                          cwe="CWE-628")
                return
            if isinstance(child, (ast.Yield, ast.YieldFrom)):
                self._add("PY-B007", Severity.HIGH, child.lineno,
                          "__init__ contains 'yield', so it is a generator - "
                          "constructing the object raises TypeError.",
                          "Move the generator logic into a separate method.",
                          cwe="CWE-628")
                return

    @staticmethod
    def _own_nodes(func):
        """Nodes of a function body, not descending into nested scopes."""
        scopes = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)
        stack = [n for n in func.body if not isinstance(n, scopes)]
        while stack:
            node = stack.pop()
            yield node
            for child in ast.iter_child_nodes(node):
                if not isinstance(child, scopes):
                    stack.append(child)

    # ---- Exceptions: B009 / B010 / B011 --------------------------------------

    def _handlers(self, node: ast.Try) -> None:
        caught: list = []   # (name, line)
        for handler in node.handlers:
            kind = handler.type
            if isinstance(kind, ast.BoolOp):
                self._add("PY-B010", Severity.HIGH, handler.lineno,
                          "'except A or B' evaluates the boolean expression "
                          "first, so only ONE exception type is caught.",
                          "Catch several types with a tuple: except (A, B):",
                          cwe="CWE-697")
                continue
            names = []
            if isinstance(kind, ast.Name):
                names = [kind.id]
            elif isinstance(kind, ast.Tuple):
                names = [e.id for e in kind.elts if isinstance(e, ast.Name)]
            elif kind is None:
                names = ["BaseException"]
            for name in names:
                if name in self.shadowed_builtins or not _is_builtin_exception(name):
                    continue
                for broader, line in caught:
                    if issubclass(getattr(builtins, name), getattr(builtins, broader)):
                        self._add("PY-B009", Severity.MEDIUM, handler.lineno,
                                  f"'except {name}' can never run: the handler "
                                  f"for {broader} at line {line} already "
                                  f"catches it.",
                                  "Order handlers from the most specific to "
                                  "the most general exception.",
                                  cwe="CWE-561")
                        break
            for name in names:
                if name not in self.shadowed_builtins and _is_builtin_exception(name):
                    caught.append((name, handler.lineno))

    def _raise(self, node: ast.Raise) -> None:
        exc = node.exc
        if isinstance(exc, ast.Call):
            exc = exc.func
        if isinstance(exc, ast.Name) and exc.id == "NotImplemented" \
                and "NotImplemented" not in self.shadowed_builtins:
            self._add("PY-B011", Severity.HIGH, node.lineno,
                      "'raise NotImplemented' raises TypeError - "
                      "NotImplemented is a comparison sentinel, not an "
                      "exception.",
                      "Use 'raise NotImplementedError(...)'.", cwe="CWE-704")

    # ---- Format strings: B013 ----------------------------------------------

    _PERCENT_SPEC = re.compile(
        r"%(?:\((?P<key>[^)]*)\))?[#0\- +]*(?P<width>\*|\d+)?(?:\.(?P<prec>\*|\d+))?"
        r"[hlL]?(?P<conv>[diouxXeEfFgGcrsa%])")

    def _percent_format(self, node: ast.BinOp) -> None:
        if not (isinstance(node.left, ast.Constant) and isinstance(node.left.value, str)):
            return
        needed, named = 0, False
        for match in self._PERCENT_SPEC.finditer(node.left.value):
            if match.group("conv") == "%":
                continue
            if match.group("key") is not None:
                named = True
                continue
            needed += 1 + (match.group("width") == "*") + (match.group("prec") == "*")
        if named:
            return
        right = node.right
        if isinstance(right, ast.Tuple):
            if any(isinstance(e, ast.Starred) for e in right.elts):
                return
            given = len(right.elts)
        elif isinstance(right, (ast.Constant, ast.JoinedStr, ast.List)) \
                and not (isinstance(right, ast.Constant) and isinstance(right.value, tuple)):
            given = 1
        else:
            return
        if needed != given:
            self._add("PY-B013", Severity.HIGH, node.lineno,
                      f"The format string has {needed} placeholder(s) but "
                      f"{given} value(s) are supplied - this raises TypeError "
                      f"at run time.",
                      "Make the number of %-placeholders match the values "
                      "(or switch to an f-string).", cwe="CWE-685")

    def _call(self, node: ast.Call, top_functions: dict) -> None:
        func = node.func
        if isinstance(func, ast.Attribute) and func.attr == "format" \
                and isinstance(func.value, ast.Constant) and isinstance(func.value.value, str):
            self._str_format(node, func.value.value)
        elif isinstance(func, ast.Name) and func.id in top_functions:
            self._arity(node, top_functions[func.id])

    def _str_format(self, node: ast.Call, template: str) -> None:
        if any(isinstance(a, ast.Starred) for a in node.args) or any(
                k.arg is None for k in node.keywords):
            return
        try:
            fields = [f for _, f, _, _ in string.Formatter().parse(template) if f is not None]
        except ValueError as exc:
            self._add("PY-B013", Severity.HIGH, node.lineno,
                      f"The format string is invalid ({exc}) - str.format() "
                      f"raises ValueError at run time.",
                      "Escape literal braces as '{{' and '}}'.", cwe="CWE-685")
            return
        auto = manual = 0
        highest = -1
        missing = []
        keywords = {k.arg for k in node.keywords}
        for field in fields:
            head = re.split(r"[.\[]", field, maxsplit=1)[0]
            if head == "":
                auto += 1
            elif head.isdigit():
                manual += 1
                highest = max(highest, int(head))
            elif head not in keywords:
                missing.append(head)
        if auto and manual:
            problem = "mixes automatic '{}' and numbered '{0}' fields (ValueError)"
        elif auto > len(node.args):
            problem = f"has {auto} '{{}}' placeholder(s) but {len(node.args)} positional value(s) (IndexError)"
        elif highest >= len(node.args):
            problem = f"refers to argument {{{highest}}} but only {len(node.args)} positional value(s) are passed (IndexError)"
        elif missing:
            problem = f"names field '{missing[0]}' that is not passed (KeyError)"
        else:
            return
        self._add("PY-B013", Severity.HIGH, node.lineno,
                  f"The format string {problem} at run time.",
                  "Pass a value for every placeholder, or correct the "
                  "placeholder names.", cwe="CWE-685")

    def _arity(self, call: ast.Call, fn) -> None:
        if any(isinstance(a, ast.Starred) for a in call.args) or any(
                k.arg is None for k in call.keywords):
            return
        args = fn.args
        positional = [*getattr(args, "posonlyargs", []), *args.args]
        names = [a.arg for a in positional]
        posonly = {a.arg for a in getattr(args, "posonlyargs", [])}
        n_defaults = len(args.defaults)
        required = names[:len(names) - n_defaults] if n_defaults else names
        given = len(call.args)
        keywords = [k.arg for k in call.keywords]
        problem = ""
        if given > len(names) and args.vararg is None:
            problem = f"passes {given} positional argument(s) but {fn.name}() accepts at most {len(names)}"
        else:
            covered = set(names[:given]) | {k for k in keywords if k not in posonly}
            missing = [n for n in required if n not in covered]
            missing += [a.arg for a, d in zip(args.kwonlyargs, args.kw_defaults)
                        if d is None and a.arg not in keywords]
            if missing:
                problem = f"does not pass required argument '{missing[0]}' of {fn.name}()"
            elif args.kwarg is None:
                allowed = {n for n in names if n not in posonly} | {a.arg for a in args.kwonlyargs}
                unknown = [k for k in keywords if k not in allowed]
                if unknown:
                    problem = f"passes unexpected keyword '{unknown[0]}' to {fn.name}()"
                else:
                    duplicate = [k for k in keywords if k in names[:given]]
                    if duplicate:
                        problem = f"passes '{duplicate[0]}' both positionally and by keyword"
        if problem:
            self._add("PY-B008", Severity.HIGH, call.lineno,
                      f"This call {problem} (defined at line {fn.lineno}) - it "
                      f"raises TypeError every time it runs.",
                      "Match the call to the function's signature.",
                      cwe="CWE-628")

    # ---- B017 / B019 / B020 / B024 ------------------------------------------

    def _assert(self, node: ast.Assert) -> None:
        if isinstance(node.test, ast.Constant) and isinstance(node.test.value, str) \
                and node.test.value:
            self._add("PY-B017", Severity.MEDIUM, node.lineno,
                      "assert on a non-empty string always passes - the check "
                      "does nothing.",
                      "Assert the condition and pass the text as the message: "
                      "assert cond, 'message'.", cwe="CWE-571")

    def _loop_else(self, node) -> None:
        if not node.orelse:
            return
        for child in self._loop_body_nodes(node.body):
            if isinstance(child, ast.Break):
                return
        self._add("PY-B019", Severity.LOW, node.orelse[0].lineno,
                  "The loop's 'else' block always runs because the loop has "
                  "no 'break' - it is ordinary code after the loop in "
                  "disguise.",
                  "Move the block after the loop, or add the missing 'break'.",
                  category=RiskCategory.MAINTAINABILITY)

    @staticmethod
    def _loop_body_nodes(body):
        stack = list(body)
        while stack:
            node = stack.pop()
            yield node
            for child in ast.iter_child_nodes(node):
                if not isinstance(child, (ast.For, ast.AsyncFor, ast.While,
                                          ast.FunctionDef, ast.AsyncFunctionDef,
                                          ast.ClassDef, ast.Lambda)):
                    stack.append(child)

    def _fstring(self, node: ast.JoinedStr) -> None:
        parent = self.parents.get(node)
        if isinstance(parent, (ast.JoinedStr, ast.FormattedValue)):
            return                      # a format spec, not a user f-string
        if not any(isinstance(v, ast.FormattedValue) for v in node.values):
            self._add("PY-B020", Severity.LOW, node.lineno,
                      "f-string without any placeholders - the 'f' prefix is "
                      "unnecessary (or a placeholder was forgotten).",
                      "Remove the 'f' prefix, or add the missing {value}.",
                      category=RiskCategory.STANDARDS)

    def _bool_operands(self, node: ast.BoolOp) -> None:
        for index, value in enumerate(node.values):
            if _has_side_effects(value):
                continue
            if any(_same(value, earlier) for earlier in node.values[:index]):
                op = "and" if isinstance(node.op, ast.And) else "or"
                self._add("PY-B024", Severity.MEDIUM, node.lineno,
                          f"The same operand appears twice in this '{op}' "
                          f"expression - one side is redundant, which usually "
                          f"means the other intended check is missing.",
                          "Correct the duplicated operand.", cwe="CWE-1164")
                return

    # ---- B022 ----------------------------------------------------------------

    def _unused_imports(self) -> None:
        if self.path_name.endswith("__init__.py"):
            return
        body = getattr(self.tree, "body", [])
        if any(isinstance(s, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "__all__" for t in s.targets)
               for s in body):
            return
        used = set()
        for node in self.nodes:
            if isinstance(node, ast.Name):
                used.add(node.id)
            elif isinstance(node, ast.Constant) and isinstance(node.value, str):
                used.update(re.findall(r"[A-Za-z_]\w*", node.value))
        guarded = set()
        for node in body:
            if isinstance(node, ast.Try):
                for child in ast.walk(node):
                    guarded.add(id(child))
            elif isinstance(node, ast.If):     # if TYPE_CHECKING / version gates
                for child in ast.walk(node):
                    guarded.add(id(child))
        for stmt in body:
            if not isinstance(stmt, (ast.Import, ast.ImportFrom)) or id(stmt) in guarded:
                continue
            if isinstance(stmt, ast.ImportFrom) and stmt.module == "__future__":
                continue
            for alias in stmt.names:
                if alias.name == "*" or (alias.asname and alias.asname == alias.name.split(".")[-1]
                                         and isinstance(stmt, ast.ImportFrom)):
                    continue            # explicit re-export: `from x import y as y`
                local = alias.asname or alias.name.split(".")[0]
                if local not in used:
                    self._add("PY-B022", Severity.LOW, stmt.lineno,
                              f"'{alias.name}' is imported but never used.",
                              "Remove the unused import.",
                              category=RiskCategory.MAINTAINABILITY)


def analyze(tree: ast.AST, nodes: list | None = None, path_name: str = "") -> list[Finding]:
    """Run every definite-defect check over one parsed module."""
    return PythonBugChecker(tree, nodes, path_name).run()
