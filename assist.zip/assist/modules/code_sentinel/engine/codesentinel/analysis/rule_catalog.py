"""
Catalog of the checks implemented in code (AST, flow, taint, structural
syntax) rather than in JSON rule packs.

Pack rules describe themselves; these do not, so the rule browser and the
scan-scope picker would otherwise never show them. The metadata and
documentation live in rules/analyzer_rules.json (same standards fields as a
pack rule: type, CWE, OWASP 2021/2025, ASVS, PCI DSS, description and
verified examples). Every id an analyzer can emit must be listed there
(tests/test_code_sentinel_languages.py enforces it).
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

CATALOG_PATH = Path(__file__).resolve().parent.parent / "rules" / "analyzer_rules.json"


@lru_cache(maxsize=1)
def _catalog() -> tuple:
    payload = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    return tuple(payload["rules"])


def analyzer_rules() -> list:
    """Every analyzer check as a plain dict (full standards metadata)."""
    return [dict(entry, languages=list(entry["languages"])) for entry in _catalog()]


def analyzer_rule(rule_id: str):
    """One analyzer check's catalog entry, or None."""
    for entry in _catalog():
        if entry["id"] == rule_id:
            return dict(entry, languages=list(entry["languages"]))
    return None


#: (id, title, category, languages) - the original compact form.
ANALYZER_RULES = tuple(
    (entry["id"], entry["title"], entry["category"], tuple(entry["languages"]))
    for entry in _catalog())
