/* ==========================================================================
   ServiceNow Assist - page controllers for
     initSimilarPage()          Similar tickets (incidents + service requests)
     initTemplatePage()         Incident / request template
     initChangeTemplatePage()   CR template
   Relies on snow.js for SNOW_BASE, fetchJson and escapeHtml. Every value
   that came from ServiceNow data is escaped before it touches innerHTML;
   the only pre-rendered HTML accepted is the server's *_highlighted /
   *_snippet fields, which the server escapes before adding <mark>.
   ========================================================================== */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const esc = (s) => escapeHtml(s == null ? "" : String(s));

  function tone(pct) {
    const n = Number(pct) || 0;
    return n >= 65 ? "high" : n >= 45 ? "medium" : "low";
  }
  function confTone(c) {
    const n = Number(c) || 0;
    return n >= 0.7 ? "high" : n >= 0.45 ? "medium" : "low";
  }
  function qualityTone(band) {
    return band === "green" ? "high" : band === "amber" ? "medium" : band === "red" ? "stop" : "low";
  }
  function ring(pct, extraClass) {
    const v = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
    return '<div class="sa-ring ' + (extraClass || "") + '" data-tone="' + tone(v) + '" style="--v:' + v +
      '" role="img" aria-label="Match score ' + v + ' percent"><b>' + v + '<small>%</small></b></div>';
  }
  function meter(conf, label) {
    const v = Math.max(0, Math.min(100, Math.round((Number(conf) || 0) * 100)));
    return '<span class="sa-meter" data-tone="' + confTone(conf) + '" title="Confidence ' + v + '%">' +
      '<span class="sa-meter-bar"><i style="width:' + v + '%"></i></span>' + (label == null ? v + "%" : label) + "</span>";
  }
  const SOURCE_LABELS = {
    "model+history": ["Model and history agree", "high"],
    "model|history": ["Model + history", "info"],
    "history": ["Similar history", "info"],
    "model": ["Trained model", "info"],
    "rule": ["ServiceNow rule", "accent"],
    "form": ["You entered", "low"],
    "default": ["Default", "low"],
  };
  function sourceChip(src) {
    const s = SOURCE_LABELS[src] || [src || "-", "low"];
    return '<span class="sa-chip" data-tone="' + s[1] + '">' + esc(s[0]) + "</span>";
  }
  function prio(p) {
    const k = String(p || "").trim();
    return k ? '<span class="sa-prio" data-p="' + esc(k) + '">' + esc(k) + "</span>" : "";
  }
  function fmtHours(h) {
    if (h === null || h === undefined || Number.isNaN(Number(h))) return "-";
    const n = Number(h);
    if (n < 1) return "< 1h";
    if (n < 48) return Math.round(n) + "h";
    return (n / 24).toFixed(1) + " days";
  }
  function show(el, on) { if (el) el.hidden = !on; }
  function toast(msg) {
    const t = $("saToast");
    if (!t) return;
    t.textContent = msg;
    t.classList.add("is-on");
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove("is-on"), 1800);
  }
  function copyText(text, okMsg) {
    const done = () => toast(okMsg || "Copied to clipboard");
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, () => fallback());
    } else { fallback(); }
    function fallback() {
      const ta = document.createElement("textarea");
      ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); done(); } catch (_) { toast("Copy failed - select and copy manually"); }
      document.body.removeChild(ta);
    }
  }
  function setBusy(btn, busy, label) {
    if (!btn) return;
    if (busy) {
      btn._orig = btn._orig || btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i><span>' + esc(label) + "</span>";
    } else {
      btn.disabled = false;
      if (btn._orig) btn.innerHTML = btn._orig;
    }
  }
  function kpi(label, icon, value, sub, opts) {
    opts = opts || {};
    return '<div class="sa-kpi"' + (opts.tone ? ' data-tone="' + opts.tone + '"' : "") + ">" +
      '<div class="sa-kpi-label"><i class="fas ' + icon + '" aria-hidden="true"></i>' + esc(label) + "</div>" +
      '<div class="sa-kpi-value' + (opts.text ? " is-text" : "") + '">' + esc(value) + "</div>" +
      (sub ? '<div class="sa-kpi-sub">' + esc(sub) + "</div>" : "") + "</div>";
  }
  function stepItems(steps, emptyText) {
    if (!steps || !steps.length) return '<li class="sa-steps-empty">' + esc(emptyText || "No steps available.") + "</li>";
    return steps.map((s) => {
      const text = typeof s === "string" ? s : (s.text || s.step || "");
      const support = typeof s === "object" && s ? s.support : null;
      const chip = support && support > 1
        ? '<span class="sa-chip" data-tone="high" title="Found in ' + support + ' similar tickets">' + support + " tickets</span>"
        : support === 1 ? '<span class="sa-chip" data-tone="low">1 ticket</span>' : "<span></span>";
      return "<li><span>" + esc(text) + "</span>" + chip + "</li>";
    }).join("");
  }

  // ------------------------------------------------------------------------
  // History import (all three pages)
  // ------------------------------------------------------------------------
  function wireHistoryImport() {
    document.querySelectorAll(".snow-history-form").forEach((form) => {
      const kind = form.querySelector(".js-history-kind");
      if (kind) kind.addEventListener("change", () => { form.action = kind.value; });
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const button = form.querySelector('button[type="submit"]');
        const output = form.querySelector(".snow-history-result");
        setBusy(button, true, "Importing...");
        output.textContent = "Updating history. Current results stay available until the new version is published.";
        try {
          const response = await fetch(form.action, { method: "POST", body: new FormData(form) });
          if (!(response.headers.get("content-type") || "").includes("application/json")) {
            throw new Error("The server did not confirm the import. Refresh to check history status before retrying.");
          }
          const data = await response.json();
          if (!response.ok || !data.ok) throw new Error(data.error || "Import failed.");
          const h = data.history;
          output.textContent = h.records + " records retained; " + h.searchable + " searchable; " +
            h.embeddings_reused + " embeddings reused. ";
          const refresh = document.createElement("button");
          refresh.type = "button";
          refresh.className = "sa-btn sa-btn-sm";
          refresh.textContent = "Reload page";
          refresh.addEventListener("click", () => window.location.reload());
          output.appendChild(refresh);
        } catch (error) {
          output.textContent = error.message;
        } finally {
          setBusy(button, false);
        }
      });
    });
    // Close the import popover on outside click / Escape.
    document.addEventListener("click", (e) => {
      document.querySelectorAll(".sa-import[open]").forEach((d) => { if (!d.contains(e.target)) d.open = false; });
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") document.querySelectorAll(".sa-import[open]").forEach((d) => { d.open = false; });
    });
  }

  // ========================================================================
  // Similar tickets
  // ========================================================================
  window.initSimilarPage = function () {
    wireHistoryImport();
    const form = $("similarForm");
    if (!form) return;
    const el = {
      desc: $("sim_description"), ci: $("sim_ci"), cat: $("sim_category"), pri: $("sim_priority"),
      group: $("sim_group"), since: $("sim_since"), topn: $("sim_topn"), submit: $("sim_submit"),
      status: $("sim_status"), placeholder: $("sim_placeholder"), loading: $("sim_loading"),
      output: $("sim_output"), results: $("sim_results"), count: $("sim_result_count"),
      kpis: $("sim_kpis"), codes: $("sim_codes"), rec: $("sim_recommendation"),
      probs: $("sim_problems_section"), probsList: $("sim_problems_list"),
    };
    let lastRec = null;

    const toggle = $("sim_refine_toggle"), refine = $("sim_refine");
    toggle.addEventListener("click", () => {
      const open = toggle.getAttribute("aria-expanded") !== "true";
      toggle.setAttribute("aria-expanded", String(open));
      refine.hidden = !open;
    });
    const countFilters = () => {
      const n = Array.from(document.querySelectorAll("#sim_refine .js-filter")).filter((f) => f.value).length;
      const badge = $("sim_filter_count");
      badge.textContent = n; badge.hidden = n === 0;
    };
    document.querySelectorAll("#sim_refine .js-filter").forEach((f) => f.addEventListener("change", countFilters));
    $("sim_reset").addEventListener("click", () => {
      form.reset(); countFilters();
      show(el.output, false); show(el.status, false); show(el.placeholder, true);
      el.desc.focus();
    });
    el.desc.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) form.requestSubmit();
    });

    const source = () => (form.querySelector('input[name="sim_source"]:checked') || {}).value || "incident";

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const description = el.desc.value.trim();
      if (description.length < 3) {
        status("warn", "Describe the issue in at least a few words.");
        el.desc.focus();
        return;
      }
      show(el.status, false); show(el.placeholder, false); show(el.output, false); show(el.loading, true);
      setBusy(el.submit, true, "Searching...");
      try {
        const data = await fetchJson(SNOW_BASE + "/similar/search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            description, source: source(), configuration_item: el.ci.value.trim(),
            category: el.cat.value, priority: el.pri.value, assignment_group: el.group.value,
            resolved_since: el.since.value, top_n: parseInt(el.topn.value, 10) || 5,
          }),
        });
        const result = data.result || {};
        if (result.status !== "ok" || !(result.matches || []).length) {
          show(el.placeholder, true);
          status("info", result.message || "No sufficiently similar tickets found. Try different wording, fewer filters, or search both record types.");
          return;
        }
        render(result, data.problems || {});
        show(el.output, true);
        loadRecommendation(result.matches.filter((m) => !m.tentative));
      } catch (err) {
        show(el.placeholder, true);
        status("stop", err.message);
      } finally {
        show(el.loading, false);
        setBusy(el.submit, false);
      }
    });

    function status(level, msg) {
      const icons = { info: "fa-circle-info", warn: "fa-triangle-exclamation", stop: "fa-circle-xmark" };
      el.status.dataset.tone = level;
      el.status.innerHTML = '<i class="fas ' + (icons[level] || icons.info) + '" aria-hidden="true"></i><div>' + esc(msg) + "</div>";
      show(el.status, true);
    }

    function render(result, problems) {
      const ins = result.insights || {};
      const matches = result.matches;
      const missing = (result.sources_missing || []);
      const labels = { incident: "incidents", sr: "service requests" };
      const nConf = matches.filter((m) => !m.tentative).length;
      el.count.innerHTML = "<strong>" + nConf + "</strong> " + (nConf === 1 ? "match" : "matches") +
        (matches.length > nConf ? " + " + (matches.length - nConf) + " possible" : "") +
        " from " + Number(result.total_searched || 0).toLocaleString() + " " +
        (result.source === "all" ? "tickets" : labels[result.source] || "tickets") +
        (missing.length ? ' <span class="sa-chip" data-tone="medium">No ' + esc(missing.map((m) => labels[m]).join(", ")) + " history</span>" : "");
      el.codes.innerHTML = (result.codes || []).map((c) =>
        '<span class="sa-chip" data-tone="info" title="Exact identifier searched"><i class="fas fa-bolt" aria-hidden="true"></i>' + esc(c) + "</span>").join("");

      const group = ins.suggested_group;
      el.kpis.innerHTML = [
        matches[0].tentative
          ? kpi("Best match", "fa-bullseye", "None confident", "Only possible matches found", { tone: "warn", text: true })
          : kpi("Best match", "fa-bullseye", Math.round(matches[0].match_score) + "%",
                matches[0].match_score >= 65 ? "Strong evidence" : matches[0].match_score >= 45 ? "Moderate evidence" : "Weak - review carefully"),
        kpi("Usually resolved by", "fa-users", group ? group.name : "-",
            group ? group.share + "% of similar tickets" : "Not enough evidence", { text: true }),
        kpi("Typical resolution", "fa-stopwatch", fmtHours(ins.median_resolution_hours),
            ins.p80_resolution_hours != null ? "8 in 10 within " + fmtHours(ins.p80_resolution_hours) : ""),
        ins.recurring
          ? kpi("Recurring issue", "fa-rotate", "Seen " + ins.occurrences + " times", "Consider raising a Problem record", { tone: "warn" })
          : kpi("Fixes on record", "fa-list-check",
                ins.available ? (ins.useful_resolutions || 0) + " of " + ins.evidence_count : "-",
                ins.available ? "strong matches document a fix" : "No confident matches"),
      ].join("");

      const confident = matches.filter((m) => !m.tentative);
      const possible = matches.filter((m) => m.tentative);
      el.results.innerHTML = confident.map(card).join("") +
        (possible.length
          ? '<div class="sa-possible-head"><i class="fas fa-circle-info" aria-hidden="true"></i><span>' +
            (confident.length ? "Possible matches - little shared wording, check before relying on them"
                              : "No confident matches. These possible matches share little wording with your description - check them before relying on them.") +
            "</span></div>" + possible.map(card).join("")
          : "");
      renderProblems(problems);
    }

    function card(m) {
      const meta = [];
      if (m.catalog_item) meta.push('<span><i class="fas fa-ticket" aria-hidden="true"></i>' + esc(m.catalog_item) + "</span>");
      if (m.category) meta.push("<span>" + esc(m.category) + (m.subcategory ? " &rsaquo; " + esc(m.subcategory) : "") + "</span>");
      if (m.assignment_group) meta.push('<span><i class="fas fa-users" aria-hidden="true"></i>' + esc(m.assignment_group) + "</span>");
      if (m.configuration_item) meta.push('<span><i class="fas fa-server" aria-hidden="true"></i>' + esc(m.configuration_item) + "</span>");
      if (m.resolved_date) meta.push('<span><i class="fas fa-calendar-days" aria-hidden="true"></i>' + esc(m.resolved_date.slice(0, 10)) + "</span>");
      if (m.resolution_hours != null) meta.push('<span><i class="fas fa-stopwatch" aria-hidden="true"></i>' + esc(fmtHours(m.resolution_hours)) + "</span>");

      const possibleChip = m.tentative
        ? '<span class="sa-chip" data-tone="medium" title="Shares little wording with your description - check it is really the same issue">Possible match</span>' : "";
      const qualityChip = m.resolution_quality === "useful"
        ? '<span class="sa-chip" data-tone="high">Fix documented</span>'
        : m.resolution_quality === "thin" ? '<span class="sa-chip" data-tone="medium">Thin close notes</span>'
        : '<span class="sa-chip" data-tone="low">No close notes</span>';
      const recurring = m.occurrences > 1
        ? '<span class="sa-chip" data-tone="' + (m.occurrences >= 3 ? "medium" : "low") + '" title="Tickets with the same title in history"><i class="fas fa-rotate" aria-hidden="true"></i>Seen ' + m.occurrences + "x</span>" : "";

      let fix;
      if (m.resolution_steps && m.resolution_steps.length) {
        fix = '<div class="sa-fix"><div class="sa-fix-head"><span>How it was resolved</span></div><ol>' +
          m.resolution_steps.slice(0, 6).map((s) => "<li>" + esc(s) + "</li>").join("") + "</ol></div>";
      } else if (m.resolution_notes) {
        fix = '<div class="sa-fix"><div class="sa-fix-head"><span>Close notes</span></div><div class="sa-fix-thin">' + esc(m.resolution_notes.slice(0, 280)) + "</div></div>";
      } else {
        fix = "";
      }

      const b = m.match_breakdown || {};
      const breakdown = '<div class="sa-breakdown">' +
        '<div><div class="sa-f-label">Wording</div>' + meter((b.text || 0) / 100) + "</div>" +
        '<div><div class="sa-f-label">Title</div>' + meter((b.title || 0) / 100) + "</div>" +
        (b.semantic != null ? '<div><div class="sa-f-label">Meaning</div>' + meter(b.semantic / 100) + "</div>" : "") +
        '<div><div class="sa-f-label">Keywords</div>' + meter((b.keywords || 0) / 100) + "</div>" +
        (b.exact_code ? '<div><div class="sa-f-label">Exact code</div><span class="sa-chip" data-tone="high">Matched</span></div>' : "") +
        "</div>";
      const related = (m.related || []).length
        ? '<div class="sa-related"><strong>Same issue also in:</strong> ' +
          m.related.map((r) => "<code>" + esc(r.id) + "</code>").join("") + "</div>" : "";
      const notes = m.resolution_notes && m.resolution_steps && m.resolution_steps.length
        ? '<div class="sa-related"><strong>Full close notes:</strong><div class="sa-fix-thin" style="font-style:normal;white-space:pre-line">' + esc(m.resolution_notes) + "</div></div>" : "";

      return '<article class="sa-result' + (m.tentative ? " is-possible" : "") + '">' + ring(m.match_score) +
        '<div style="min-width:0">' +
          '<div class="sa-result-top">' +
            '<span class="sa-result-id">' + esc(m.incident_id) + "</span>" +
            '<span class="sa-chip" data-tone="' + (m.source === "sr" ? "accent" : "info") + '">' + esc(m.record_type) + "</span>" +
            possibleChip + prio(m.priority) + recurring + qualityChip +
          "</div>" +
          '<div class="sa-result-title">' + (m.title_highlighted || esc(m.title)) + "</div>" +
          '<div class="sa-result-meta">' + meta.join("") + "</div>" +
          (m.description_snippet ? '<div class="sa-result-snippet">' + m.description_snippet + "</div>" : "") +
          fix +
          '<div class="sa-result-foot">' +
            '<div class="sa-signals">' + (m.match_signals || []).map((s) => '<span class="sa-chip">' + esc(s) + "</span>").join("") + "</div>" +
            '<button type="button" class="sa-btn sa-btn-ghost sa-btn-sm" data-copy-id="' + esc(m.incident_id) + '"><i class="fas fa-copy" aria-hidden="true"></i>Copy number</button>' +
          "</div>" +
          '<details class="sa-details" style="margin-top:8px"><summary>Why this match<i class="fas fa-chevron-down" aria-hidden="true"></i></summary>' +
            breakdown + related + notes + "</details>" +
        "</div></article>";
    }

    el.results.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-copy-id]");
      if (btn) copyText(btn.dataset.copyId, "Copied " + btn.dataset.copyId);
    });

    function renderProblems(problems) {
      if (!problems || problems.status !== "ok" || !(problems.matches || []).length) { show(el.probs, false); return; }
      const ms = problems.matches;
      const band = problems.best_band || ms[0].similarity_band;
      const chip = $("sim_problems_best_band");
      chip.dataset.tone = band === "likely" ? "stop" : band === "possible" ? "medium" : "low";
      chip.textContent = band.charAt(0).toUpperCase() + band.slice(1) + " match";
      $("sim_problems_summary").textContent = ms.length + " Problem record" + (ms.length === 1 ? "" : "s") +
        " may already cover this - check before raising a new ticket.";
      el.probsList.innerHTML = ms.map((p) =>
        '<div class="sa-problem">' +
          '<div class="sa-result-top"><span class="sa-result-id">' + esc(p.problem_id) + "</span>" +
            (p.is_known_error ? '<span class="sa-chip" data-tone="medium">Known error</span>' : "") +
            (p.is_major_problem ? '<span class="sa-chip" data-tone="stop">Major problem</span>' : "") +
            '<span class="sa-chip">' + esc(p.state) + "</span>" +
            '<span class="sa-chip" data-tone="' + tone(p.similarity_score) + '">' + Math.round(p.similarity_score) + "% match</span></div>" +
          '<div class="sa-result-title">' + (p.title_highlighted || esc(p.title)) + "</div>" +
          (p.workaround ? '<div class="sa-fix"><div class="sa-fix-head"><span>Workaround</span></div><div style="margin-top:6px;font-size:13px">' + esc(p.workaround.slice(0, 400)) + "</div></div>" : "") +
          (p.cause_notes ? '<div class="sa-result-meta"><span><strong>Cause:</strong>&nbsp;' + esc(p.cause_notes.slice(0, 250)) + "</span></div>" : "") +
        "</div>").join("");
      show(el.probs, true);
    }

    async function loadRecommendation(matches) {
      show(el.rec, false);
      try {
        const data = await fetchJson(SNOW_BASE + "/similar/synthesize", {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ matches }),
        });
        const rec = data.recommendation;
        if (!rec || !(rec.steps || rec.recommended_steps || []).length) return;
        lastRec = rec;
        const chip = $("sim_rec_confidence");
        chip.dataset.tone = rec.confidence === "high" ? "high" : rec.confidence === "medium" ? "medium" : "low";
        chip.textContent = rec.confidence.charAt(0).toUpperCase() + rec.confidence.slice(1) + " confidence";
        $("sim_rec_reason").textContent = rec.confidence_reason || "";
        $("sim_rec_cause").textContent = rec.likely_root_cause || "";
        show($("sim_rec_cause_wrap"), !!rec.likely_root_cause);
        $("sim_rec_steps").innerHTML = stepItems(rec.steps || rec.recommended_steps);
        show(el.rec, true);
      } catch (_) { /* the recommendation is optional */ }
    }
    $("sim_rec_copy").addEventListener("click", () => {
      if (!lastRec) return;
      const lines = [];
      if (lastRec.likely_root_cause) lines.push("Likely root cause: " + lastRec.likely_root_cause, "");
      lines.push("Suggested steps:");
      (lastRec.recommended_steps || []).forEach((s, i) => lines.push("  " + (i + 1) + ". " + s));
      copyText(lines.join("\n"), "Suggested fix copied");
    });

    // Deep link from the template page: ?q=...&source=...
    const params = new URLSearchParams(window.location.search);
    if (params.get("q")) {
      el.desc.value = params.get("q");
      const src = form.querySelector('input[name="sim_source"][value="' + (params.get("source") || "") + '"]');
      if (src) src.checked = true;
      form.requestSubmit();
    }
  };

  // ========================================================================
  // Incident / request template
  // ========================================================================
  window.initTemplatePage = function () {
    wireHistoryImport();
    const form = $("templateForm");
    if (!form) return;
    const el = {
      desc: $("tg_description"), submit: $("tg_submit"), err: $("tg_error"), errMsg: $("tg_error_msg"),
      placeholder: $("tg_placeholder"), loading: $("tg_loading"), result: $("tg_result"),
    };
    let current = null;

    el.desc.addEventListener("input", () => {
      const n = el.desc.value.trim().split(/\s+/).filter(Boolean).length;
      $("tg_len").textContent = n + (n === 1 ? " word" : " words");
    });
    el.desc.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) form.requestSubmit();
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      show(el.err, false);
      const description = el.desc.value.trim();
      if (description.length < 10) {
        el.errMsg.textContent = "Please describe the ticket in at least 10 characters.";
        show(el.err, true); el.desc.focus(); return;
      }
      show(el.placeholder, false); show(el.result, false); show(el.loading, true);
      setBusy(el.submit, true, "Generating...");
      try {
        const data = await fetchJson(SNOW_BASE + "/template/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            description,
            ticket_type: (form.querySelector('input[name="tg_type"]:checked') || {}).value || "auto",
            scope: $("tg_scope").value, urgency: $("tg_urgency").value,
            environment: $("tg_environment").value, caller: $("tg_caller").value.trim() || "Unknown",
            configuration_item: $("tg_ci").value.trim(),
          }),
        });
        current = data.template;
        render(current);
        show(el.result, true);
      } catch (err) {
        show(el.placeholder, true);
        el.errMsg.textContent = err.message;
        show(el.err, true);
      } finally {
        show(el.loading, false);
        setBusy(el.submit, false);
      }
    });

    function render(t) {
      const f = t.fields || {};
      const ev = t.evidence || {};
      $("tg_badges").innerHTML =
        '<span class="sa-chip" data-tone="' + (t.ticket_type === "request" ? "accent" : "info") + '">' + esc(t.ticket_type_label) + "</span>" +
        prio(t.priority) +
        (ev.matches ? '<span class="sa-chip">Based on ' + ev.matches + " similar ticket" + (ev.matches === 1 ? "" : "s") + "</span>" : "") +
        ((t.needs_review || []).length ? '<span class="sa-chip" data-tone="medium"><i class="fas fa-triangle-exclamation" aria-hidden="true"></i>Review ' + esc(t.needs_review.join(", ")) + "</span>" : "");
      $("tg_short_description").textContent = t.short_description || "-";
      $("tg_type_reason").textContent = t.ticket_type_reason || "";

      const notes = (t.notes || []).map((n) =>
        '<div class="sa-callout" data-tone="warn" style="margin:16px 20px 0"><i class="fas fa-circle-info" aria-hidden="true"></i><div>' + esc(n) + "</div></div>");
      if (t.fallback_mode) {
        notes.push('<div class="sa-callout" data-tone="warn" style="margin:16px 20px 0"><i class="fas fa-triangle-exclamation" aria-hidden="true"></i><div><strong>No history or models available.</strong> Values are defaults - import ticket history to get evidence-based suggestions.</div></div>');
      } else if (!ev.matches) {
        notes.push('<div class="sa-callout" data-tone="info" style="margin:16px 20px 0"><i class="fas fa-circle-info" aria-hidden="true"></i><div>No sufficiently similar tickets in history - fields come from the trained models and rules only.</div></div>');
      }
      $("tg_notes").innerHTML = notes.join("") + (notes.length ? '<div style="height:16px"></div>' : "");

      const rows = [
        ["category", "Category"], ["subcategory", "Subcategory"],
        ["assignment_group", "Assignment group"], ["configuration_item", "Configuration item"],
        ["impact", "Impact"], ["urgency", "Urgency"],
        ["priority", "Priority"], ["historical_priority", "Priority on similar tickets"],
      ];
      const review = new Set((t.needs_review || []).map((r) => r.replace(/ /g, "_")));
      let html = rows.map(([key, label]) => fieldCell(key, label, f[key] || {}, review.has(key))).join("");
      html += plainCell("Environment", t.environment) + plainCell("Caller", t.caller && t.caller !== "Unknown" ? t.caller : "");
      $("tg_fields").innerHTML = html;

      const ins = t.insights || {};
      $("tg_kpis").innerHTML = [
        kpi("Typical resolution", "fa-stopwatch", fmtHours(t.estimated_resolution_hours),
            t.estimated_resolution_p80_hours != null ? "8 in 10 within " + fmtHours(t.estimated_resolution_p80_hours)
              : t.eta_source === "model" ? "Model estimate" : "Default for " + t.priority),
        kpi("Evidence", "fa-layer-group", (ev.matches || 0) + (ev.matches === 1 ? " ticket" : " tickets"),
            ev.matches ? "Strength " + Math.round((ev.strength || 0) * 100) + "%" + (ev.models_used ? " + models" : "") : (ev.models_used ? "Models only" : "No history")),
        ins.recurring
          ? kpi("Recurring issue", "fa-rotate", "Seen " + ins.occurrences + " times", "Consider a Problem record", { tone: "warn" })
          : kpi("Recurrence", "fa-rotate", ins.available ? (ins.occurrences > 1 ? ins.occurrences + " similar" : "First seen") : "-", "Same title in history"),
        kpi("Fixes on record", "fa-list-check", ins.available ? (ins.useful_resolutions || 0) + " of " + ins.evidence_count : "-", "strong matches document a fix"),
      ].join("");

      const res = t.resolution;
      if (res && (res.steps || []).length) {
        $("tg_steps").innerHTML = stepItems(res.steps);
        $("tg_steps_reason").textContent = res.confidence_reason || "";
        const c = $("tg_steps_conf");
        c.dataset.tone = res.confidence === "high" ? "high" : res.confidence === "medium" ? "medium" : "low";
        c.textContent = res.confidence.charAt(0).toUpperCase() + res.confidence.slice(1) + " confidence";
        $("tg_root_cause").textContent = t.likely_root_cause || "";
        show($("tg_root_cause_wrap"), !!t.likely_root_cause);
        show($("tg_steps_card"), true);
      } else {
        show($("tg_steps_card"), false);
      }

      const sims = t.similar_incidents || [];
      $("tg_similar").innerHTML = sims.map((s) =>
        "<li><div style='min-width:0'>" +
          '<div class="sa-evidence-title"><code>' + esc(s.id) + "</code> " + esc(s.title) + "</div>" +
          '<div class="sa-evidence-meta">' + esc(s.record_type) +
            (s.assignment_group ? " &middot; " + esc(s.assignment_group) : "") +
            (s.resolution_hours != null ? " &middot; resolved in " + esc(fmtHours(s.resolution_hours)) : "") +
            (s.resolution_quality === "useful" ? " &middot; fix documented" : "") + "</div>" +
        "</div>" + '<span class="sa-chip" data-tone="' + tone(s.similarity) + '">' + Math.round(s.similarity) + "%</span></li>").join("");
      show($("tg_similar_card"), sims.length > 0);
      $("tg_open_similar").href = SNOW_BASE + "/similar?q=" + encodeURIComponent(t.description.slice(0, 500)) +
        "&source=" + (ev.source === "sr" ? "sr" : "incident");
    }

    function fieldCell(key, label, fd, review) {
      const value = fd.value;
      const alts = (fd.alternatives || []).filter((a) => a.value);
      const showMeter = fd.source && fd.source !== "rule" && fd.source !== "form" && value;
      return '<div class="' + (review ? "is-review" : "") + '" data-field="' + key + '">' +
        '<div class="sa-f-label"><span>' + esc(label) + "</span>" + (value ? sourceChip(fd.source) : "") + "</div>" +
        '<div class="sa-f-value' + (value ? "" : " is-empty") + '">' +
          (key === "priority" || key === "historical_priority" ? (value ? prio(value) : "Not enough evidence") : esc(value || "Not enough evidence")) + "</div>" +
        (showMeter ? '<div style="margin-top:6px">' + meter(fd.confidence) + "</div>" : "") +
        (fd.note ? '<div class="sa-f-note">' + esc(fd.note) + "</div>" : "") +
        (alts.length && key !== "historical_priority"
          ? '<div class="sa-f-alts"><span>Or:</span>' + alts.map((a) =>
              '<button type="button" class="sa-chip sa-chip-btn" data-swap="' + key + '" data-value="' + esc(a.value) +
              '" title="Use this instead (' + Math.round(a.confidence * 100) + '% confidence)">' + esc(a.value) + "</button>").join("") + "</div>"
          : "") +
        "</div>";
    }
    function plainCell(label, value) {
      return '<div><div class="sa-f-label"><span>' + esc(label) + '</span></div><div class="sa-f-value' + (value ? "" : " is-empty") + '">' +
        esc(value || "-") + "</div></div>";
    }

    // Swap an alternative into a field (the copied text follows).
    $("tg_fields").addEventListener("click", (e) => {
      const btn = e.target.closest("[data-swap]");
      if (!btn || !current) return;
      const key = btn.dataset.swap, value = btn.dataset.value;
      const fd = current.fields[key];
      const previous = { value: fd.value, confidence: fd.confidence };
      const chosen = fd.alternatives.find((a) => a.value === value);
      fd.alternatives = fd.alternatives.filter((a) => a.value !== value).concat([previous]);
      fd.value = value; fd.confidence = chosen ? chosen.confidence : fd.confidence; fd.source = "form";
      current[key] = value;
      current.needs_review = (current.needs_review || []).filter((r) => r !== key.replace(/_/g, " "));
      render(current);
      toast(key.replace(/_/g, " ") + " set to " + value);
    });

    $("tg_copy").addEventListener("click", () => {
      if (!current) return;
      const t = current;
      const lines = [
        "Type: " + t.ticket_type_label,
        "Short description: " + t.short_description,
        "Category: " + (t.category || ""),
        "Subcategory: " + (t.subcategory || ""),
        "Assignment group: " + (t.assignment_group || ""),
        "Configuration item: " + (t.configuration_item || ""),
        "Impact: " + t.impact, "Urgency: " + t.urgency, "Priority: " + t.priority,
        "Environment: " + (t.environment || ""),
        "", "Description:", t.description,
      ];
      const steps = (t.resolution && t.resolution.recommended_steps) || [];
      if (steps.length) {
        lines.push("", "Suggested resolution steps:");
        steps.forEach((s, i) => lines.push("  " + (i + 1) + ". " + s));
      }
      copyText(lines.join("\n"), "Template copied");
    });
  };

  // ========================================================================
  // CR template
  // ========================================================================
  window.initChangeTemplatePage = function () {
    wireHistoryImport();
    const form = $("crTemplateForm");
    if (!form) return;
    const el = {
      title: $("cr_title"), desc: $("cr_description"), start: $("cr_planned_start"), end: $("cr_planned_end"),
      env: $("cr_environment"), reqBy: $("cr_requested_by"), servers: $("cr_servers"), submit: $("cr_tg_submit"),
      err: $("cr_tg_error"), errMsg: $("cr_tg_error_msg"), loading: $("cr_tg_loading"), result: $("cr_tg_result"),
    };
    let last = null;

    // Live description quality - mirrors section_quality.score_cr_description.
    function localQualityScore(text) {
      text = (text || "").trim();
      const words = text.split(/\s+/).filter(Boolean);
      let score = 0;
      if (words.length >= 40) score += 25; else if (words.length >= 20) score += 18; else if (words.length >= 10) score += 10;
      if (!/^(make\s+(some\s+)?changes?|fix\s+something|update\s+stuff|patch\s+it)/i.test(text)) score += 15;
      const W = {
        what: /\b(server|application|database|service|system|cluster|cmdb|ci|module|patch|upgrade|deploy|config)\b/i,
        where: /\b(production|prod|uat|test|dev|environment|site|location|region|cluster)\b/i,
        when: /\b(today|tonight|this\s+\w+|next\s+\w+|after|during|window|maintenance|scheduled)\b/i,
        why: /\b(because|due\s+to|in\s+order\s+to|to\s+fix|to\s+resolve|to\s+enable|security|performance|compliance)\b/i,
      };
      let answered = 0;
      for (const k in W) if (W[k].test(text)) answered++;
      score += Math.min(8 * answered, 32);
      score += /\b(KB\d+|v\d+\.\d|\d+\.\d+\.\d+|patch\s+\w+|PRB\d+|INC\d+|CHG\d+|RFC\d+)\b/i.test(text) ? 18 : 5;
      score += (text.indexOf("\n") >= 0 || /^\s*[\-\*\d]\./m.test(text) || words.length > 30) ? 10 : 5;
      return Math.min(100, Math.round(score));
    }
    el.desc.addEventListener("input", () => {
      const box = $("cr_quality");
      const text = el.desc.value;
      if (text.trim().length < 5) { box.hidden = true; return; }
      const score = localQualityScore(text);
      const band = score >= 75 ? "green" : score >= 50 ? "amber" : "red";
      box.dataset.band = band;
      box.querySelector("i").style.width = score + "%";
      box.querySelector(".js-q-score").textContent = score + "/100";
      box.hidden = false;
    });

    function windowHint() {
      const hint = $("cr_window_hint");
      const s = new Date(el.start.value), e = new Date(el.end.value);
      if (isNaN(s) || isNaN(e)) { hint.textContent = ""; return; }
      const dur = (e - s) / 36e5, lead = (s - new Date()) / 36e5;
      if (dur <= 0) { hint.textContent = "Planned end must be after planned start."; return; }
      hint.textContent = "Window " + (dur < 48 ? dur.toFixed(1) + "h" : (dur / 24).toFixed(1) + " days") +
        " - starts in " + (lead < 0 ? "the past" : lead < 48 ? Math.round(lead) + "h" : (lead / 24).toFixed(1) + " days") + ".";
    }
    el.start.addEventListener("change", windowHint);
    el.end.addEventListener("change", windowHint);

    // Tabs
    const tabs = ["impl", "backout", "test"];
    function selectTab(name) {
      tabs.forEach((t) => {
        const on = t === name;
        const tab = $("cr_tab_" + t);
        tab.setAttribute("aria-selected", String(on));
        tab.tabIndex = on ? 0 : -1;
        $("cr_plan_" + t).hidden = !on;
      });
    }
    tabs.forEach((t, i) => {
      const tab = $("cr_tab_" + t);
      tab.addEventListener("click", () => selectTab(t));
      tab.addEventListener("keydown", (e) => {
        if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
        const next = tabs[(i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
        selectTab(next); $("cr_tab_" + next).focus();
      });
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      show(el.err, false);
      const payload = {
        title: el.title.value.trim(), description: el.desc.value.trim(),
        planned_start: el.start.value, planned_end: el.end.value, environment: el.env.value,
        requested_by: el.reqBy.value.trim(), server_list: el.servers.value.trim(),
      };
      const missing = [];
      if (payload.title.length < 5) missing.push("a short description (5+ characters)");
      if (payload.description.length < 10) missing.push("a description (10+ characters)");
      if (!payload.planned_start || !payload.planned_end) missing.push("planned start and end");
      if (missing.length) { fail("Please add " + missing.join(", ") + "."); return; }

      show(el.result, false); show(el.loading, true);
      setBusy(el.submit, true, "Generating...");
      try {
        const resp = await fetch(SNOW_BASE + "/api/change-template", {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
        });
        const data = await resp.json();
        if (!resp.ok || data.status === "error" || data.status === "no_models") {
          fail(data.message || "Generation failed."); return;
        }
        last = data;
        render(data);
        show(el.result, true);
        selectTab("impl");
        $("cr_tg_result").scrollIntoView({ behavior: "smooth", block: "start" });
      } catch (err) {
        fail("Network error: " + err.message);
      } finally {
        show(el.loading, false);
        setBusy(el.submit, false);
      }
    });
    function fail(msg) { el.errMsg.textContent = msg; show(el.err, true); }

    function qChip(id, q) {
      const c = $(id);
      if (!c) return;
      if (!q) { c.textContent = "-"; c.dataset.tone = "low"; return; }
      c.textContent = q.score + "/100"; c.dataset.tone = qualityTone(q.band); c.title = q.note || "";
    }
    function fmtDate(s) {
      const d = new Date(s);
      return isNaN(d) ? (s || "-") : d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
    }

    function render(data) {
      const t = data.template || {};
      const q = data.quality || { sections: {}, overall: {} };
      const ps = data.plan_source || {};
      const detail = data.field_detail || {};
      const conf = t.confidences || {};

      const ringEl = $("cr_tg_overall_ring");
      const score = q.overall.score || 0;
      ringEl.style.setProperty("--v", score);
      ringEl.dataset.tone = q.overall.band === "green" ? "high" : q.overall.band === "amber" ? "medium" : "low";
      $("cr_tg_overall_score").textContent = score;
      $("cr_tg_title").textContent = t.title || "";
      const riskTone = { "High": "stop", "Very High": "stop", "Moderate": "medium", "Low": "high" }[t.risk] || "low";
      $("cr_tg_badges").innerHTML =
        '<span class="sa-chip" data-tone="info">' + esc(t.type) + "</span>" +
        '<span class="sa-chip" data-tone="' + riskTone + '">Risk: ' + esc(t.risk) + "</span>" +
        (t.environment ? '<span class="sa-chip">' + esc(t.environment) + "</span>" : "") +
        '<span class="sa-chip">' + esc(fmtDate(t.planned_start)) + "</span>" +
        (ps.mode === "high_confidence_match" ? '<span class="sa-chip" data-tone="high">Strong precedent</span>'
          : ps.mode === "best_available_match" ? '<span class="sa-chip" data-tone="medium">Partial precedent</span>'
          : '<span class="sa-chip" data-tone="stop">No precedent</span>');
      const weakest = q.overall.weakest_sections || [];
      $("cr_tg_overall_weakest").textContent = "Template quality " + score + "/100" +
        (weakest.length ? " - strengthen: " + weakest.join(", ").replace(/_/g, " ") : "");

      // Schedule + rationale
      const sched = data.schedule || { checks: [] };
      const icons = { ok: "fa-circle-check", info: "fa-circle-info", warn: "fa-triangle-exclamation", stop: "fa-circle-xmark" };
      $("cr_tg_checks").innerHTML = sched.checks.map((c) =>
        '<li data-level="' + esc(c.level) + '"><i class="fas ' + (icons[c.level] || icons.info) + '" aria-hidden="true"></i><span>' + esc(c.message) + "</span></li>").join("") +
        (data.environment_note ? '<li data-level="info"><i class="fas fa-circle-info" aria-hidden="true"></i><span>' + esc(data.environment_note) + "</span></li>" : "");
      $("cr_tg_schedule_sub").textContent = "Window " + fmtHours(sched.duration_hours) +
        (sched.typical_duration_hours ? " (similar changes: " + fmtHours(sched.typical_duration_hours) + ")" : "") +
        " - lead time " + fmtHours(Math.max(0, sched.lead_time_hours || 0));

      const oc = data.outcomes || {};
      const ok = oc.similar_successful || 0, bad = oc.similar_failed || 0, total = ok + bad;
      let oh = "";
      if (!total) {
        oh = '<p class="sa-muted">No sufficiently similar changes in history to judge.</p>';
      } else {
        oh = '<div style="display:flex;justify-content:space-between;font-size:13px"><span><strong>' + ok + "</strong> successful</span><span><strong>" + bad + "</strong> failed / backed out</span></div>" +
          '<div class="sa-outcome"><i class="ok" style="width:' + (100 * ok / total) + '%"></i><i class="bad" style="width:' + (100 * bad / total) + '%"></i></div>';
      }
      (oc.failures || []).forEach((f) => {
        oh += '<div class="sa-callout" data-tone="stop" style="margin-top:10px"><i class="fas fa-circle-xmark" aria-hidden="true"></i><div>' +
          "<strong>" + esc(f.change_id) + "</strong> " + esc(f.title) +
          ' <span class="sa-chip" data-tone="stop">' + Math.round(f.similarity_score) + "% similar</span>" +
          '<div class="sa-muted" style="font-size:12.5px;margin-top:2px">' + esc([f.state, f.close_code, f.closed_date].filter(Boolean).join(" - ")) + "</div>" +
          (f.close_notes ? '<div style="font-size:12.5px;margin-top:4px">' + esc(f.close_notes) + "</div>" : "") + "</div></div>";
      });
      if (total && !bad) oh += '<div class="sa-callout" data-tone="ok" style="margin-top:10px"><i class="fas fa-circle-check" aria-hidden="true"></i><div>No similar change on record has failed or been backed out.</div></div>';
      $("cr_tg_outcomes").innerHTML = oh;

      const warnings = (data.server_lookup && data.server_lookup.warnings) || [];
      $("cr_tg_warnings_list").innerHTML = warnings.map((w) => "<li>" + esc(w) + "</li>").join("");
      show($("cr_tg_warnings"), warnings.length > 0);

      // Fields
      const rows = [
        ["type", "Type"], ["risk", "Risk"], ["category", "Category"], ["subcategory", "Subcategory"],
        ["business_service", "Business service"], ["assignment_group", "Assignment group"],
        ["priority", "Priority"], ["impact", "Impact"], ["urgency", "Urgency"],
        ["environment", "Environment"], ["planned_start", "Planned start"], ["planned_end", "Planned end"],
      ];
      $("cr_tg_fields").innerHTML = rows.map(([key, label]) => {
        const qs = key === "planned_start" || key === "planned_end" ? q.sections.planned_window : q.sections[key];
        const d = detail[key];
        let value = t[key];
        if (key === "planned_start" || key === "planned_end") value = fmtDate(value);
        const empty = !value || value === "Unknown";
        const alts = d && d.alternatives ? d.alternatives.filter((a) => a.value) : [];
        return "<div" + (conf[key] != null && conf[key] < 0.45 && !empty ? ' class="is-review"' : "") + ">" +
          '<div class="sa-f-label"><span>' + esc(label) + "</span>" +
            (qs ? '<span class="sa-chip" data-tone="' + qualityTone(qs.band) + '" title="' + esc(qs.note || "") + '">' + qs.score + "</span>" : "") + "</div>" +
          '<div class="sa-f-value' + (empty ? " is-empty" : "") + '">' + esc(empty ? "Not enough evidence" : value) + "</div>" +
          (d ? '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:6px">' + sourceChip(d.source) +
                (conf[key] != null ? meter(conf[key]) : "") + "</div>" : "") +
          (alts.length ? '<div class="sa-f-alts"><span>Or:</span>' + alts.map((a) => '<span class="sa-chip">' + esc(a.value) + "</span>").join("") + "</div>" : "") +
        "</div>";
      }).join("");
      const evd = data.evidence || {};
      $("cr_tg_fields_sub").textContent = "From " + (evd.voters || 0) + " similar change" + (evd.voters === 1 ? "" : "s") +
        ((evd.models_used || []).length ? " and " + evd.models_used.length + " trained field models" : "") + ".";

      // Plans
      const cons = data.plan_consensus || {};
      const compared = ps.compared_with || 0;
      function annotated(name, steps) {
        const c = cons[name] || [];
        return (steps || []).map((s, i) => ({ text: s, support: c[i] ? c[i].support + 1 : null }));
      }
      const empty = ps.mode === "no_corpus_match" ? "No similar past CR - draft this plan manually." : "The source CR has no steps for this plan.";
      $("cr_tg_impl_steps").innerHTML = consensusItems(annotated("implementation_plan", t.implementation_plan), compared, empty);
      $("cr_tg_backout_steps").innerHTML = consensusItems(annotated("backout_plan", t.backout_plan), compared, empty);
      $("cr_tg_test_steps").innerHTML = consensusItems(annotated("test_plan", t.test_plan), compared, empty);
      qChip("cr_tg_impl_quality", q.sections.implementation_plan);
      qChip("cr_tg_backout_quality", q.sections.backout_plan);
      qChip("cr_tg_test_quality", q.sections.test_plan);
      if (ps.disclaimer) $("cr_tg_disclaimer_text").textContent = ps.disclaimer;

      const prov = $("cr_tg_plan_source");
      if (ps.best_match_id) {
        prov.innerHTML = "<div style='min-width:0'><strong>Lifted from " + esc(ps.best_match_id) + "</strong> &middot; " + esc(ps.best_match_title || "") +
          '<div class="sa-muted" style="font-size:12.5px;margin-top:2px">' + esc(ps.reason || "") +
          ((ps.borrowed_sections || []).length ? " " + esc(ps.borrowed_sections.join(" and ")) + " built from steps the similar changes share." : "") + "</div></div>" +
          '<span class="sa-chip" data-tone="' + tone(ps.best_match_score) + '">' + Math.round(ps.best_match_score) + "% match</span>";
        show(prov, true);
        $("cr_tg_plans_subtitle").textContent = compared
          ? "Step badges show how many of the " + (compared + 1) + " most similar changes include each step."
          : "Only one sufficiently similar change - review every step.";
      } else {
        show(prov, false);
        $("cr_tg_plans_subtitle").textContent = "No similar past CRs were found - please draft the plans manually.";
      }

      // Risk
      $("cr_tg_ria_text").textContent = t.risk_impact_analysis_with_warnings || t.risk_impact_analysis || "-";
      qChip("cr_tg_ria_quality", q.sections.risk_impact_analysis);
      $("cr_tg_ria_source").textContent = ps.risk_impact_source === "lifted_from_best_match"
        ? "Taken from " + (ps.best_match_id || "the source CR") + " - update it for this change" : "Composed from the predicted fields, schedule and server lookup";
      $("cr_tg_rationale").innerHTML = (data.rationale || []).map((r) =>
        '<li data-level="warn"><i class="fas fa-triangle-exclamation" aria-hidden="true"></i><span>' + esc(r) + "</span></li>").join("");
      show($("cr_tg_rationale"), (data.rationale || []).length > 0);

      // Similar table
      const list = $("cr_tg_similar_list");
      const sims = data.similar_changes || [];
      list.innerHTML = sims.length ? sims.map((s) => {
        const isSource = ps.best_match_id && s.change_id === ps.best_match_id;
        return '<tr class="' + (isSource ? "is-source" : "") + '">' +
          '<td class="sa-t-title"><code>' + esc(s.change_id) + "</code>" + (isSource ? ' <span class="sa-chip" data-tone="high">Plan source</span>' : "") +
            '<div style="margin-top:4px">' + esc(s.title) + "</div>" +
            '<div class="sa-signals" style="margin-top:6px">' + (s.match_signals || []).map((x) => '<span class="sa-chip">' + esc(x) + "</span>").join("") + "</div></td>" +
          "<td>" + esc(s.type || "-") + '<div class="sa-muted">' + esc(s.risk || "") + "</div></td>" +
          "<td>" + esc(s.assignment_group || "-") + "</td>" +
          "<td>" + esc(s.environment || "-") + "</td>" +
          "<td>" + esc(s.duration_hours != null ? fmtHours(s.duration_hours) : "-") + "</td>" +
          "<td>" + esc((s.closed_date || "").slice(0, 10) || "-") + "</td>" +
          '<td class="sa-num"><span class="sa-chip" data-tone="' + tone(s.similarity_score) + '" title="Similarity, not a success probability">' + Math.round(s.similarity_score) + "%</span></td></tr>";
      }).join("") : '<tr><td colspan="7" class="sa-muted">No similar successful changes match these details and environment.</td></tr>';
      $("cr_tg_similar_sub").textContent = sims.length + " successful change" + (sims.length === 1 ? "" : "s") + " matched";
    }

    function consensusItems(items, compared, emptyText) {
      if (!items.length) return '<li class="sa-steps-empty">' + esc(emptyText) + "</li>";
      return items.map((s) => {
        let chip = "<span></span>";
        if (compared && s.support != null) {
          const n = s.support, of = compared + 1;
          chip = '<span class="sa-chip" data-tone="' + (n >= 3 || n / of >= 0.5 ? "high" : n >= 2 ? "medium" : "low") +
            '" title="Found in ' + n + " of the " + of + ' most similar changes">' + n + "/" + of + "</span>";
        }
        return "<li><span>" + esc(s.text) + "</span>" + chip + "</li>";
      }).join("");
    }

    $("cr_tg_copy").addEventListener("click", () => {
      if (!last) return;
      copyText(buildPlainText(last.template), "CR template copied");
    });
    $("cr_tg_export_xlsx").addEventListener("click", async function () {
      if (!last) return;
      const btn = this;
      setBusy(btn, true, "Building...");
      try {
        const resp = await fetch(SNOW_BASE + "/download/cr-template-excel", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ template: last.template, plan_source: last.plan_source || {},
                                 similar_changes: last.similar_changes || [], quality: last.quality || {} }),
        });
        const ct = resp.headers.get("content-type") || "";
        if (!resp.ok || ct.includes("application/json")) {
          let msg = "Excel export failed.";
          try { const j = await resp.json(); msg = j.error || msg; } catch (_) { /* keep default */ }
          toast(msg); return;
        }
        const blob = await resp.blob();
        const m = (resp.headers.get("content-disposition") || "").match(/filename="?([^"]+)"?/);
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob); a.download = (m && m[1]) || "cr_template.xlsx";
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        URL.revokeObjectURL(a.href);
      } catch (err) {
        toast("Network error: " + err.message);
      } finally {
        setBusy(btn, false);
      }
    });

    function buildPlainText(t) {
      const lines = [
        "CR TEMPLATE", "===========",
        "Short description: " + (t.title || ""), "Type: " + (t.type || ""),
        "Planned start: " + (t.planned_start || ""), "Planned end: " + (t.planned_end || ""),
        "Environment: " + (t.environment || ""), "", "Description:", t.description || "", "",
        "Category: " + (t.category || ""), "Subcategory: " + (t.subcategory || ""),
        "Business service: " + (t.business_service || ""), "Risk: " + (t.risk || ""),
        "Priority: " + (t.priority || ""), "Impact: " + (t.impact || "") + " - Urgency: " + (t.urgency || ""),
        "Assignment group: " + (t.assignment_group || ""), "", "IMPLEMENTATION PLAN:",
      ];
      (t.implementation_plan || []).forEach((s, i) => lines.push((i + 1) + ". " + s));
      lines.push("", "BACKOUT PLAN:");
      (t.backout_plan || []).forEach((s, i) => lines.push((i + 1) + ". " + s));
      lines.push("", "TEST PLAN:");
      (t.test_plan || []).forEach((s, i) => lines.push((i + 1) + ". " + s));
      lines.push("", "RISK & IMPACT ANALYSIS:", t.risk_impact_analysis_with_warnings || t.risk_impact_analysis || "",
        "", "------------------------------------------------------------",
        "Disclaimer: these steps are generated from historical CRs for",
        "reference only. Cross-validate every step before submitting.");
      return lines.join("\n");
    }
  };
})();
