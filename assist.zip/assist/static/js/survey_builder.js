/*
   survey_builder.js - the Survey module's form builder.

   Reads the form from #svSchemaData, draws one card per question into
   #svCanvas, and on submit writes the whole form back into the hidden
   `schema` field as JSON. The server rebuilds it from a whitelist
   (modules/survey/schema.py), so this file is a convenience, never a control.

   Every piece of user text is put on the page with textContent / .value -
   never innerHTML - so a label can contain anything.
*/
(function () {
  'use strict';

  var dataEl = document.getElementById('svSchemaData');
  var cfgEl = document.getElementById('svBuilderConfig');
  var canvas = document.getElementById('svCanvas');
  var form = document.getElementById('svBuilderForm');
  var field = document.getElementById('svSchemaField');
  if (!dataEl || !canvas || !form) { return; }

  var cfg = JSON.parse(cfgEl.textContent || '{}');
  var locked = !!cfg.locked;
  var typeLabels = cfg.types || {};
  var limits = cfg.limits || {questions: 100, options: 50, rows: 50, columns: 12};
  var initial = JSON.parse(dataEl.textContent || '{}');
  var questions = initial.questions || [];
  // The acknowledgement block. A new form starts with it ON (the server's
  // default, passed in the config so the wording is defined in one place).
  var ack = initial.acknowledgement || JSON.parse(JSON.stringify(cfg.ack_default || {enabled: true}));
  var dirty = false;
  var focusIndex = -1;

  var ICONS = {
    section: 'fa-heading', text: 'fa-font', paragraph: 'fa-align-left',
    number: 'fa-hashtag', date: 'fa-calendar-day', radio: 'fa-circle-dot',
    checkbox: 'fa-square-check', dropdown: 'fa-caret-down',
    grid: 'fa-table-cells', grid_multi: 'fa-table-list', table: 'fa-table'
  };
  var CHOICE = ['radio', 'checkbox', 'dropdown'];
  var TABLES = ['grid', 'grid_multi', 'table'];
  var HALF = ['text', 'number', 'date', 'dropdown'];
  var OTHER = ['radio', 'checkbox'];
  var COLUMN_TYPES = [['text', 'Text'], ['yesno', 'Yes / No'], ['number', 'Number']];

  function has(list, v) { return list.indexOf(v) !== -1; }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === 'text') { node.textContent = attrs[k]; }
        else if (k === 'cls') { node.className = attrs[k]; }
        else if (k === 'on') {
          Object.keys(attrs.on).forEach(function (ev) { node.addEventListener(ev, attrs.on[ev]); });
        } else if (attrs[k] === true) { node.setAttribute(k, ''); }
        else if (attrs[k] !== false && attrs[k] != null) { node.setAttribute(k, attrs[k]); }
      });
    }
    (children || []).forEach(function (c) { if (c) { node.appendChild(c); } });
    return node;
  }

  function icon(name) { return el('i', {cls: 'fas ' + name, 'aria-hidden': 'true'}); }

  function touch() { dirty = true; updateCounter(); }

  function blank(type) {
    var q = {id: '', type: type, label: '', help: '', required: false};
    if (has(CHOICE, type)) { q.options = ['Option 1', 'Option 2']; }
    if (has(OTHER, type)) { q.layout = 'stacked'; q.allow_other = false; }
    if (has(HALF, type)) { q.width = 'full'; }
    if (type === 'grid' || type === 'grid_multi') {
      q.rows = ['Row 1', 'Row 2', 'Row 3'];
      q.columns = ['Poor', 'Fair', 'Good', 'Excellent'];
      q.row_header = '';
    }
    if (type === 'table') {
      // No rows: the participant adds one per item while filling the form.
      q.columns = ['Column 1', 'Column 2'];
      q.column_types = ['text', 'text'];
    }
    return q;
  }

  // ------------------------------------------------------------- list editor
  // An editable list of strings (choices, rows or columns). `extra` lets the
  // text-entry table attach a type picker to each column.
  function listEditor(q, key, opts) {
    var wrap = el('div', {cls: 'sv-list'});
    var max = opts.max;

    function draw() {
      wrap.innerHTML = '';
      (q[key] || []).forEach(function (value, i) {
        var input = el('input', {
          type: 'text', cls: 'sv-input', maxlength: '200', disabled: locked,
          'aria-label': opts.noun + ' ' + (i + 1)
        });
        input.value = value;
        input.addEventListener('input', function () { q[key][i] = input.value; touch(); });
        input.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') {
            e.preventDefault();
            if (q[key].length < max) {
              q[key].splice(i + 1, 0, '');
              if (opts.onInsert) { opts.onInsert(i + 1); }
              touch(); draw();
              var next = wrap.querySelectorAll('input.sv-input')[i + 1];
              if (next) { next.focus(); }
            }
          }
        });
        var row = el('div', {cls: 'sv-list-row'}, [
          el('span', {cls: 'sv-mark', 'aria-hidden': 'true', text: opts.mark(i)}),
          input
        ]);
        if (opts.extra) { row.appendChild(opts.extra(i)); }
        row.appendChild(el('button', {
          type: 'button', cls: 'sv-mini is-danger', title: 'Remove', 'aria-label': 'Remove ' + opts.noun.toLowerCase() + ' ' + (i + 1),
          disabled: locked || q[key].length <= opts.min,
          on: {click: function () {
            q[key].splice(i, 1);
            if (opts.onRemove) { opts.onRemove(i); }
            touch(); draw();
          }}
        }, [icon('fa-xmark')]));
        wrap.appendChild(row);
      });
      if (!locked && (q[key] || []).length < max) {
        wrap.appendChild(el('button', {
          type: 'button', cls: 'sv-list-add', text: '+ Add ' + opts.noun.toLowerCase(),
          on: {click: function () {
            q[key].push('');
            if (opts.onInsert) { opts.onInsert(q[key].length - 1); }
            touch(); draw();
            var inputs = wrap.querySelectorAll('input.sv-input');
            if (inputs.length) { inputs[inputs.length - 1].focus(); }
          }}
        }));
      }
    }
    draw();
    return wrap;
  }

  // ------------------------------------------------------------------- card
  function card(q, index, number) {
    var isSection = q.type === 'section';
    var node = el('article', {
      cls: 'sv-qcard' + (isSection ? ' is-section' : '') + (index === focusIndex ? ' is-focus' : ''),
      'data-index': String(index)
    });
    node.addEventListener('focusin', function () {
      focusIndex = index;
      Array.prototype.forEach.call(canvas.querySelectorAll('.sv-qcard.is-focus'), function (c) {
        if (c !== node) { c.classList.remove('is-focus'); }
      });
      node.classList.add('is-focus');
    });

    // head
    var head = el('div', {cls: 'sv-qcard-head'}, [
      isSection ? null : el('span', {cls: 'sv-qnum', text: 'Q' + number}),
      el('span', {cls: 'sv-qtype'}, [icon(ICONS[q.type] || 'fa-question'), document.createTextNode(typeLabels[q.type] || q.type)]),
      el('span', {cls: 'sv-spacer'}),
      el('button', {type: 'button', cls: 'sv-mini', title: 'Move up', 'aria-label': 'Move up',
                    disabled: locked || index === 0, on: {click: function () { move(index, -1); }}}, [icon('fa-arrow-up')]),
      el('button', {type: 'button', cls: 'sv-mini', title: 'Move down', 'aria-label': 'Move down',
                    disabled: locked || index === questions.length - 1, on: {click: function () { move(index, 1); }}}, [icon('fa-arrow-down')]),
      el('button', {type: 'button', cls: 'sv-mini', title: 'Duplicate', 'aria-label': 'Duplicate',
                    disabled: locked || questions.length >= limits.questions, on: {click: function () { copy(index); }}}, [icon('fa-clone')]),
      el('button', {type: 'button', cls: 'sv-mini is-danger', title: 'Delete', 'aria-label': 'Delete',
                    disabled: locked, on: {click: function () { remove(index); }}}, [icon('fa-trash-can')])
    ]);
    node.appendChild(head);

    // body
    var body = el('div', {cls: 'sv-qcard-body'});
    var label = el('input', {
      type: 'text', cls: 'sv-input', maxlength: '500', disabled: locked,
      placeholder: isSection ? 'Section heading, e.g. USER INFORMATION' : 'Question',
      'aria-label': isSection ? 'Section heading' : 'Question text'
    });
    label.value = q.label || '';
    label.style.fontWeight = '600';
    label.addEventListener('input', function () { q.label = label.value; touch(); });
    body.appendChild(label);

    var help = el('textarea', {
      cls: 'sv-input', maxlength: '1000', rows: isSection ? '2' : '1', disabled: locked,
      placeholder: isSection ? 'Text under the heading (optional) - instructions, a declaration...'
                             : 'Help text (optional), e.g. (If No, please give details below)',
      'aria-label': isSection ? 'Section text' : 'Help text'
    });
    help.value = q.help || '';
    help.addEventListener('input', function () { q.help = help.value; touch(); });
    body.appendChild(help);

    if (has(CHOICE, q.type)) {
      body.appendChild(el('div', {cls: 'sv-sub-label', text: 'Choices'}));
      body.appendChild(listEditor(q, 'options', {
        noun: 'Choice', min: 1, max: limits.options,
        mark: function (i) { return q.type === 'radio' ? 'o' : q.type === 'checkbox' ? '[]' : String(i + 1) + '.'; }
      }));
    }

    if (has(TABLES, q.type) && q.type !== 'table') {
      var rh = el('input', {type: 'text', cls: 'sv-input', maxlength: '200', disabled: locked,
                            placeholder: 'Heading over the row labels (optional), e.g. Service area',
                            'aria-label': 'Row label heading'});
      rh.value = q.row_header || '';
      rh.addEventListener('input', function () { q.row_header = rh.value; touch(); });
      body.appendChild(rh);
    }
    if (has(TABLES, q.type)) {
      if (q.type === 'table' && !q.column_types) { q.column_types = q.columns.map(function () { return 'text'; }); }
      var colOpts = {
        noun: 'Column', min: 1, max: limits.columns,
        mark: function (i) { return String(i + 1) + '.'; }
      };
      if (q.type === 'table') {
        colOpts.extra = function (i) {
          var sel = el('select', {cls: 'sv-input', disabled: locked, 'aria-label': 'Column ' + (i + 1) + ' type'});
          COLUMN_TYPES.forEach(function (t) {
            var o = el('option', {value: t[0], text: t[1]});
            if ((q.column_types[i] || 'text') === t[0]) { o.selected = true; }
            sel.appendChild(o);
          });
          sel.addEventListener('change', function () { q.column_types[i] = sel.value; touch(); });
          return sel;
        };
        colOpts.onInsert = function (i) { q.column_types.splice(i, 0, 'text'); };
        colOpts.onRemove = function (i) { q.column_types.splice(i, 1); };
      }
      if (q.type === 'table') {
        // Columns only - rows are added by the participant on the form.
        delete q.rows;
        delete q.row_header;
        body.appendChild(el('div', null, [
          el('div', {cls: 'sv-sub-label', text: 'Columns (and what goes in them)'}),
          listEditor(q, 'columns', colOpts)
        ]));
        body.appendChild(el('div', {cls: 'sv-dyn-note'}, [
          icon('fa-table-list'),
          el('span', {text: 'No rows to set up: participants add a row for each item ("+ Add row") while filling in the form, up to ' + limits.rows + ' rows.'})
        ]));
      } else {
        body.appendChild(el('div', {cls: 'sv-two'}, [
          el('div', null, [
            el('div', {cls: 'sv-sub-label', text: 'Rows'}),
            listEditor(q, 'rows', {noun: 'Row', min: 1, max: limits.rows,
                                   mark: function (i) { return String(i + 1) + '.'; }})
          ]),
          el('div', null, [
            el('div', {cls: 'sv-sub-label', text: 'Columns (the choices)'}),
            listEditor(q, 'columns', colOpts)
          ])
        ]));
      }
    }
    node.appendChild(body);

    // foot - the per-question options
    if (!isSection) {
      var foot = el('div', {cls: 'sv-qcard-foot'});
      foot.appendChild(toggle('Required', !!q.required, function (v) { q.required = v; }));
      if (has(OTHER, q.type)) {
        foot.appendChild(toggle('"Other (please specify)"', !!q.allow_other, function (v) { q.allow_other = v; }));
        foot.appendChild(picker('Layout', q.layout || 'stacked',
          [['stacked', 'One per line'], ['inline', 'Side by side']], function (v) { q.layout = v; }));
      }
      if (has(HALF, q.type)) {
        foot.appendChild(picker('Width', q.width || 'full',
          [['full', 'Full line'], ['half', 'Half - pairs with the next']], function (v) { q.width = v; }));
      }
      node.appendChild(foot);
    }
    return node;
  }

  function toggle(text, value, set) {
    var box = el('input', {type: 'checkbox', disabled: locked});
    box.checked = value;
    box.addEventListener('change', function () { set(box.checked); touch(); });
    return el('label', null, [box, document.createTextNode(text)]);
  }

  function picker(text, value, choices, set) {
    var sel = el('select', {disabled: locked, 'aria-label': text});
    choices.forEach(function (c) {
      var o = el('option', {value: c[0], text: c[1]});
      if (c[0] === value) { o.selected = true; }
      sel.appendChild(o);
    });
    sel.addEventListener('change', function () { set(sel.value); touch(); });
    return el('label', null, [document.createTextNode(text + ':'), sel]);
  }

  // ------------------------------------------------------ acknowledgement
  // Always the last card; it cannot be moved, because on the form it is the
  // sign-off that closes it.
  function ackCard() {
    var node = el('article', {cls: 'sv-qcard sv-ackcard' + (ack.enabled ? '' : ' is-off')});
    var onBox = el('input', {type: 'checkbox', disabled: locked});
    onBox.checked = !!ack.enabled;
    onBox.addEventListener('change', function () { ack.enabled = onBox.checked; touch(); render(); });
    node.appendChild(el('div', {cls: 'sv-qcard-head'}, [
      el('span', {cls: 'sv-qtype'}, [icon('fa-file-signature'), document.createTextNode('Acknowledgement - end of form')]),
      el('span', {cls: 'sv-spacer'}),
      el('label', {cls: 'sv-switch'}, [onBox, document.createTextNode(ack.enabled ? 'Included' : 'Not included')])
    ]));
    if (!ack.enabled) {
      node.appendChild(el('div', {cls: 'sv-qcard-body'}, [
        el('p', {cls: 'sv-muted', style: 'margin:0;font-size:13px;',
                 text: 'Participants will not be asked to confirm, sign or date this form. Tick "Not included" to add the block back.'})
      ]));
      return node;
    }
    var body = el('div', {cls: 'sv-qcard-body'});
    var heading = el('input', {type: 'text', cls: 'sv-input', maxlength: '200', disabled: locked,
                               'aria-label': 'Acknowledgement heading'});
    heading.value = ack.heading || '';
    heading.style.fontWeight = '600';
    heading.addEventListener('input', function () { ack.heading = heading.value; touch(); });
    var statement = el('textarea', {cls: 'sv-input', maxlength: '1000', rows: '3', disabled: locked,
                                    'aria-label': 'Statement participants confirm'});
    statement.value = ack.statement || '';
    statement.addEventListener('input', function () { ack.statement = statement.value; touch(); });
    body.appendChild(heading);
    body.appendChild(el('div', {cls: 'sv-sub-label', text: 'Statement the participant confirms'}));
    body.appendChild(statement);
    body.appendChild(el('div', {cls: 'sv-ack-preview'}, [
      el('span', null, [icon('fa-square-check'), document.createTextNode(' I confirm')]),
      el('span', null, [icon('fa-user'), document.createTextNode(' User Name')]),
      el('span', null, [icon('fa-envelope'), document.createTextNode(' Email (one response each)')]),
      el('span', null, [icon('fa-calendar-day'), document.createTextNode(' Date (today)')]),
      ack.comments ? el('span', null, [icon('fa-comment'), document.createTextNode(' ' + (ack.comments_label || 'Comments'))]) : null
    ]));
    node.appendChild(body);

    var foot = el('div', {cls: 'sv-qcard-foot'});
    foot.appendChild(toggle('Comments box', ack.comments !== false, function (v) { ack.comments = v; render(); }));
    if (ack.comments !== false) {
      var lbl = el('input', {type: 'text', cls: 'sv-input', maxlength: '200', disabled: locked,
                             'aria-label': 'Comments box label', style: 'width:260px;padding:4px 8px;font-size:12.5px;'});
      lbl.value = ack.comments_label || '';
      lbl.addEventListener('input', function () { ack.comments_label = lbl.value; touch(); });
      foot.appendChild(el('label', null, [document.createTextNode('Label:'), lbl]));
    }
    foot.appendChild(el('span', {cls: 'sv-muted', text: 'Confirm, name, email and date are always required.'}));
    node.appendChild(foot);
    return node;
  }

  // ------------------------------------------------------------- operations
  function render() {
    canvas.innerHTML = '';
    if (!questions.length) {
      canvas.appendChild(el('div', {cls: 'sv-canvas-empty'}, [
        icon('fa-layer-group'),
        el('strong', {text: 'Your form is empty.'}),
        el('div', {text: 'Add a section heading or a question from the panel on the left.'})
      ]));
    }
    var n = 0;
    questions.forEach(function (q, i) {
      if (q.type !== 'section') { n += 1; }
      canvas.appendChild(card(q, i, n));
    });
    canvas.appendChild(ackCard());
    updateCounter();
    Array.prototype.forEach.call(document.querySelectorAll('[data-add]'), function (b) {
      b.disabled = locked || questions.length >= limits.questions;
    });
  }

  function focusCard(index) {
    var target = canvas.querySelector('.sv-qcard[data-index="' + index + '"]');
    if (!target) { return; }
    target.scrollIntoView({behavior: 'smooth', block: 'center'});
    var input = target.querySelector('input.sv-input');
    if (input) { setTimeout(function () { input.focus(); }, 250); }
  }

  function add(type) {
    if (locked || questions.length >= limits.questions) { return; }
    var at = focusIndex >= 0 && focusIndex < questions.length ? focusIndex + 1 : questions.length;
    questions.splice(at, 0, blank(type));
    focusIndex = at;
    touch(); render(); focusCard(at);
  }

  function move(index, delta) {
    var to = index + delta;
    if (to < 0 || to >= questions.length) { return; }
    var q = questions.splice(index, 1)[0];
    questions.splice(to, 0, q);
    focusIndex = to;
    touch(); render(); focusCard(to);
  }

  function copy(index) {
    var clone = JSON.parse(JSON.stringify(questions[index]));
    clone.id = '';
    questions.splice(index + 1, 0, clone);
    focusIndex = index + 1;
    touch(); render(); focusCard(index + 1);
  }

  function remove(index) {
    var q = questions[index];
    var name = q.label ? '"' + q.label + '"' : 'this ' + (q.type === 'section' ? 'section' : 'question');
    if (!window.confirm('Delete ' + name + '?')) { return; }
    questions.splice(index, 1);
    focusIndex = Math.min(index, questions.length - 1);
    touch(); render();
  }

  function updateCounter() {
    var counter = document.getElementById('svCounter');
    if (!counter || !counter.getAttribute('data-base')) {
      if (counter) { counter.setAttribute('data-base', counter.textContent.trim()); }
    }
    if (!counter) { return; }
    var answerable = questions.filter(function (q) { return q.type !== 'section'; }).length;
    counter.textContent = answerable + ' question' + (answerable === 1 ? '' : 's') +
      (dirty ? ' - unsaved changes. ' : '. ') + counter.getAttribute('data-base');
  }

  Array.prototype.forEach.call(document.querySelectorAll('[data-add]'), function (b) {
    b.addEventListener('click', function () { add(b.getAttribute('data-add')); });
  });

  document.getElementById('svTitle').addEventListener('input', function () { dirty = true; });
  document.getElementById('svDescription').addEventListener('input', function () { dirty = true; });

  form.addEventListener('submit', function (e) {
    var answerable = questions.filter(function (q) { return q.type !== 'section'; });
    if (!locked && !answerable.length) {
      e.preventDefault();
      window.alert('Add at least one question before saving.');
      return;
    }
    field.value = JSON.stringify({questions: questions, acknowledgement: ack});
    dirty = false;
  });

  window.addEventListener('beforeunload', function (e) {
    if (dirty) { e.preventDefault(); e.returnValue = ''; }
  });

  render();
}());
