"""
html_sanitizer.py - allowlist sanitizer for rich text authored in the app.

Used by the ServiceNow Guide, whose sections are edited in a contenteditable
editor and rendered with ``|safe``. Before this, whatever an editor saved ran
on the application's origin for every reader, administrators included: a
guide author effectively held a script-injection permission, which is far
more than "can edit documentation".

How it works
------------
The input is TOKENISED with the standard library's HTMLParser and a NEW
document is written out from the tokens that pass the allowlist. Nothing of
the input is copied through as a string: every tag name comes from the
allowlist, every attribute value is re-escaped, and text is re-escaped. That
is what makes the output safe even when the input is malformed - there is no
"clean the bad bits out of the original" step for a parser differential to
get between.

* Tags not on the allowlist are dropped but their TEXT is kept (a pasted
  <font> or <section> loses its markup, not its words).
* Tags in DROP_WITH_CONTENT (script, style, iframe, svg, math, ...) are
  dropped together with everything inside them.
* Only allowlisted attributes survive; every ``on*`` handler is gone because
  none is on the list.
* href keeps http, https, mailto, in-page (#) and relative links only.
* style keeps an allowlist of layout/typography properties, and only values
  made of plain characters - no url(), expression(), escapes or comments.
* Comments, doctypes and processing instructions are dropped.
* Open tags are closed at the end, so the fragment cannot leave an unclosed
  element that swallows the page around it.

Standard library only, so it needs nothing new installed on the Python 3.9
production host. ASCII-only source per the project convention.
"""

from __future__ import annotations

import html
import re
from html.parser import HTMLParser

ALLOWED_TAGS = frozenset({
    'a', 'abbr', 'b', 'blockquote', 'br', 'caption', 'code', 'col',
    'colgroup', 'dd', 'del', 'div', 'dl', 'dt', 'em', 'h1', 'h2', 'h3', 'h4',
    'h5', 'h6', 'hr', 'i', 'ins', 'kbd', 'li', 'mark', 'ol', 'p', 'pre', 's',
    'small', 'span', 'strike', 'strong', 'sub', 'sup', 'table', 'tbody', 'td',
    'tfoot', 'th', 'thead', 'tr', 'u', 'ul',
})

VOID_TAGS = frozenset({'br', 'col', 'hr'})

# Dropped WITH their content: the content is code, styling or a foreign
# document, never prose worth keeping.
DROP_WITH_CONTENT = frozenset({
    'script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed',
    'applet', 'template', 'noscript', 'noembed', 'noframes', 'xmp',
    'plaintext', 'textarea', 'select', 'option', 'title', 'head', 'svg',
    'math', 'canvas', 'audio', 'video', 'form', 'button', 'input', 'link',
    'meta', 'base',
})

GLOBAL_ATTRS = frozenset({'class', 'style', 'title'})
TAG_ATTRS = {
    'a': frozenset({'href', 'target'}),
    'td': frozenset({'colspan', 'rowspan'}),
    'th': frozenset({'colspan', 'rowspan', 'scope'}),
    'ol': frozenset({'start', 'type'}),
    'col': frozenset({'span'}),
    'colgroup': frozenset({'span'}),
}

SAFE_URL_SCHEMES = frozenset({'http', 'https', 'mailto'})

ALLOWED_CSS_PROPERTIES = frozenset({
    'background-color', 'border', 'border-bottom', 'border-collapse',
    'border-color', 'border-left', 'border-radius', 'border-right',
    'border-style', 'border-top', 'border-width', 'color', 'flex',
    'font-size', 'font-style', 'font-weight', 'gap', 'height', 'line-height',
    'list-style-type', 'margin', 'margin-bottom', 'margin-left',
    'margin-right', 'margin-top', 'max-width', 'min-width', 'padding',
    'padding-bottom', 'padding-left', 'padding-right', 'padding-top',
    'text-align', 'text-decoration', 'vertical-align', 'white-space', 'width',
})
# Letters, digits, whitespace and . , % # ( ) + - only. Rules out url(...)
# payloads by construction (no ':' or '/' or quotes), escapes ('\'),
# comments ('/*'), and at-rules ('@').
_CSS_VALUE_RE = re.compile(r'^[A-Za-z0-9\s.,%#()+\-]*$')
_CSS_FORBIDDEN_WORDS = re.compile(r'expression|url|javascript|behavior|binding',
                                  re.IGNORECASE)

_INT_RE = re.compile(r'^\d{1,3}$')
_CONTROL_RE = re.compile(r'[\x00-\x20\x7f]+')


def _clean_style(value: str) -> str | None:
    kept = []
    for declaration in value.split(';'):
        if ':' not in declaration:
            continue
        prop, _, val = declaration.partition(':')
        prop = prop.strip().lower()
        val = val.strip()
        if prop not in ALLOWED_CSS_PROPERTIES or not val:
            continue
        if not _CSS_VALUE_RE.match(val) or _CSS_FORBIDDEN_WORDS.search(val):
            continue
        kept.append(f'{prop}: {val}')
    return '; '.join(kept) if kept else None


def _clean_href(value: str) -> str | None:
    # Browsers ignore control characters and whitespace inside a scheme
    # ("java\tscript:"), so the check is made on the value with them removed.
    probe = _CONTROL_RE.sub('', value)
    if not probe:
        return None
    if probe.startswith(('#', '/', '?')) and not probe.startswith('//'):
        return value.strip()
    if probe.startswith('//'):
        return None   # protocol-relative: an off-site link in disguise
    scheme, sep, _ = probe.partition(':')
    if not sep:
        return value.strip()          # plain relative path
    if '/' in scheme or '?' in scheme or '#' in scheme:
        return value.strip()          # the ':' is past the path start
    if scheme.lower() in SAFE_URL_SCHEMES:
        return value.strip()
    return None


def _clean_attr(tag: str, name: str, value: str | None) -> str | None:
    allowed = TAG_ATTRS.get(tag, frozenset()) | GLOBAL_ATTRS
    if name not in allowed:
        return None
    value = value or ''
    if name == 'style':
        return _clean_style(value)
    if name == 'href':
        return _clean_href(value)
    if name == 'target':
        return '_blank' if value.strip().lower() == '_blank' else None
    if name in ('colspan', 'rowspan', 'span', 'start'):
        return value.strip() if _INT_RE.match(value.strip()) else None
    if name == 'type':
        return value.strip() if value.strip() in ('1', 'a', 'A', 'i', 'I') else None
    if name == 'scope':
        v = value.strip().lower()
        return v if v in ('row', 'col', 'rowgroup', 'colgroup') else None
    return value


class _Sanitizer(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out: list[str] = []
        self.stack: list[str] = []
        self.skip_depth = 0
        self.skip_tag: str | None = None

    # -- tags ------------------------------------------------------------
    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if self.skip_depth:
            if tag == self.skip_tag:
                self.skip_depth += 1
            return
        if tag in DROP_WITH_CONTENT:
            if tag not in VOID_TAGS and tag not in ('input', 'link', 'meta', 'base'):
                self.skip_tag = tag
                self.skip_depth = 1
            return
        if tag not in ALLOWED_TAGS:
            return
        parts = [tag]
        has_blank_target = False
        for name, value in attrs:
            name = name.lower()
            cleaned = _clean_attr(tag, name, value)
            if cleaned is None:
                continue
            if name == 'target':
                has_blank_target = True
            parts.append(f'{name}="{html.escape(cleaned, quote=True)}"')
        if tag == 'a' and has_blank_target:
            parts.append('rel="noopener noreferrer"')
        self.out.append('<' + ' '.join(parts) + '>')
        if tag not in VOID_TAGS:
            self.stack.append(tag)

    def handle_startendtag(self, tag, attrs):
        was_skipping = bool(self.skip_depth)
        self.handle_starttag(tag, attrs)
        tag = tag.lower()
        if not was_skipping and self.skip_depth:
            # <svg/> or <script/>: nothing inside it to drop.
            self.skip_depth = 0
            self.skip_tag = None
            return
        # <div/> in HTML is an OPEN div; <br/> is a void element. Only pop
        # what handle_starttag pushed for a self-closed non-void element.
        if (not self.skip_depth and tag in ALLOWED_TAGS
                and tag not in VOID_TAGS and self.stack
                and self.stack[-1] == tag):
            self.stack.pop()
            self.out.append(f'</{tag}>')

    def handle_endtag(self, tag):
        tag = tag.lower()
        if self.skip_depth:
            if tag == self.skip_tag:
                self.skip_depth -= 1
                if not self.skip_depth:
                    self.skip_tag = None
            return
        if tag not in ALLOWED_TAGS or tag in VOID_TAGS or tag not in self.stack:
            return
        # Close anything left open inside it, so nesting stays well formed.
        while self.stack:
            open_tag = self.stack.pop()
            self.out.append(f'</{open_tag}>')
            if open_tag == tag:
                break

    # -- content ---------------------------------------------------------
    def handle_data(self, data):
        if not self.skip_depth:
            self.out.append(html.escape(data, quote=False))

    def handle_comment(self, data):
        pass

    def handle_decl(self, decl):
        pass

    def handle_pi(self, data):
        pass

    def unknown_decl(self, data):
        pass

    def result(self) -> str:
        self.close()
        while self.stack:
            self.out.append(f'</{self.stack.pop()}>')
        return ''.join(self.out)


def sanitize_html(value) -> str:
    """Return ``value`` reduced to the allowlisted HTML subset. None -> ''."""
    if not value:
        return ''
    parser = _Sanitizer()
    parser.feed(str(value))
    return parser.result()
