#!/usr/bin/env python3
"""Single-application user-journey performance recorder for Microsoft Edge (Python 3.9).

Requires: Windows, Microsoft Edge, openpyxl (pip install openpyxl).
No Selenium, Playwright, WebDriver, or application-code changes.

Use:
    py -3.9 url_journey_recorder.py --url "https://app.example.local/" --name "CRM"

What it does:
  * Opens ONE application URL in ONE tab of a private Edge window.
  * Every user step in that tab is recorded and timed:
      - clicks on buttons, links, tabs, menu items and other controls
      - page navigations (link, typed address, reload, back/forward, redirect)
      - in-page route changes of single-page applications (no full reload)
      - form submissions (Enter key or submit button)
      - dropdown / checkbox / radio selections
  * For each step the browser's response is captured: time to last network
    response, server wait, DOM ready, page load, HTTP status of the page,
    request count, failures, cached responses, data size and JavaScript
    errors - plus the page the user moved from and the page they landed on.
  * Typed text, field values, query strings and URL fragments are NEVER
    recorded (only hash routes such as #/orders are kept, without queries).
  * Every tab is recorded: the first one, popups (window.open) and links or
    buttons that open a new tab. A new tab is paused until it is instrumented,
    so its first page load is timed too. Each step shows which tab it ran in
    and a popup's first step shows the step that opened it.
  * Server method timings: if the application sends a Server-Timing response
    header (see dotnet/ServerTiming.cs for ASP.NET), each method / phase and its
    duration is listed on the "Server methods" and "Method summary" sheets.
    Pass --timing-key (or set JOURNEY_TIMING_KEY) to send the cookie that the
    server-side module requires before it emits the header.
  * Stop with Ctrl+C in this console (or close the Edge window). A formatted
    Excel report url_journey_report_<timestamp>.xlsx is written.
"""

import argparse
import base64
import datetime as dt
import hashlib
import json
import math
import os
import select
import shutil
import statistics
import socket
import struct
import subprocess
import sys
import tempfile
import time
import urllib.request
import urllib.error
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    Workbook = None


# A step is complete when its tracked network requests finish and there have
# been no new tracked requests for QUIET_MS. This is NOT exact visual readiness.
QUIET_MS = 1200
NO_REQUEST_WAIT_MS = 2000
MAX_ACTION_MS = 120000
MAX_WS_FRAME_BYTES = 16 * 1024 * 1024
TAB_POLL_SECONDS = 2.0
MERGE_MS = 1000              # a submit/change this soon after a click belongs to that click

FAST_MS = 1000               # steps under this are rated "Fast"
DEFAULT_SLOW_MS = 3000       # steps at/above this are rated "Slow"

# Streaming / fire-and-forget requests never "finish" in the normal sense and
# would hold every step open until MAX_ACTION_MS. They are not timed.
UNTRACKED_TYPES = ('EventSource', 'WebSocket', 'Ping', 'CSPViolationReport', 'Media')

# Change to True if your application uses custom clickable divs rather than
# normal HTML buttons, links, or accessible role=button controls.
RECORD_ALL_CLICKS = False

# Cookie that asks the server to emit Server-Timing (value = --timing-key).
TIMING_COOKIE = 'JourneyTiming'
MAX_SERVER_TIMING_ENTRIES = 100

# DevTools features the first tab cannot be recorded without.
REQUIRED_FEATURES = ('Runtime.addBinding', 'Page.addScriptToEvaluateOnNewDocument', 'Network.enable')

KIND_CLICK = 'Click'
KIND_NAV = 'Navigation'
KIND_ROUTE = 'Route change'
KIND_SUBMIT = 'Form submit'
KIND_SELECT = 'Selection'

NAV_LABELS = {'navigate': 'Open page', 'reload': 'Reload', 'back_forward': 'Back/Forward to',
              'back_forward_cache': 'Back/Forward (cached) to', 'prerender': 'Open page'}

INJECT_JS = r"""
(function () {
  // Flag the DOCUMENT: a popup's first about:blank page hands its window object on to
  // the real page, so a window flag would skip the listeners on the new document.
  if (document.__edgeJourneyInstalled) return;
  document.__edgeJourneyInstalled = true;
  var newWindow = !window.__edgeJourneyInstalled;
  window.__edgeJourneyInstalled = true;
  var allClicks = __ALL_CLICKS__;
  function where() {
    var url = location.origin + location.pathname;
    var h = location.hash || '';
    if (/^#!?\//.test(h)) url += h.split('?')[0];
    return url;
  }
  function text(raw) {
    return String(raw || '').replace(/\s+/g, ' ').trim().slice(0, 100);
  }
  function send(obj) {
    try {
      obj.url = where();
      obj.title = document.title || '';
      obj.timeMs = Date.now();
      window.__edgeJourneyNotify(JSON.stringify(obj));
    } catch (ex) { /* Don't interfere with application behavior. */ }
  }
  function fieldLabel(el) {
    var lab = (el.labels && el.labels.length) ? el.labels[0].innerText : '';
    return text(el.getAttribute('aria-label') || lab || el.title || el.name || el.id ||
                el.tagName.toLowerCase());
  }
  document.addEventListener('click', function (ev) {
    try {
      var target = ev.target;
      if (!target || !target.closest) return;
      var hit = target.closest('button, a, input[type="submit"], input[type="button"], input[type="image"], ' +
                               '[role="button"], [role="tab"], [role="menuitem"], [role="link"], [onclick], [tabindex]');
      if (!hit && !allClicks) return;
      var el = hit || target;
      // Only button-type inputs may use their value as a label - never a text box.
      var value = (el.tagName === 'INPUT' && /^(submit|button|image|reset)$/i.test(el.type)) ? el.value : '';
      var label = text(el.getAttribute('aria-label') || el.innerText || value || el.title || el.id ||
                       el.getAttribute('name') || el.tagName) || 'Unnamed control';
      send({ type: 'click', label: label });
    } catch (ex) { /* Don't interfere with application behavior. */ }
  }, true);
  document.addEventListener('submit', function (ev) {
    try {
      var f = ev.target;
      var label = text(f.getAttribute('aria-label') || f.getAttribute('name') || f.id ||
                       (f.getAttribute('action') || '').split('?')[0]) || 'form';
      send({ type: 'submit', label: label });
    } catch (ex) { /* Don't interfere with application behavior. */ }
  }, true);
  document.addEventListener('change', function (ev) {
    try {
      var el = ev.target;
      if (!el || !el.tagName) return;
      var kind = String(el.type || '').toLowerCase();
      if (el.tagName !== 'SELECT' && kind !== 'checkbox' && kind !== 'radio') return;
      send({ type: 'change', label: fieldLabel(el) });
    } catch (ex) { /* Don't interfere with application behavior. */ }
  }, true);
  if (newWindow) window.addEventListener('pageshow', function (ev) {
    setTimeout(function () {
      try {
        var nav = performance.getEntriesByType ? performance.getEntriesByType('navigation')[0] : null;
        send({ type: 'page', persisted: !!ev.persisted,
               navType: ev.persisted ? 'back_forward_cache' : (nav ? nav.type : '') });
      } catch (ex) { /* Don't interfere with application behavior. */ }
    }, 0);
  });
})();
""".replace('__ALL_CLICKS__', 'true' if RECORD_ALL_CLICKS else 'false')


def clean_url(raw):
    """Never record query strings or URL fragments (potentially sensitive).
    The one exception is a hash route (#/orders or #!/orders), kept without its query."""
    try:
        parts = urlsplit(raw or '')
        frag = parts.fragment if parts.fragment.startswith(('/', '!/')) else ''
        return urlunsplit((parts.scheme, parts.netloc, parts.path, '', frag.split('?')[0]))
    except ValueError:
        return '[invalid URL]'


def _split_unquoted(raw, sep):
    """Split on `sep` outside double-quoted strings (Server-Timing syntax)."""
    parts, cur, quoted, escaped = [], [], False, False
    for ch in raw:
        if escaped:
            escaped = False
        elif ch == '\\' and quoted:
            escaped = True
        elif ch == '"':
            quoted = not quoted
        elif ch == sep and not quoted:
            parts.append(''.join(cur))
            cur = []
            continue
        cur.append(ch)
    parts.append(''.join(cur))
    return parts


def parse_server_timing(raw):
    """Server-Timing header -> [{'name', 'desc', 'dur'}]. Repeated headers arrive joined by newlines."""
    out = []
    for part in _split_unquoted(str(raw or '').replace('\n', ','), ','):
        fields = _split_unquoted(part, ';')
        name = fields[0].strip()
        if not name:
            continue
        desc, dur = '', None
        for field in fields[1:]:
            key, _, value = field.partition('=')
            key, value = key.strip().lower(), value.strip()
            if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
                value = value[1:-1].replace('\\"', '"').replace('\\\\', '\\')
            if key == 'desc':
                desc = value[:200]
            elif key == 'dur':
                try:
                    dur = round(float(value), 1)
                except ValueError:
                    pass
        out.append(dict(name=name[:80], desc=desc or name[:80], dur=dur))
        if len(out) >= MAX_SERVER_TIMING_ENTRIES:
            break
    return out


def short_url(url):
    path = urlsplit(url).path.rstrip('/')
    return path.rsplit('/', 1)[-1] or url


def median_or_none(values):
    return round(statistics.median(values)) if values else None


def percentile(values, pct):
    """Nearest-rank percentile; None for an empty list."""
    if not values:
        return None
    ordered = sorted(values)
    return round(ordered[max(0, math.ceil(pct / 100.0 * len(ordered)) - 1)])


def rating(total_ms, slow_ms):
    if total_ms is None:
        return 'Not measured'
    if total_ms < FAST_MS:
        return 'Fast'
    return 'Acceptable' if total_ms < slow_ms else 'Slow'


def find_edge():
    paths = [
        shutil.which('msedge'),
        os.path.join(os.environ.get('PROGRAMFILES(X86)', ''), 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
        os.path.join(os.environ.get('PROGRAMFILES', ''), 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    ]
    for path in paths:
        if path and os.path.isfile(path):
            return path
    raise RuntimeError('Microsoft Edge (msedge.exe) was not found on this computer.')


def wait_for_debugging_port(profile, process, seconds=25):
    port_file = Path(profile) / 'DevToolsActivePort'
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if port_file.exists():
            lines = port_file.read_text(encoding='utf-8', errors='replace').splitlines()
            if lines and lines[0].isdigit():
                return int(lines[0])
        if process.poll() is not None:
            raise RuntimeError('Edge exited before it opened the debugging endpoint.')
        time.sleep(0.2)
    raise RuntimeError('Edge did not enable local debugging. IT browser policy may block it.')


class WSClient:
    """Minimal RFC 6455 WebSocket client for localhost CDP, stdlib only."""

    def __init__(self, ws_url):
        parsed = urlsplit(ws_url)
        if parsed.scheme != 'ws' or parsed.hostname not in ('localhost', '127.0.0.1', '::1'):
            raise RuntimeError('Refusing to connect to a non-local debugging WebSocket.')
        host = parsed.hostname
        port = parsed.port or 80
        path = parsed.path + ('?' + parsed.query if parsed.query else '')
        self.sock = socket.create_connection((host, port), timeout=10)
        self.sock.settimeout(10)
        key = base64.b64encode(os.urandom(16)).decode('ascii')
        request = (
            'GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\n'
            'Connection: Upgrade\r\nSec-WebSocket-Version: 13\r\n'
            'Sec-WebSocket-Key: %s\r\n\r\n'
        ) % (path, host, port, key)
        self.sock.sendall(request.encode('ascii'))
        response = bytearray()
        while b'\r\n\r\n' not in response:
            block = self.sock.recv(4096)
            if not block:
                raise ConnectionError('Browser closed during WebSocket handshake.')
            response.extend(block)
            if len(response) > 65536:
                raise RuntimeError('Oversized WebSocket handshake.')
        hdrs, leftovers = bytes(response).split(b'\r\n\r\n', 1)
        expected = base64.b64encode(hashlib.sha1((key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode('ascii')).digest()).decode('ascii')
        if not hdrs.startswith(b'HTTP/1.1 101') or ('sec-websocket-accept: ' + expected).lower().encode() not in hdrs.lower():
            raise RuntimeError('CDP WebSocket handshake was rejected: %r' % hdrs[:250])
        self.buffer = bytearray(leftovers)
        self.sock.settimeout(15)

    def _exact(self, n):
        while len(self.buffer) < n:
            chunk = self.sock.recv(max(4096, n - len(self.buffer)))
            if not chunk:
                raise ConnectionError('Edge browser connection closed.')
            self.buffer.extend(chunk)
        out = bytes(self.buffer[:n])
        del self.buffer[:n]
        return out

    def send_frame(self, opcode, payload):
        # Browser clients MUST mask WebSocket frames.
        mask = os.urandom(4)
        n = len(payload)
        if n < 126:
            length_part = bytes((0x80 | n,))
        elif n < 65536:
            length_part = bytes((0x80 | 126,)) + struct.pack('!H', n)
        else:
            length_part = bytes((0x80 | 127,)) + struct.pack('!Q', n)
        payload = bytes(byte ^ mask[i % 4] for i, byte in enumerate(payload))
        self.sock.sendall(bytes((0x80 | opcode,)) + length_part + mask + payload)

    def send_json(self, obj):
        self.send_frame(1, json.dumps(obj, separators=(',', ':')).encode('utf-8'))

    def recv_json(self, wait_seconds=0.2):
        if not self.buffer:
            readable, _, _ = select.select([self.sock], [], [], wait_seconds)
            if not readable:
                return None
        message = bytearray()
        started = False
        while True:
            b1, b2 = self._exact(2)
            opcode, fin = b1 & 0x0f, bool(b1 & 0x80)
            size = b2 & 0x7f
            if size == 126:
                size = struct.unpack('!H', self._exact(2))[0]
            elif size == 127:
                size = struct.unpack('!Q', self._exact(8))[0]
            if size > MAX_WS_FRAME_BYTES:
                raise RuntimeError('WebSocket message exceeds safety limit.')
            mask = self._exact(4) if b2 & 0x80 else None
            payload = self._exact(size)
            if mask:
                payload = bytes(byte ^ mask[i % 4] for i, byte in enumerate(payload))
            if opcode == 8:
                raise ConnectionError('Edge closed the debugging WebSocket.')
            if opcode == 9:
                self.send_frame(10, payload)
                continue
            if opcode == 10:
                continue
            if opcode in (1, 2):
                started = True
            elif opcode != 0 or not started:
                continue
            message.extend(payload)
            if len(message) > MAX_WS_FRAME_BYTES:
                raise RuntimeError('WebSocket message exceeds safety limit.')
            if fin:
                return json.loads(message.decode('utf-8'))

    def close(self):
        try:
            self.send_frame(8, b'')
        except (OSError, ConnectionError):
            pass
        self.sock.close()


class Report:
    """Session state: application name/URL, step numbering, results and errors."""

    def __init__(self, url, name, slow_ms):
        self.name = name
        self.app_url = clean_url(url)
        self.slow_ms = slow_ms
        self.seq = 0
        self.completed = []          # list of (result dict, request list)
        self.errors = []             # JavaScript exceptions / console errors
        self.browser_version = ''
        self.started = dt.datetime.now()

    def next_id(self):
        self.seq += 1
        return self.seq

    def rel_path(self, url):
        """Page path relative to the application's base folder. Pages on another
        site (for example a single sign-on server) keep their host name."""
        if not url:
            return '(start)'
        parts = urlsplit(url)
        path = parts.path or '/'
        base = urlsplit(self.app_url)
        if not base.netloc or parts.netloc.lower() != base.netloc.lower():
            return parts.netloc.lower() + path
        base_dir = base.path.rsplit('/', 1)[0] + '/'
        if base_dir != '/' and path.lower().startswith(base_dir.lower()):
            path = '/' + path[len(base_dir):]
        return path + ('#' + parts.fragment if parts.fragment else '')


class Tab:
    """One recorded Edge tab: its DevTools session and its in-flight step."""

    def __init__(self, browser, session_id, target_id, number, opener=None, opener_step=None):
        self.browser = browser
        self.report = browser.report
        self.session_id = session_id
        self.target_id = target_id
        self.number = number
        self.name = 'Tab %d' % number
        self.opener = opener              # tab that opened this one (popup / new tab), if any
        self.opener_step = opener_step    # the opener's step that led here
        self.navigated = False
        self.title_waits = {}        # Runtime.evaluate id -> result dict awaiting the page title
        self.active = None
        self.last_result = None
        self.reqs = {}
        self.main_frame = None
        self.cdp_offset_ms = None
        self.current_url = ''
        self.current_title = ''

    def cmd(self, name, params=None):
        return self.browser.send(name, params, tab=self)

    def start(self, resume=False):
        self.cmd('Runtime.enable')
        self.cmd('Page.enable')
        self.cmd('Network.enable', {'maxTotalBufferSize': 10000000})
        self.cmd('Runtime.addBinding', {'name': '__edgeJourneyNotify'})
        self.cmd('Page.addScriptToEvaluateOnNewDocument', {'source': INJECT_JS})
        self.cmd('Runtime.evaluate', {'expression': INJECT_JS})
        self.cmd('Page.getFrameTree')
        if resume:
            # New tabs wait for the debugger: release this one only after instrumentation is in place.
            self.cmd('Runtime.runIfWaitingForDebugger')

    def new_action(self, kind, label, from_url, start_ms):
        if self.active:
            self.finish_action('INTERRUPTED_BY_NEXT_STEP')
        from_url = clean_url(from_url) if from_url else ''
        action = dict(id=self.report.next_id(), kind=kind, label=label[:110], from_url=from_url,
                      from_rel=self.report.rel_path(from_url), started_ms=start_ms, requests=[],
                      pending=set(), last_activity_ms=start_ms, last_end_ms=None, dom_ms=None,
                      load_ms=None, js_errors=0, nav_dest='', opened_by=None)
        self.active = action
        print('[%03d] T%-2d %-12s %-38s %s' % (action['id'], self.number, kind, action['label'][:38],
                                              action['from_rel'][:60]), flush=True)
        return action

    def new_navigation(self, kind, dest_url, start_ms, nav_type='navigate'):
        dest = clean_url(dest_url)
        rel = self.report.rel_path(dest)
        label = ('Go to ' if kind == KIND_ROUTE else NAV_LABELS.get(nav_type, 'Open page') + ' ') + rel
        from_url, opened_by = self.current_url, None
        if self.opener is not None and not self.navigated:
            # First page of a popup / new tab: the user came from the opener's page.
            label = 'New tab: ' + label
            from_url, opened_by = self.opener.current_url, self.opener_step
        self.navigated = True
        action = self.new_action(kind, label, from_url, start_ms)
        action['nav_dest'] = dest
        action['opened_by'] = opened_by
        return action

    def on_response(self, method, message):
        # Runtime.evaluate fails harmlessly when its page or context has already gone.
        if 'error' in message and method != 'Runtime.evaluate':
            print('DevTools error for %s (%s): %s' % (method, self.name, message['error']), file=sys.stderr)
            # A popup that closes at once fails its setup commands; only the first tab is fatal.
            if method in REQUIRED_FEATURES and self.number == 1:
                raise RuntimeError('Required Edge DevTools feature not available: ' + method)
        if method == 'Page.getFrameTree':
            frame = message.get('result', {}).get('frameTree', {}).get('frame', {})
            self.main_frame = frame.get('id')
            self.set_current_url(frame.get('url', '') + frame.get('urlFragment', ''))
        waiting = self.title_waits.pop(message['id'], None)
        if waiting is not None:
            value = message.get('result', {}).get('result', {}).get('value')
            if isinstance(value, str) and value.strip():
                waiting['title'] = value.strip()[:150]
                self.current_title = waiting['title']

    def on_event(self, message):
        method = message.get('method')
        p = message.get('params', {})
        if method == 'Page.frameNavigated':
            frame = p.get('frame', {})
            if not frame.get('parentId'):
                self.main_frame = frame.get('id', self.main_frame)
                self.set_current_url(frame.get('url', '') + frame.get('urlFragment', ''))
        elif method == 'Page.navigatedWithinDocument':
            if not self.main_frame or p.get('frameId') == self.main_frame:
                dest = clean_url(p.get('url', ''))
                # A route change with no click behind it (history.back, timers, redirects).
                if not self.active and dest.startswith(('http://', 'https://')) and dest != self.current_url:
                    self.new_navigation(KIND_ROUTE, dest, time.time() * 1000)
                self.set_current_url(dest)
        elif method == 'Runtime.executionContextCreated':
            ctx = p.get('context') or {}
            aux = ctx.get('auxData') or {}
            if aux.get('isDefault') and (not self.main_frame or aux.get('frameId') == self.main_frame):
                # Safety net: a popup's first real document can miss addScriptToEvaluateOnNewDocument.
                # The script's document flag makes a second install a no-op.
                self.cmd('Runtime.evaluate', {'expression': INJECT_JS, 'contextId': ctx.get('id')})
        elif method == 'Runtime.bindingCalled':
            if p.get('name') == '__edgeJourneyNotify':
                try:
                    self.on_page_event(json.loads(p['payload']))
                except (ValueError, KeyError, TypeError) as ex:
                    print('Could not parse a page event: %s' % ex, file=sys.stderr)
        elif method == 'Runtime.exceptionThrown':
            details = p.get('exceptionDetails') or {}
            text = (details.get('exception') or {}).get('description') or details.get('text') or 'Exception'
            self.js_error('JavaScript exception', text)
        elif method == 'Runtime.consoleAPICalled':
            if p.get('type') == 'error':
                args = p.get('args') or []
                text = ' '.join(str(a.get('value', a.get('description', ''))) for a in args[:3])
                self.js_error('Console error', text or 'console.error')
        elif method == 'Network.requestWillBeSent':
            self.request_start(p)
        elif method == 'Network.responseReceived':
            req = self.reqs.get(p.get('requestId'))
            if req:
                self.apply_response(req, p.get('response') or {})
        elif method == 'Network.requestServedFromCache':
            req = self.reqs.get(p.get('requestId'))
            if req:
                req['cached'] = True
        elif method in ('Network.loadingFinished', 'Network.loadingFailed'):
            self.request_done(p, failed=(method == 'Network.loadingFailed'))
        elif method in ('Page.domContentEventFired', 'Page.loadEventFired'):
            a = self.active
            if a and self.cdp_offset_ms is not None and 'timestamp' in p:
                event_ms = float(p['timestamp']) * 1000 + self.cdp_offset_ms
                delta = round(event_ms - a['started_ms'])
                if delta >= 0:
                    a['dom_ms' if method == 'Page.domContentEventFired' else 'load_ms'] = delta

    def set_current_url(self, raw):
        url = clean_url(raw)
        self.current_url = url if url.startswith(('http://', 'https://')) else ''

    def on_page_event(self, body):
        kind = body.get('type')
        url = body.get('url') or ''
        now = float(body.get('timeMs', time.time() * 1000))
        label = str(body.get('label') or '').strip()
        if body.get('title'):
            self.current_title = str(body['title']).strip()[:150]
        a = self.active
        merge = a is not None and a['kind'] == KIND_CLICK and now - a['started_ms'] < MERGE_MS
        if kind == 'click':
            self.new_action(KIND_CLICK, label or 'Unnamed control', url, now)
        elif kind == 'submit':
            if merge:
                a['kind'] = KIND_SUBMIT      # submit button click: one step, not two
            else:
                self.new_action(KIND_SUBMIT, 'Submit ' + (label or 'form'), url, now)
        elif kind == 'change':
            if not merge:                    # checkbox/radio clicks are already recorded
                self.new_action(KIND_SELECT, 'Change ' + (label or 'field'), url, now)
        elif kind == 'page':
            nav_type = body.get('navType') or 'navigate'
            if body.get('persisted') and not a:
                # Restored from the back/forward cache: no network request, but still a step.
                self.new_navigation(KIND_NAV, url, now, nav_type)
            elif a and a['kind'] == KIND_NAV and nav_type in NAV_LABELS:
                prefix = 'New tab: ' if a['opened_by'] is not None else ''
                a['label'] = prefix + NAV_LABELS[nav_type] + ' ' + self.report.rel_path(a['nav_dest'])

    def js_error(self, source, text):
        text = str(text).strip().splitlines()[0][:300] if str(text).strip() else source
        owner = self.active or self.last_result
        action_id = owner['id'] if self.active else (owner['action_id'] if owner else None)
        if owner is not None:
            owner['js_errors'] += 1
        self.report.errors.append(dict(action_id=action_id, page=self.report.rel_path(self.current_url),
                                       source=source, message=text))

    @staticmethod
    def apply_response(req, response):
        status = response.get('status')
        req['status'] = int(status) if isinstance(status, (int, float)) else None
        req['mime'] = str(response.get('mimeType') or '')[:60]
        if response.get('fromDiskCache') or response.get('fromPrefetchCache') or response.get('fromServiceWorker'):
            req['cached'] = True
        timings = response.get('timing') or {}
        if 'receiveHeadersEnd' in timings and 'sendEnd' in timings:
            req['ttfb_ms'] = max(0, round(timings['receiveHeadersEnd'] - timings['sendEnd'], 1))
        for key, value in (response.get('headers') or {}).items():
            if str(key).lower() == 'server-timing':
                req['server_timing'] = parse_server_timing(value)

    def request_start(self, p):
        rid = p.get('requestId')
        if not rid:
            return
        ts = float(p.get('timestamp', 0))
        wall = float(p.get('wallTime', time.time())) * 1000
        if ts:
            self.cdp_offset_ms = wall - ts * 1000
        # A redirect re-uses the requestId: close the previous hop first.
        if p.get('redirectResponse') and rid in self.reqs:
            self.apply_response(self.reqs[rid], p['redirectResponse'])
            self.request_done({'requestId': rid, 'timestamp': ts})
        request = p.get('request') or {}
        url = clean_url(request.get('url', ''))
        kind = p.get('type', '')
        if not url.startswith(('http://', 'https://')) or kind in UNTRACKED_TYPES:
            return
        main = not self.main_frame or p.get('frameId') == self.main_frame
        if kind == 'Document' and main and not self.active:
            self.new_navigation(KIND_NAV, url, wall)
        action = self.active
        if not action or wall < action['started_ms'] - 150:
            return
        # The new request belongs to the active step.
        req = dict(id=rid, action=action, method=request.get('method', ''), url=url, type=kind,
                   main_document=(kind == 'Document' and main), started_ts=ts, started_ms=wall,
                   status=None, mime='', cached=False, duration_ms=None, ttfb_ms=None,
                   bytes_received=0, error='', server_timing=[])
        self.reqs[rid] = req
        action['requests'].append(req)
        action['pending'].add(rid)
        action['last_activity_ms'] = max(action['last_activity_ms'], wall)

    def request_done(self, p, failed=False):
        rid = p.get('requestId')
        req = self.reqs.pop(rid, None)
        if not req:
            return
        end_ts = float(p.get('timestamp', req['started_ts']))
        elapsed = max(0, (end_ts - req['started_ts']) * 1000)
        req['duration_ms'] = round(elapsed, 1)
        req['bytes_received'] = p.get('encodedDataLength', 0) if not failed else 0
        if failed:
            req['error'] = p.get('errorText') or 'Network failed'
        action = req['action']
        action['pending'].discard(rid)
        end_wall = req['started_ms'] + elapsed
        action['last_end_ms'] = max(action['last_end_ms'] or 0, end_wall)
        action['last_activity_ms'] = max(action['last_activity_ms'], end_wall)

    def tick(self):
        action = self.active
        if not action:
            return
        now = time.time() * 1000
        if now - action['started_ms'] > MAX_ACTION_MS:
            self.finish_action('TIMEOUT')
        elif action['pending']:
            return
        elif action['requests'] and now - action['last_activity_ms'] >= QUIET_MS:
            self.finish_action('NETWORK_QUIET')
        elif not action['requests'] and now - action['started_ms'] >= NO_REQUEST_WAIT_MS:
            self.finish_action('NO_NETWORK_OBSERVED')

    def finish_action(self, reason, ask_title=True):
        action = self.active
        if not action:
            return
        self.active = None
        # The duration here is from the step to the LAST network completion, not
        # the 1.2-second confirmation window used before declaring network quiet.
        total_ms = None
        # A popup that closes itself after its work (save-and-close) still has a valid time.
        closed_clean = reason == 'TAB_CLOSED' and action['requests'] and not action['pending']
        if (reason == 'NETWORK_QUIET' or closed_clean) and action['last_end_ms'] is not None:
            total_ms = round(max(0, action['last_end_ms'] - action['started_ms']))
        requests = action['requests']
        ended = [r for r in requests if r['duration_ms'] is not None]
        slow = max(ended, key=lambda r: r['duration_ms']) if ended else None
        docs = [r for r in requests if r['main_document']]
        doc = docs[-1] if docs else None
        wait_from = doc if doc and doc['ttfb_ms'] is not None else slow
        to_url = self.current_url or action['nav_dest'] or action['from_url']
        result = {
            'action_id': action['id'], 'tab': self.name, 'opened_by': action['opened_by'],
            'started': dt.datetime.fromtimestamp(action['started_ms'] / 1000),
            'kind': action['kind'], 'action': action['label'],
            'from_page': action['from_rel'], 'to_page': self.report.rel_path(to_url), 'to_url': to_url,
            'title': self.current_title, 'outcome': reason, 'total_ms': total_ms,
            'rating': rating(total_ms, self.report.slow_ms),
            'server_wait_ms': round(wait_from['ttfb_ms']) if wait_from and wait_from['ttfb_ms'] is not None else None,
            'dom_ms': action['dom_ms'], 'load_ms': action['load_ms'],
            'doc_status': doc['status'] if doc else None,
            'request_count': len(requests),
            'failed_requests': sum(1 for r in requests if r['error'] or
                                   (isinstance(r['status'], int) and r['status'] >= 400)),
            'cached': sum(1 for r in requests if r['cached']),
            'js_errors': action['js_errors'],
            'slowest_ms': round(slow['duration_ms']) if slow else None,
            'slowest_url': slow['url'] if slow else '',
            'kb': round(sum(float(r['bytes_received'] or 0) for r in ended) / 1024, 1),
        }
        self.report.completed.append((result, requests))
        self.last_result = result
        if ask_title:
            # The title often changes after the response arrives; read it once more.
            try:
                rid = self.cmd('Runtime.evaluate', {'expression': 'document.title', 'returnByValue': True})
                self.title_waits[rid] = result
            except (OSError, ConnectionError):
                pass
        shown = '%d ms' % total_ms if total_ms is not None else 'not measured'
        moved = '  -> ' + result['to_page'] if result['to_page'] != action['from_rel'] else ''
        print('      %-22s %-13s requests: %-4d%s' % (reason, shown, len(requests), moved[:70]), flush=True)


class Browser:
    """Edge process watched through ONE browser-level DevTools connection. Every tab -
    the first one, popups and pages opened in a new tab - gets its own session on it."""

    def __init__(self, port, report, start_url='', timing_key=''):
        self.port = port
        self.report = report
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.ws = None
        self.cmd_seq = 0
        self.commands = {}           # command id -> (Tab or None, method)
        self.tabs = {}               # sessionId -> open Tab
        self.by_target = {}          # targetId -> open Tab
        self.tab_count = 0
        self.first_tab = None
        self.start_url = start_url
        self.timing_key = timing_key
        self.cookie_pending = False
        self.navigated = False

    def _get(self, path, method='GET'):
        # The endpoint is LOCAL to the user's machine. Some enterprise/Anaconda
        # environments configure HTTP_PROXY/HTTPS_PROXY or a Windows proxy which
        # routes ordinary urllib calls through a corporate gateway. That gateway
        # can return "HTTP Error 403: Forbidden" for 127.0.0.1 even though
        # Edge launched correctly. Bypass proxies ONLY for this loopback call.
        req = urllib.request.Request('http://127.0.0.1:%d%s' % (self.port, path), method=method)
        try:
            with self.opener.open(req, timeout=5) as res:
                return json.load(res)
        except urllib.error.HTTPError as ex:
            raise RuntimeError(
                'Edge LOCAL debugging endpoint returned HTTP %s. '
                'Check whether corporate Edge policy blocks remote debugging. '
                'This error is not from the application URL.' % ex.code
            ) from ex

    def pages(self):
        return [t for t in self._get('/json/list')
                if t.get('type') == 'page' and t.get('webSocketDebuggerUrl')
                and not str(t.get('url', '')).startswith('devtools://')]

    def connect(self):
        info = self._get('/json/version')
        self.report.browser_version = info.get('Browser', '')
        if not info.get('webSocketDebuggerUrl'):
            raise RuntimeError('Edge did not report a browser-level debugging endpoint.')
        self.ws = WSClient(info['webSocketDebuggerUrl'])
        if self.timing_key:
            # Host-only cookie for the application: asks its server to send Server-Timing.
            parts = urlsplit(self.start_url)
            self.cookie_pending = True
            self.send('Storage.setCookies', {'cookies': [{
                'name': TIMING_COOKIE, 'value': self.timing_key, 'path': '/', 'httpOnly': True,
                'url': '%s://%s/' % (parts.scheme, parts.netloc), 'secure': parts.scheme == 'https'}]})
        # Attach to existing pages now and to every new tab/popup as it opens. New targets
        # stay paused until instrumented, so a popup's first page load is timed as well.
        self.send('Target.setAutoAttach', {'autoAttach': True, 'waitForDebuggerOnStart': True, 'flatten': True})

    def send(self, method, params=None, tab=None, session_id=None):
        self.cmd_seq += 1
        message = {'id': self.cmd_seq, 'method': method, 'params': params or {}}
        session_id = tab.session_id if tab is not None else session_id
        if session_id:
            message['sessionId'] = session_id
        self.commands[self.cmd_seq] = (tab, method)
        self.ws.send_json(message)
        return self.cmd_seq

    def wait_for_first_tab(self, seconds=10):
        deadline = time.monotonic() + seconds
        fallback_sent = False
        while not self.tabs:
            if time.monotonic() > deadline:
                raise RuntimeError('No debuggable Edge tab found.')
            if not fallback_sent and time.monotonic() > deadline - seconds / 2:
                # Auto-attach normally covers existing pages; attach explicitly if it did not.
                fallback_sent = True
                for target in self.pages():
                    self.send('Target.attachToTarget', {'targetId': target['id'], 'flatten': True})
            if not self.pump() and not self.ws:
                raise RuntimeError('Lost the Edge debugging connection.')

    def dispatch(self, message):
        if 'id' in message:
            tab, method = self.commands.pop(message['id'], (None, 'unknown'))
            if tab is not None:
                tab.on_response(method, message)
            else:
                self.on_browser_response(method, message)
            return
        session_id = message.get('sessionId')
        if session_id:
            tab = self.tabs.get(session_id)
            if tab is not None:
                tab.on_event(message)
            return
        method = message.get('method')
        if method == 'Target.attachedToTarget':
            self.on_attached(message.get('params') or {})
        elif method == 'Target.detachedFromTarget':
            self.on_detached((message.get('params') or {}).get('sessionId'))

    def on_browser_response(self, method, message):
        if 'error' in message:
            if method == 'Target.setAutoAttach':
                raise RuntimeError('Edge refused to attach to its tabs: %s' % message['error'])
            if method == 'Storage.setCookies':
                print('WARNING: could not set the %s cookie (%s); server method timings will be missing.'
                      % (TIMING_COOKIE, message['error']), file=sys.stderr)
            # Errors from resuming/detaching a target that already went away are harmless.
        if method == 'Storage.setCookies':
            self.cookie_pending = False
            self.maybe_navigate()

    def maybe_navigate(self):
        """Open the start URL once the first tab is instrumented and the timing cookie is set."""
        tab = self.first_tab
        if self.start_url and not self.navigated and not self.cookie_pending \
                and tab is not None and tab.session_id in self.tabs:
            self.navigated = True
            tab.cmd('Page.navigate', {'url': self.start_url})

    def on_attached(self, p):
        session_id = p.get('sessionId')
        info = p.get('targetInfo') or {}
        target_id = info.get('targetId')
        if not session_id:
            return
        waiting = bool(p.get('waitingForDebugger'))
        if info.get('type') != 'page' or target_id in self.by_target \
                or str(info.get('url', '')).startswith('devtools://'):
            # Workers, DevTools windows, duplicate sessions: let them run, do not record them.
            if waiting:
                self.send('Runtime.runIfWaitingForDebugger', session_id=session_id)
            self.send('Target.detachFromTarget', {'sessionId': session_id})
            return
        opener = self.by_target.get(info.get('openerId'))
        opener_step = None
        if opener is not None:
            if opener.active and not opener.active['requests']:
                # The click only opened the new tab: close that step and link the new tab to it.
                opener_step = opener.active['id']
                opener.finish_action('OPENED_NEW_TAB')
            elif opener.active:
                opener_step = opener.active['id']
            elif opener.last_result:
                opener_step = opener.last_result['action_id']
        self.tab_count += 1
        tab = Tab(self, session_id, target_id, self.tab_count, opener, opener_step)
        self.tabs[session_id] = tab
        self.by_target[target_id] = tab
        tab.start(resume=waiting)
        if self.first_tab is None:
            self.first_tab = tab
            self.maybe_navigate()
        else:
            print('NOTE: %s opened%s - recording it as well.'
                  % (tab.name, ' from ' + opener.name if opener else ''), flush=True)

    def on_detached(self, session_id):
        tab = self.tabs.pop(session_id, None)
        if tab is None:
            return
        self.by_target.pop(tab.target_id, None)
        if tab.active:
            tab.finish_action('TAB_CLOSED', ask_title=False)
        print('NOTE: %s was closed.' % tab.name, flush=True)

    def stop(self, reason):
        for tab in list(self.tabs.values()):
            if tab.active:
                tab.finish_action(reason, ask_title=False)
        self.tabs.clear()

    def tick(self):
        for tab in list(self.tabs.values()):
            tab.tick()

    def pump(self):
        """Read every waiting DevTools message, then tick each tab's timer.
        Returns False once no recorded tab is left."""
        if not self.ws.buffer:
            readable, _, _ = select.select([self.ws.sock], [], [], 0.2)
            if not readable:
                self.tick()
                return bool(self.tabs)
        try:
            for _ in range(500):
                message = self.ws.recv_json(0)
                if message is None:
                    break
                self.dispatch(message)
        except (ConnectionError, OSError, RuntimeError, ValueError) as ex:
            self.stop('TAB_CLOSED')
            self.ws = None
            print('\nThe Edge debugging connection ended (%s).' % ex)
            return False
        self.tick()
        return bool(self.tabs)


# ----------------------------------------------------------------------------
# Excel report
# ----------------------------------------------------------------------------

NAVY = '1F3864'
BLUE = '2F5496'
ZEBRA = 'F2F5FA'
GREY_TEXT = '595959'
GOOD = 'E2EFDA'
WARN = 'FFF2CC'
BAD = 'F8CBAD'
THIN = Side(style='thin', color='BFBFBF') if Workbook else None
RATING_FILLS = {'Fast': GOOD, 'Acceptable': WARN, 'Slow': BAD}


def _fill(color):
    return PatternFill('solid', start_color=color, end_color=color)


def _title(ws, text, subtitle, width_cols):
    ws.sheet_view.showGridLines = False
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=width_cols)
    cell = ws.cell(row=1, column=1, value=text)
    cell.font = Font(size=16, bold=True, color='FFFFFF')
    cell.fill = _fill(NAVY)
    cell.alignment = Alignment(vertical='center', indent=1)
    for c in range(2, width_cols + 1):
        ws.cell(row=1, column=c).fill = _fill(NAVY)
    ws.row_dimensions[1].height = 32
    sub = ws.cell(row=2, column=1, value=subtitle)
    sub.font = Font(italic=True, color=GREY_TEXT)


def _table(ws, row, headers, rows, number_cols=()):
    """Write a styled table starting at `row`. Returns the last row written."""
    for c, head in enumerate(headers, 1):
        cell = ws.cell(row=row, column=c, value=head)
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = _fill(BLUE)
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=THIN, bottom=THIN, left=THIN, right=THIN)
    ws.row_dimensions[row].height = 30
    for i, values in enumerate(rows, 1):
        for c, value in enumerate(values, 1):
            cell = ws.cell(row=row + i, column=c, value=value)
            cell.border = Border(top=THIN, bottom=THIN, left=THIN, right=THIN)
            cell.alignment = Alignment(vertical='top', wrap_text=isinstance(value, str) and len(value) > 40)
            if i % 2 == 0:
                cell.fill = _fill(ZEBRA)
            if c in number_cols and isinstance(value, (int, float)):
                cell.number_format = '#,##0'
            if isinstance(value, dt.datetime):
                cell.number_format = 'yyyy-mm-dd hh:mm:ss'
    return row + len(rows)


def _widths(ws, widths):
    for c, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(c)].width = w


def _section(ws, row, text, cols=5):
    cell = ws.cell(row=row, column=1, value=text)
    cell.font = Font(size=12, bold=True, color=NAVY)
    for c in range(1, cols + 1):
        ws.cell(row=row, column=c).border = Border(bottom=Side(style='medium', color=NAVY))
    return row + 1


def _data_sheet(wb, name, title, subtitle, headers, rows, widths, number_cols=()):
    ws = wb.create_sheet(name)
    _title(ws, title, subtitle, len(headers))
    last = _table(ws, 3, headers, rows, number_cols)
    ws.freeze_panes = 'A4'
    ws.auto_filter.ref = 'A3:%s%d' % (get_column_letter(len(headers)), max(last, 3))
    _widths(ws, widths)
    return ws


def _is_failed(q):
    return bool(q['error']) or (isinstance(q['status'], int) and q['status'] >= 400)


def _server_leaves(timings):
    """Server-Timing entries that are not the parent of another entry in the same
    response - the innermost methods, which is where the time was actually spent."""
    descs = [e['desc'] for e in timings]
    return [e for e in timings if e['name'] != 'total' and e['dur'] is not None
            and not any(d.startswith(e['desc'] + ' > ') for d in descs)]


def slowest_server_method(requests):
    best = None
    for q in requests:
        for e in _server_leaves(q['server_timing']):
            if best is None or e['dur'] > best['dur']:
                best = e
    return '%s (%s ms)' % (best['desc'], '{:,}'.format(round(best['dur']))) if best else ''


def build_pages(report):
    """One row per page: the steps performed on it and how fast it opened."""
    pages = {}

    def entry(rel):
        return pages.setdefault(rel.lower(), dict(page=rel, steps=[], opened=[]))

    for result, _ in report.completed:
        entry(result['from_page'])['steps'].append(result)
        if result['to_page'] != result['from_page'] or result['kind'] in (KIND_NAV, KIND_ROUTE):
            entry(result['to_page'])['opened'].append(result)
    rows = []
    for p in pages.values():
        if p['page'] == '(start)':
            continue
        steps, opened = p['steps'], p['opened']
        timed = [r['total_ms'] for r in steps if r['total_ms'] is not None]
        open_times = [r['total_ms'] for r in opened if r['total_ms'] is not None]
        loads = [r['load_ms'] for r in opened if r['load_ms'] is not None]
        rows.append(dict(page=p['page'], opened=len(opened), median_open=median_or_none(open_times),
                         median_load=median_or_none(loads), steps=len(steps), median=median_or_none(timed),
                         slowest=max(timed) if timed else None,
                         slow=sum(1 for t in timed if t >= report.slow_ms),
                         failed=sum(r['failed_requests'] for r in steps),
                         errors=sum(r['js_errors'] for r in steps)))
    rows.sort(key=lambda r: -(r['slowest'] or 0))
    return rows


def write_excel(report, path):
    # Steps in different tabs can finish out of order; report them in the order performed.
    report.completed.sort(key=lambda c: c[0]['action_id'])
    wb = Workbook()
    name = report.name
    slow_ms = report.slow_ms
    results = [r for r, _ in report.completed]
    all_requests = [q for _, reqs in report.completed for q in reqs]
    timed = [r['total_ms'] for r in results if r['total_ms'] is not None]
    finished = dt.datetime.now()
    subtitle = 'Generated %s   |   Fast < %s ms   |   Slow >= %s ms   |   Times are step to last network response' % (
        finished.strftime('%d %b %Y %H:%M'), '{:,}'.format(FAST_MS), '{:,}'.format(slow_ms))

    # ---- Summary -----------------------------------------------------------
    ws = wb.active
    ws.title = 'Summary'
    _title(ws, '%s - User Journey Performance' % name, subtitle, 5)
    _widths(ws, [44, 30, 16, 16, 60])
    row = _section(ws, 4, 'Test details')
    details = [
        ('Application', name),
        ('Start URL', report.app_url or '(typed in the browser)'),
        ('Browser', report.browser_version or 'Microsoft Edge'),
        ('Recording started', report.started),
        ('Recording ended', finished),
        ('Duration (minutes)', round((finished - report.started).total_seconds() / 60, 1)),
    ]
    for label, value in details:
        ws.cell(row=row, column=1, value=label).font = Font(bold=True)
        cell = ws.cell(row=row, column=2, value=value)
        if isinstance(value, dt.datetime):
            cell.number_format = 'yyyy-mm-dd hh:mm:ss'
        cell.alignment = Alignment(horizontal='left')
        row += 1

    row = _section(ws, row + 1, 'Results at a glance')
    slow_count = sum(1 for t in timed if t >= slow_ms)
    failed = sum(1 for q in all_requests if _is_failed(q))
    pages_seen = {r['to_page'].lower() for r in results} | {r['from_page'].lower() for r in results}
    pages_seen.discard('(start)')
    glance = [
        ('Steps recorded', len(results)),
        ('Tabs / popups recorded', len({r['tab'] for r in results})),
        ('Steps timed', len(timed)),
        ('Pages visited (unique)', len(pages_seen)),
        ('Median step time (ms)', median_or_none(timed)),
        ('90th percentile step time (ms)', percentile(timed, 90)),
        ('Slowest step (ms)', max(timed) if timed else None),
        ('Fast steps (< %s ms)' % '{:,}'.format(FAST_MS), sum(1 for t in timed if t < FAST_MS)),
        ('Slow steps (>= %s ms)' % '{:,}'.format(slow_ms), slow_count),
        ('Network requests', len(all_requests)),
        ('Failed requests (errors / HTTP 4xx-5xx)', failed),
        ('Responses served from cache', sum(1 for q in all_requests if q['cached'])),
        ('JavaScript errors', len(report.errors)),
        ('Data transferred (KB)', round(sum(r['kb'] for r in results), 1)),
        ('Requests with server method timings', sum(1 for q in all_requests if q['server_timing'])),
    ]
    start = row
    row = _table(ws, row, ['Metric', 'Value'], [list(g) for g in glance], (2,))
    for r in range(start + 1, row + 1):
        label = ws.cell(row=r, column=1).value
        value = ws.cell(row=r, column=2).value
        ws.cell(row=r, column=2).alignment = Alignment(horizontal='right')
        if label.startswith(('Slow steps', 'Failed requests', 'JavaScript errors')) and value:
            ws.cell(row=r, column=2).font = Font(bold=True, color='C00000')

    row += 2
    if timed:
        verdict = ('Overall: %d of %d timed steps finished under %s ms. %d slow step(s), %d failed request(s), '
                   '%d JavaScript error(s).' % (len(timed) - slow_count, len(timed), '{:,}'.format(slow_ms),
                                                 slow_count, failed, len(report.errors)))
    else:
        verdict = 'Overall: no step produced a clean network timing, so no response times are available.'
    healthy = timed and not slow_count and not failed and not report.errors
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
    cell = ws.cell(row=row, column=1, value=verdict)
    cell.font = Font(bold=True, size=12, color=NAVY)
    cell.fill = _fill(GOOD if healthy else WARN)
    cell.alignment = Alignment(wrap_text=True, vertical='center', indent=1)
    ws.row_dimensions[row].height = 34

    row = _section(ws, row + 2, 'Slowest steps')
    top = sorted((r for r in results if r['total_ms'] is not None), key=lambda r: -r['total_ms'])[:10]
    if top:
        start = row
        rows = [[r['action_id'], r['action'], r['from_page'], r['total_ms'],
                 '%s (%s ms)' % (short_url(r['slowest_url']), '{:,}'.format(r['slowest_ms']))
                 if r['slowest_url'] else ''] for r in top]
        row = _table(ws, row, ['Step #', 'Action', 'Page', 'Total (ms)', 'Slowest request'], rows, (4,))
        for r in range(start + 1, row + 1):
            total = ws.cell(row=r, column=4)
            if isinstance(total.value, int) and total.value >= slow_ms:
                total.font = Font(bold=True, color='C00000')
    else:
        ws.cell(row=row, column=1, value='No step was timed.')
        row += 1

    row = _section(ws, row + 2, 'Steps by type')
    kinds = [KIND_NAV, KIND_ROUTE, KIND_CLICK, KIND_SUBMIT, KIND_SELECT]
    rows = []
    for kind in kinds:
        rs = [r for r in results if r['kind'] == kind]
        if not rs:
            continue
        kt = [r['total_ms'] for r in rs if r['total_ms'] is not None]
        rows.append([kind, len(rs), median_or_none(kt), max(kt) if kt else None,
                     sum(1 for t in kt if t >= slow_ms)])
    if rows:
        row = _table(ws, row, ['Step type', 'Steps', 'Median (ms)', 'Slowest (ms)', 'Slow steps'], rows,
                     (2, 3, 4, 5))
    else:
        ws.cell(row=row, column=1, value='No steps were recorded.')
        row += 1

    row = _section(ws, row + 2, 'How to read this report')
    notes = [
        'Times are measured in the browser: from the click / navigation until the last network response finished.',
        'Server wait = time until the server sent the first byte (the page itself for navigations, otherwise the '
        'slowest request).',
        '"Not measured" means the step caused no network traffic (instant UI change) or did not finish cleanly '
        '- see Outcome on the Journey sheet.',
        'Typed text, field values, query strings and URL fragments are never recorded. See the Journey, Pages, '
        'Requests and Issues sheets for detail.',
        'Popups and new tabs are recorded as Tab 2, Tab 3, ...; "Opened from step #" links a new tab\'s first '
        'page to the step that opened it.',
        'Server methods / Method summary come from the application\'s Server-Timing header and are server-side '
        'durations; they stay empty unless the server module is installed and --timing-key matches.',
    ]
    for note in notes:
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
        cell = ws.cell(row=row, column=1, value='-  ' + note)
        cell.alignment = Alignment(wrap_text=True, vertical='top')
        ws.row_dimensions[row].height = 30
        row += 1

    # ---- Journey -----------------------------------------------------------
    headers = ['#', 'Tab', 'Time', 'Step type', 'Action', 'From page', 'To page', 'Page title', 'Outcome',
               'Total (ms)', 'Rating', 'Server wait (ms)', 'DOM ready (ms)', 'Page load (ms)', 'Page status',
               'Requests', 'Failed', 'From cache', 'JS errors', 'Slowest request (ms)', 'Slowest request',
               'Data (KB)', 'Opened from step #', 'Slowest server method']
    rows = [[r['action_id'], r['tab'], r['started'], r['kind'], r['action'], r['from_page'], r['to_page'],
             r['title'], r['outcome'], r['total_ms'], r['rating'], r['server_wait_ms'], r['dom_ms'], r['load_ms'],
             r['doc_status'], r['request_count'], r['failed_requests'], r['cached'], r['js_errors'],
             r['slowest_ms'], short_url(r['slowest_url']) if r['slowest_url'] else '', r['kb'],
             r['opened_by'], slowest_server_method(reqs)]
            for r, reqs in report.completed]
    ws = _data_sheet(wb, 'Journey', 'Every recorded step',
                     'One row per user step, in the order performed. From/To page shows where the user moved.',
                     headers, rows,
                     [6, 8, 19, 13, 32, 28, 28, 28, 22, 11, 12, 12, 11, 11, 9, 10, 8, 9, 8, 12, 26, 10, 11, 48],
                     (10, 12, 13, 14, 20))
    for r in range(4, 4 + len(rows)):
        total = ws.cell(row=r, column=10)
        if isinstance(total.value, int) and total.value >= slow_ms:
            total.font = Font(bold=True, color='C00000')
        grade = ws.cell(row=r, column=11)
        if grade.value in RATING_FILLS:
            grade.fill = _fill(RATING_FILLS[grade.value])
            if grade.value == 'Slow':
                grade.font = Font(bold=True, color='9C0006')
        else:
            grade.font = Font(italic=True, color=GREY_TEXT)
        status = ws.cell(row=r, column=15)
        if isinstance(status.value, int) and status.value >= 400:
            status.font = Font(bold=True, color='C00000')
        for c in (17, 19):
            if ws.cell(row=r, column=c).value:
                ws.cell(row=r, column=c).font = Font(bold=True, color='C00000')
        if ws.cell(row=r, column=7).value != ws.cell(row=r, column=6).value:
            ws.cell(row=r, column=7).font = Font(bold=True, color=BLUE)

    # ---- Pages -------------------------------------------------------------
    headers = ['Page', 'Times opened', 'Median time to open (ms)', 'Median page load (ms)', 'Steps on page',
               'Median step (ms)', 'Slowest step (ms)', 'Slow steps', 'Failed requests', 'JS errors']
    rows = [[p['page'], p['opened'], p['median_open'], p['median_load'], p['steps'], p['median'], p['slowest'],
             p['slow'], p['failed'], p['errors']] for p in build_pages(report)]
    ws = _data_sheet(wb, 'Pages', 'Performance by page',
                     'Times opened = navigations / route changes that landed on the page. '
                     'Steps on page = actions performed while on it.',
                     headers, rows, [40, 12, 16, 16, 12, 14, 14, 10, 12, 10], (3, 4, 6, 7))
    for r in range(4, 4 + len(rows)):
        slowest = ws.cell(row=r, column=7)
        if isinstance(slowest.value, int) and slowest.value >= slow_ms:
            slowest.font = Font(bold=True, color='C00000')
        for c in (8, 9, 10):
            if ws.cell(row=r, column=c).value:
                ws.cell(row=r, column=c).font = Font(bold=True, color='C00000')

    # ---- Requests ----------------------------------------------------------
    headers = ['Step #', 'Tab', 'Action', 'Method', 'Type', 'URL (no query)', 'Status', 'Content type',
               'From cache', 'Total (ms)', 'Server wait (ms)', 'KB', 'Error']
    rows = []
    for result, requests in report.completed:
        for q in requests:
            rows.append([result['action_id'], result['tab'], result['action'], q['method'], q['type'], q['url'],
                         q['status'], q['mime'], 'Yes' if q['cached'] else '', q['duration_ms'], q['ttfb_ms'],
                         round(float(q['bytes_received'] or 0) / 1024, 1), q['error']])
    ws = _data_sheet(wb, 'Requests', 'Network request detail',
                     'Server wait = time until the server sent the first byte of the response.',
                     headers, rows, [8, 8, 28, 9, 12, 60, 8, 22, 10, 11, 14, 9, 26], (10, 11))
    for r in range(4, 4 + len(rows)):
        status = ws.cell(row=r, column=7).value
        if (isinstance(status, int) and status >= 400) or ws.cell(row=r, column=13).value:
            for c in (7, 13):
                ws.cell(row=r, column=c).font = Font(bold=True, color='C00000')

    # ---- Server methods ----------------------------------------------------
    headers = ['Step #', 'Tab', 'Action', 'Request', 'Server method / phase', 'Duration (ms)']
    rows = []
    by_method = {}
    for result, requests in report.completed:
        for q in requests:
            for e in q['server_timing']:
                rows.append([result['action_id'], result['tab'], result['action'],
                             '%s %s' % (q['method'], report.rel_path(q['url'])), e['desc'], e['dur']])
                if e['dur'] is not None:
                    by_method.setdefault(e['desc'], []).append((e['dur'], result['action_id']))
    if not rows:
        rows = [['', '', 'No Server-Timing headers were received. Install dotnet/ServerTiming.cs on the '
                         'application and run with --timing-key.', '', '', None]]
    ws = _data_sheet(wb, 'Server methods', 'Server-side methods per request',
                     'From the Server-Timing response header. "A > B" means B ran inside A. '
                     'Durations are measured on the server.',
                     headers, rows, [8, 8, 30, 40, 70, 13], (6,))
    for r in range(4, 4 + len(rows)):
        dur = ws.cell(row=r, column=6)
        if isinstance(dur.value, (int, float)) and dur.value >= slow_ms:
            dur.font = Font(bold=True, color='C00000')

    headers = ['Server method / phase', 'Calls', 'Median (ms)', '90th percentile (ms)', 'Slowest (ms)',
               'Total (ms)', 'Slowest at step #']
    rows = []
    for desc, calls in by_method.items():
        durs = [d for d, _ in calls]
        worst = max(calls, key=lambda c: c[0])
        rows.append([desc, len(calls), median_or_none(durs), percentile(durs, 90), round(worst[0]),
                     round(sum(durs)), worst[1]])
    rows.sort(key=lambda r: -r[5])
    if not rows:
        rows = [['No server method timings were received.', None, None, None, None, None, None]]
    ws = _data_sheet(wb, 'Method summary', 'Server methods - totals across the journey',
                     'Sorted by total time. Parent phases include the time of the methods inside them.',
                     headers, rows, [70, 8, 12, 14, 12, 12, 12], (3, 4, 5, 6))
    for r in range(4, 4 + len(rows)):
        slowest = ws.cell(row=r, column=5)
        if isinstance(slowest.value, int) and slowest.value >= slow_ms:
            slowest.font = Font(bold=True, color='C00000')

    # ---- Issues ------------------------------------------------------------
    issues = []
    for result, requests in report.completed:
        for q in requests:
            if _is_failed(q):
                kind = 'HTTP %s' % q['status'] if isinstance(q['status'], int) and q['status'] >= 400 \
                    else 'Network failure'
                detail = q['url'] + (' - ' + q['error'] if q['error'] else '')
                issues.append([result['action_id'], result['action'], result['from_page'], kind, detail])
    titles = {r['action_id']: (r['action'], r['from_page']) for r in results}
    for e in report.errors:
        action, page = titles.get(e['action_id'], ('', e['page']))
        issues.append([e['action_id'], action, page or e['page'], e['source'], e['message']])
    issues.sort(key=lambda i: i[0] or 0)
    if not issues:
        issues = [['', 'No failed requests or JavaScript errors were observed.', '', '', '']]
    ws = _data_sheet(wb, 'Issues', 'Errors and failures',
                     'Failed / HTTP 4xx-5xx requests and JavaScript errors, linked to the step that caused them.',
                     ['Step #', 'Action', 'Page', 'Issue type', 'Detail'], issues, [8, 32, 30, 20, 90])
    for r in range(4, 4 + len(issues)):
        if ws.cell(row=r, column=4).value:
            ws.cell(row=r, column=4).font = Font(bold=True, color='C00000')

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(path))
    return path


def main():
    parser = argparse.ArgumentParser(description='Record a user journey through one web application in Edge '
                                                 'and write an Excel performance report.')
    parser.add_argument('--url', default='', help='Application URL to open (or type it in the browser)')
    parser.add_argument('--name', default='Application', help='Display name for the application')
    parser.add_argument('--slow-ms', type=int, default=DEFAULT_SLOW_MS,
                        help='Steps at or above this many ms are rated slow (default %d)' % DEFAULT_SLOW_MS)
    parser.add_argument('--out', default='', help='Folder for the Excel report (default: current folder)')
    parser.add_argument('--timing-key', default=os.environ.get('JOURNEY_TIMING_KEY', ''),
                        help='Key matching the server\'s JourneyTimingKey setting; sent as the %s cookie so '
                             'the server returns method timings (default: JOURNEY_TIMING_KEY env var)'
                             % TIMING_COOKIE)
    args = parser.parse_args()
    name = args.name.strip() or 'Application'
    if args.url and not args.url.lower().startswith(('http://', 'https://')):
        print('--url must start with http:// or https://', file=sys.stderr)
        return 2
    if args.timing_key and not args.url:
        print('--timing-key needs --url (the cookie is scoped to the application host).', file=sys.stderr)
        return 2
    if sys.platform != 'win32':
        print('This recorder launches Microsoft Edge on Windows. Running OS: %s' % sys.platform, file=sys.stderr)
        return 2
    if Workbook is None:
        print('openpyxl is required for the Excel report. Install it with:\n    py -3.9 -m pip install openpyxl',
              file=sys.stderr)
        return 2
    process = None
    browser = None
    report = Report(args.url, name, args.slow_ms)
    profile = tempfile.mkdtemp(prefix='edge_journey_profile_')
    output = (Path(args.out) if args.out else Path.cwd()) / (
        'url_journey_report_' + dt.datetime.now().strftime('%Y%m%d_%H%M%S') + '.xlsx')
    print('Opening a separate Edge browser profile for this test.')
    try:
        edge = find_edge()
        process = subprocess.Popen([
            edge, '--remote-debugging-port=0', '--remote-debugging-address=127.0.0.1',
            '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check',
            '--new-window', 'about:blank'
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        port = wait_for_debugging_port(profile, process)
        browser = Browser(port, report, args.url, args.timing_key)
        browser.connect()
        browser.wait_for_first_tab()
        print('Recording %s%s. Popups and new tabs are recorded too.'
              % (name, (' - ' + clean_url(args.url)) if args.url else ''))
        if args.timing_key:
            print('Server method timings requested (%s cookie set for the application host).' % TIMING_COOKIE)
        print('Click, navigate and submit as a normal user. Every step is timed.')
        print('Press Ctrl+C here (or close the Edge window) to stop and save the Excel report.\n')
        last_poll = time.monotonic()
        while browser.pump():
            if time.monotonic() - last_poll >= TAB_POLL_SECONDS:
                last_poll = time.monotonic()
                if process.poll() is not None:
                    print('\nEdge was closed.')
                    break
        else:
            print('\nAll recorded tabs are closed.')
    except KeyboardInterrupt:
        print('\nStopped by user.')
    except (RuntimeError, OSError, ConnectionError, ValueError) as ex:
        print('\nERROR: %s' % ex, file=sys.stderr)
    finally:
        if browser:
            browser.stop('STOPPED_BEFORE_COMPLETION')
            if browser.ws:
                try:
                    browser.ws.close()
                except OSError:
                    pass
        if report.completed:
            try:
                path = write_excel(report, output)
                print('\nSaved %d steps. Excel report:\n  %s' % (len(report.completed), path))
            except OSError as ex:
                print('\nCould not save the Excel report (%s). Is a file with that name open?' % ex,
                      file=sys.stderr)
        else:
            print('\nNo steps were recorded, so no report was written.')
        if process:
            # Terminate only the dedicated Edge process we started, not existing normal Edge sessions.
            try:
                process.terminate()
                process.wait(timeout=8)
            except (OSError, subprocess.TimeoutExpired):
                pass
        try:
            shutil.rmtree(profile)
        except OSError:
            print('Temporary Edge profile could not be deleted; close test Edge and delete: %s' % profile)
    return 0


if __name__ == '__main__':
    sys.exit(main())
