"""
templates_lib.py - ready-made forms a member can start a survey from.

Each entry is a complete, valid survey: title, description and a schema that
schema.normalise accepts. Starting from one creates an ordinary draft - the
builder can change any of it - so a template is a head start, never a lock.
"""

TEMPLATES = [
    {
        'key': 'satisfaction',
        'name': 'Service satisfaction',
        'blurb': 'A rating table across service areas, plus what went well '
                 'and what to improve.',
        'title': 'Service Satisfaction Survey',
        'description': 'Tell us how the service has worked for you over the '
                       'last month. It takes about three minutes.',
        'schema': {'questions': [
            {'type': 'text', 'label': 'Team / Department', 'required': False,
             'width': 'half'},
            {'type': 'dropdown', 'label': 'How often do you use the service?',
             'required': True, 'width': 'half',
             'options': ['Daily', 'Weekly', 'Monthly', 'Rarely']},
            {'type': 'grid', 'required': True,
             'label': 'How satisfied are you with each of the following?',
             'row_header': 'Service area',
             'rows': ['Response time', 'Quality of resolution',
                      'Communication', 'Ease of raising a request'],
             'columns': ['Very poor', 'Poor', 'Neutral', 'Good',
                         'Excellent']},
            {'type': 'paragraph', 'label': 'What went well?',
             'required': False},
            {'type': 'paragraph', 'label': 'What should we improve?',
             'required': False},
        ]},
    },
]

BY_KEY = dict((t['key'], t) for t in TEMPLATES)
