"""
schema.py - the shape of a survey form and of an answer to it.

The builder (static/js/survey_builder.js) posts the whole form as JSON. None
of it is trusted: ``normalise`` rebuilds every question from a whitelist,
clips every string, de-duplicates choices and assigns ids, so what reaches the
database is always a form this module knows how to render, answer and export.
The same goes for answers - ``read_answers`` reads the public form field by
field against the schema, and anything the schema does not ask for is dropped.

Question types
--------------
  section     a heading and a paragraph between questions; never answered
  text        short answer, one line
  paragraph   long answer
  number      a number
  date        a calendar date
  radio       pick ONE of a list            (radio buttons)
  checkbox    pick ANY of a list            (checkboxes)
  dropdown    pick ONE of a list            (select box - for long lists)
  grid        TABLE: one choice per row     (a radio button in every cell)
  grid_multi  TABLE: any choices per row    (a checkbox in every cell)
  table       TABLE: type into every cell   (column headers; the
              PARTICIPANT adds as many rows as they need)

Layout options (modelled on the paper forms people already use - see the VPN
testing feedback form in sample_uploads/):
  width         'full' | 'half' - two half-width short fields share a line
                (Name | Department). text, number, date and dropdown only.
  layout        'stacked' | 'inline' - choices one per line, or side by side
                (Yes  No). radio and checkbox only.
  allow_other   radio / checkbox: adds "Other (please specify)" with a text
                box; stored as "Other: <what they typed>".
  reason_on     radio / checkbox / dropdown: the choices that open a "reason"
                box when picked (Yes / No -> "No" asks why). Stored with
                reason_label (the box's caption) and reason_required.
  row_header    grid / grid_multi: heading over the row-label column.
  column_types  'table' only, one per column: 'text' | 'yesno' | 'number' |
                'choice' - a Y/N column renders as a Yes / No picker, a
                choice column as a dropdown of the builder's own options.
  column_options 'table' only, one list per column: the dropdown options of
                a 'choice' column ([] for every other column). Stored only
                when the table has a choice column.

Answer shapes, keyed by question id in survey_responses.answers_json:
  text / paragraph / number / date / radio / dropdown  -> "value"
  checkbox                                             -> ["a", "b"]
  grid                                                 -> {"row": "col"}
  grid_multi                                           -> {"row": ["col", ...]}
  table                                                -> [{"col": "text"}, ...]
                                                          one dict per row
                                                          the participant
                                                          filled in
  reason box of a choice question  -> "text" under "<qid>__reason"
                                      (reason_key) - beside the answer, so
                                      the answer keeps its shape and counts

Choices, rows and columns are stored and answered by their LABEL, so an export
or a raw row dump reads as English. That is safe because the form is frozen
once it has a response (service.is_locked) - a label can never change under
an answer that used it.
"""

import json
import re
import secrets

TYPES = ('section', 'text', 'paragraph', 'number', 'date',
         'radio', 'checkbox', 'dropdown', 'grid', 'grid_multi', 'table')
CHOICE_TYPES = ('radio', 'checkbox', 'dropdown')
TABLE_TYPES = ('grid', 'grid_multi', 'table')

TYPE_LABELS = {
    'section': 'Section heading',
    'text': 'Short answer',
    'paragraph': 'Paragraph',
    'number': 'Number',
    'date': 'Date',
    'radio': 'Single choice',
    'checkbox': 'Checkboxes',
    'dropdown': 'Dropdown',
    'grid': 'Table - one choice per row',
    'grid_multi': 'Table - checkboxes',
    'table': 'Table - participants add rows',
}

MAX_QUESTIONS = 100
MAX_OPTIONS = 50
MAX_ROWS = 50
MAX_COLUMNS = 12
MAX_LABEL = 500
MAX_HELP = 1000
MAX_CHOICE = 200
MAX_TITLE = 200
MAX_DESCRIPTION = 4000

# Answer caps. A public form is a write endpoint anybody with the link can
# reach, so nothing it stores is unbounded.
MAX_TEXT_ANSWER = 1000
MAX_PARAGRAPH_ANSWER = 8000
MAX_CELL_ANSWER = 500

WIDTHS = ('full', 'half')
HALF_WIDTH_TYPES = ('text', 'number', 'date', 'dropdown')
LAYOUTS = ('stacked', 'inline')
OTHER_TYPES = ('radio', 'checkbox')
COLUMN_TYPES = ('text', 'yesno', 'number', 'choice')
MAX_COLUMN_OPTIONS = 30
OTHER_PREFIX = 'Other: '
OTHER_VALUE = '__other__'
YES_NO = ('Yes', 'No')
REASON_SUFFIX = '__reason'
REASON_DEFAULT_LABEL = 'Please give a reason'

_ID_RE = re.compile(r'^q_[a-z0-9]{6,16}$')
_DATE_RE = re.compile(r'^\d{4}-\d{2}-\d{2}$')


class SchemaError(ValueError):
    """The posted form cannot be saved. The message is shown to the builder."""


def new_question_id(taken=()):
    while True:
        qid = 'q_' + secrets.token_hex(4)
        if qid not in taken:
            return qid


def _clip(value, limit):
    if value is None:
        return ''
    if not isinstance(value, str):
        value = str(value)
    return value.strip()[:limit]


def _line(value, limit):
    """A one-line label: whitespace collapsed, clipped."""
    return ' '.join(_clip(value, limit * 2).split())[:limit]


def _unique_lines(values, limit, cap):
    """De-duplicated (case-insensitively), blank-free, clipped list."""
    out, seen = [], set()
    if not isinstance(values, (list, tuple)):
        return out
    for raw in values:
        text = _line(raw, limit)
        key = text.lower()
        if text and key not in seen:
            seen.add(key)
            out.append(text)
        if len(out) >= cap:
            break
    return out


def _flagged(values, flags):
    """Lower-cased labels of the entries whose parallel flag is set."""
    if not isinstance(values, list) or not isinstance(flags, list):
        return set()
    return set(_line(v, MAX_CHOICE).lower()
               for v, f in zip(values, flags) if f)


def _columns_with_index(values):
    """_unique_lines for table columns, keeping each kept column's POSITION
    in the posted list, so its parallel type / options stay attached even
    when a blank or duplicate column before it is dropped."""
    out, seen = [], set()
    if not isinstance(values, list):
        return out
    for i, raw in enumerate(values):
        text = _line(raw, MAX_CHOICE)
        if text and text.lower() not in seen:
            seen.add(text.lower())
            out.append((i, text))
        if len(out) >= MAX_COLUMNS:
            break
    return out


def normalise(raw):
    """Validate a posted form. Returns {"questions": [...]} or raises SchemaError.

    ``raw`` is the decoded JSON (a dict with "questions") or a JSON string.
    """
    if isinstance(raw, str):
        try:
            raw = json.loads(raw or '{}')
        except ValueError:
            raise SchemaError('The form could not be read. Reload the page '
                              'and try again.')
    if not isinstance(raw, dict):
        raise SchemaError('The form could not be read.')
    questions = raw.get('questions')
    if not isinstance(questions, list):
        raise SchemaError('The form could not be read.')
    if len(questions) > MAX_QUESTIONS:
        raise SchemaError('A survey can hold at most %d questions.'
                          % MAX_QUESTIONS)

    out, taken = [], set()
    for position, q in enumerate(questions, start=1):
        if not isinstance(q, dict):
            continue
        qtype = q.get('type')
        if qtype not in TYPES:
            raise SchemaError('Question %d has an unknown type.' % position)

        qid = q.get('id') if isinstance(q.get('id'), str) else ''
        if not _ID_RE.match(qid) or qid in taken:
            qid = new_question_id(taken)
        taken.add(qid)

        label = _line(q.get('label'), MAX_LABEL)
        item = {
            'id': qid,
            'type': qtype,
            'label': label,
            'help': _clip(q.get('help'), MAX_HELP),
        }
        if qtype != 'section':
            if not label:
                raise SchemaError('Question %d needs a question text.'
                                  % position)
            item['required'] = bool(q.get('required'))

        if qtype in HALF_WIDTH_TYPES:
            item['width'] = q.get('width') if q.get('width') in WIDTHS \
                else 'full'

        if qtype in CHOICE_TYPES:
            options = _unique_lines(q.get('options'), MAX_CHOICE, MAX_OPTIONS)
            if qtype in OTHER_TYPES:
                item['allow_other'] = bool(q.get('allow_other'))
                item['layout'] = q.get('layout') if q.get('layout') in \
                    LAYOUTS else 'stacked'
                # "Other" is a built-in choice; a typed one would duplicate it.
                if item['allow_other']:
                    options = [o for o in options
                               if not o.lower().startswith('other')]
            minimum = 1 if item.get('allow_other') else 2
            if len(options) < minimum:
                raise SchemaError('"%s" needs at least two choices.'
                                  % _short(label))
            item['options'] = options
            # The builder posts a flag per choice (option_reasons), because
            # a label still being typed cannot be a key; a stored form or a
            # template names the choices (reason_on).
            if isinstance(q.get('option_reasons'), list):
                wanted = _flagged(q.get('options'), q['option_reasons'])
            else:
                wanted = set(o.lower() for o in _unique_lines(
                    q.get('reason_on'), MAX_CHOICE, MAX_OPTIONS))
            reason_on = [o for o in options if o.lower() in wanted]
            if reason_on:
                item['reason_on'] = reason_on
                item['reason_label'] = _line(q.get('reason_label'),
                                             MAX_CHOICE) or \
                    REASON_DEFAULT_LABEL
                item['reason_required'] = bool(q.get('reason_required',
                                                     True))

        if qtype in TABLE_TYPES:
            kept = _columns_with_index(q.get('columns'))
            cols = [text for _, text in kept]
            if len(cols) < (1 if qtype == 'table' else 2):
                raise SchemaError('"%s" needs at least %s.' % (
                    _short(label),
                    'one column' if qtype == 'table' else 'two columns'))
            item['columns'] = cols
            if qtype != 'table':
                # A choice table's rows are the things being rated, so the
                # builder fixes them. A text-entry table has none: the
                # participant adds a row per item (one per application).
                rows = _unique_lines(q.get('rows'), MAX_CHOICE, MAX_ROWS)
                if not rows:
                    raise SchemaError('"%s" needs at least one row.'
                                      % _short(label))
                item['rows'] = rows
                item['row_header'] = _line(q.get('row_header'), MAX_CHOICE)
            if qtype == 'table':
                raw_types = q.get('column_types')
                if not isinstance(raw_types, list):
                    raw_types = []
                raw_opts = q.get('column_options')
                if not isinstance(raw_opts, list):
                    raw_opts = []
                types, col_opts = [], []
                for i, col in kept:
                    ctype = raw_types[i] if i < len(raw_types) and \
                        raw_types[i] in COLUMN_TYPES else 'text'
                    opts = []
                    if ctype == 'choice':
                        opts = _unique_lines(
                            raw_opts[i] if i < len(raw_opts) else [],
                            MAX_CHOICE, MAX_COLUMN_OPTIONS)
                        if len(opts) < 2:
                            raise SchemaError(
                                '"%s": the dropdown column "%s" needs at '
                                'least two options.' % (_short(label),
                                                        _short(col)))
                    types.append(ctype)
                    col_opts.append(opts)
                item['column_types'] = types
                if 'choice' in types:
                    item['column_options'] = col_opts

        if qtype == 'section' and not (label or item['help']):
            # An empty section is a slip of the mouse, not content.
            continue
        out.append(item)

    if not any(q['type'] != 'section' for q in out):
        raise SchemaError('Add at least one question before saving.')
    return {'questions': out,
            'acknowledgement': normalise_ack(raw.get('acknowledgement'))}


def _short(label):
    return label if len(label) <= 60 else label[:57] + '...'


# ---------------------------------------------------------------------------
# Acknowledgement - the "User acceptance confirmation" block
#
# Not a question: a fixed block at the END of every form, ON by default for
# every new survey (the builder can reword it or switch it off). The
# participant ticks "I confirm", gives their name, email address and the
# date, and may add comments / issues. The email is ALSO the duplicate key:
# one response per email address per survey (service.submit_response). Stored on the response under ACK_KEY, never under a
# question id, so it cannot collide with one.
# ---------------------------------------------------------------------------

ACK_KEY = '_ack'
ACK_DEFAULT_HEADING = 'User acceptance confirmation'
ACK_DEFAULT_STATEMENT = ('I confirm that the information I have provided in '
                         'this survey is accurate and complete to the best of '
                         'my knowledge.')
ACK_DEFAULT_COMMENTS_LABEL = 'Comments / Issues Identified'
ACK_FIELD_CONFIRM = '_ack__confirm'
ACK_FIELD_NAME = '_ack__name'
ACK_FIELD_EMAIL = '_ack__email'
ACK_FIELD_DATE = '_ack__date'
ACK_FIELD_COMMENTS = '_ack__comments'
MAX_ACK_NAME = 200
MAX_EMAIL = 254
# Deliberately plain: one @, something on each side, a dot in the domain, no
# spaces. It catches typos; whether the mailbox exists is not knowable here.
_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def email_key(email):
    """The matching form of an email address: trimmed and lower-cased, so
    Ann.Lee@x.com and ann.lee@X.COM count as the same person."""
    return (email or '').strip().lower()


def default_ack():
    return {'enabled': True, 'heading': ACK_DEFAULT_HEADING,
            'statement': ACK_DEFAULT_STATEMENT, 'comments': True,
            'comments_label': ACK_DEFAULT_COMMENTS_LABEL}


def normalise_ack(raw):
    """The acknowledgement block from a posted form. Missing = the default
    (on), which is what makes it part of every NEW survey."""
    ack = default_ack()
    if not isinstance(raw, dict):
        return ack
    ack['enabled'] = bool(raw.get('enabled', True))
    ack['heading'] = _line(raw.get('heading'), MAX_CHOICE) or \
        ACK_DEFAULT_HEADING
    ack['statement'] = _clip(raw.get('statement'), MAX_HELP) or \
        ACK_DEFAULT_STATEMENT
    ack['comments'] = bool(raw.get('comments', True))
    ack['comments_label'] = _line(raw.get('comments_label'), MAX_CHOICE) or \
        ACK_DEFAULT_COMMENTS_LABEL
    return ack


def ack_of(form_schema):
    """The block a stored form carries. A form saved before the block existed
    has none, and is NOT retro-fitted: its link may already be answered."""
    ack = form_schema.get('acknowledgement')
    if not isinstance(ack, dict) or not ack.get('enabled'):
        return None
    return ack


def load(schema_json):
    """The stored schema as a dict. A damaged row reads as an empty form."""
    try:
        data = json.loads(schema_json or '{}')
    except ValueError:
        return {'questions': []}
    if not isinstance(data, dict) or not isinstance(data.get('questions'),
                                                    list):
        return {'questions': []}
    return data


def dump(schema):
    return json.dumps(schema, ensure_ascii=True, separators=(',', ':'))


def reason_key(qid):
    """Where a choice question's reason box is stored in the answers."""
    return qid + REASON_SUFFIX


def answerable(schema):
    """The questions that take an answer (sections excluded), in order."""
    return [q for q in schema.get('questions', []) if q.get('type') != 'section']


# ---------------------------------------------------------------------------
# Answers
# ---------------------------------------------------------------------------

def field_name(qid, row=None, col=None):
    """The HTML form field name for a question / table row / table cell.

    Indices, not labels, so a label with quotes or brackets never has to be
    escaped into an attribute and read back.
    """
    name = qid
    if row is not None:
        name += '__r%d' % row
    if col is not None:
        name += '__c%d' % col
    return name


def read_answers(schema, form):
    """(answers, errors) from a submitted public form.

    ``form`` is a werkzeug MultiDict (or anything with get/getlist).
    ``errors`` maps question id -> message; ``answers`` is safe to store
    only when ``errors`` is empty. Choices are matched against the schema, so
    a hand-edited POST cannot store a value the form never offered.
    """
    answers, errors = {}, {}
    for q in answerable(schema):
        qid, qtype = q['id'], q['type']
        required = q.get('required')
        value, problem, reason = None, None, None

        if qtype in ('text', 'paragraph'):
            limit = MAX_TEXT_ANSWER if qtype == 'text' else MAX_PARAGRAPH_ANSWER
            text = (form.get(field_name(qid)) or '').strip()
            if len(text) > limit:
                problem = 'Please keep this under %d characters.' % limit
            value = text or None

        elif qtype == 'number':
            text = (form.get(field_name(qid)) or '').strip()
            if text:
                try:
                    float(text)
                    value = text[:40]
                except ValueError:
                    problem = 'Please enter a number.'

        elif qtype == 'date':
            text = (form.get(field_name(qid)) or '').strip()
            if text:
                if _DATE_RE.match(text):
                    value = text
                else:
                    problem = 'Please enter a date.'

        elif qtype in ('radio', 'dropdown'):
            text = form.get(field_name(qid)) or ''
            if text == OTHER_VALUE and q.get('allow_other'):
                other, problem = _other_text(form, qid)
                value = (OTHER_PREFIX + other) if other else None
            elif text:
                if text in q['options']:
                    value = text
                else:
                    problem = 'Please choose one of the options.'

        elif qtype == 'checkbox':
            raw = form.getlist(field_name(qid))
            picked = [v for v in raw if v in q['options']]
            # Keep the form's own order, not the click order.
            value = [o for o in q['options'] if o in picked]
            if OTHER_VALUE in raw and q.get('allow_other'):
                other, problem = _other_text(form, qid)
                if other:
                    value.append(OTHER_PREFIX + other)
            value = value or None

        elif qtype == 'grid':
            grid = {}
            for r, row in enumerate(q['rows']):
                text = form.get(field_name(qid, r)) or ''
                if text in q['columns']:
                    grid[row] = text
            value = grid or None
            if required and len(grid) < len(q['rows']):
                problem = 'Please answer every row.'

        elif qtype == 'grid_multi':
            grid = {}
            for r, row in enumerate(q['rows']):
                picked = set(form.getlist(field_name(qid, r)))
                cols = [c for c in q['columns'] if c in picked]
                if cols:
                    grid[row] = cols
            value = grid or None

        elif qtype == 'table':
            table = []
            types = q.get('column_types') or []
            # Rows are added and removed in the browser, so their indices can
            # have gaps; read every index up to the cap and keep the rows that
            # hold something, in order.
            col_opts = q.get('column_options') or []
            for r in range(MAX_ROWS):
                cells = {}
                for c, col in enumerate(q['columns']):
                    ctype = types[c] if c < len(types) else 'text'
                    text = (form.get(field_name(qid, r, c)) or '').strip()
                    if not text:
                        continue
                    if ctype == 'yesno' and text not in YES_NO:
                        continue
                    if ctype == 'choice' and text not in (
                            col_opts[c] if c < len(col_opts) else []):
                        continue
                    if ctype == 'number':
                        try:
                            float(text)
                        except ValueError:
                            problem = 'Please enter numbers in "%s".' % col
                            continue
                    if len(text) > MAX_CELL_ANSWER:
                        problem = ('Please keep each cell under %d '
                                   'characters.' % MAX_CELL_ANSWER)
                    cells[col] = text[:MAX_CELL_ANSWER]
                if cells:
                    table.append(cells)
            value = table or None

        if problem is None and required and value is None:
            problem = 'This question is required.'
        if problem is None and q.get('reason_on') and value is not None:
            reason, problem = _reason_text(q, value, form)
        if problem:
            errors[qid] = problem
        elif value is not None:
            answers[qid] = value
            if reason:
                answers[reason_key(qid)] = reason

    ack = ack_of(schema)
    if ack:
        value, problem = _read_ack(ack, form)
        if problem:
            errors[ACK_KEY] = problem
        else:
            answers[ACK_KEY] = value
    return answers, errors


def _read_ack(ack, form):
    """(value, problem) for the acknowledgement block. All of it is required
    except the comments - an acknowledgement nobody signed is not one."""
    name = ' '.join((form.get(ACK_FIELD_NAME) or '').split())
    email = (form.get(ACK_FIELD_EMAIL) or '').strip()
    day = (form.get(ACK_FIELD_DATE) or '').strip()
    comments = (form.get(ACK_FIELD_COMMENTS) or '').strip() \
        if ack.get('comments') else ''
    if form.get(ACK_FIELD_CONFIRM) != 'yes':
        return None, 'Please tick the box to confirm the statement.'
    if not name:
        return None, 'Please enter your name.'
    if len(name) > MAX_ACK_NAME:
        return None, 'Please keep your name under %d characters.' \
            % MAX_ACK_NAME
    if not email:
        return None, 'Please enter your email address.'
    if len(email) > MAX_EMAIL or not _EMAIL_RE.match(email):
        return None, 'Please enter a valid email address.'
    if not _DATE_RE.match(day):
        return None, 'Please enter the date.'
    if len(comments) > MAX_PARAGRAPH_ANSWER:
        return None, 'Please keep the comments under %d characters.' \
            % MAX_PARAGRAPH_ANSWER
    value = {'confirmed': True, 'name': name, 'email': email, 'date': day}
    if comments:
        value['comments'] = comments
    return value, None


def _reason_text(q, value, form):
    """(text, problem) for a choice question's reason box. Read only when a
    choice that asks for a reason was picked; otherwise whatever is in the
    box (typed, then the choice changed) is dropped."""
    picked = value if isinstance(value, list) else [value]
    if not any(p in q['reason_on'] for p in picked):
        return None, None
    text = (form.get(field_name(q['id']) + REASON_SUFFIX) or '').strip()
    if len(text) > MAX_TEXT_ANSWER:
        return None, 'Please keep the reason under %d characters.' \
            % MAX_TEXT_ANSWER
    if not text and q.get('reason_required', True):
        return None, 'Please fill in "%s".' % _short(
            q.get('reason_label') or REASON_DEFAULT_LABEL)
    return text or None, None


def _other_text(form, qid):
    """(text, problem) for an "Other (please specify)" box that was ticked."""
    text = ' '.join((form.get(field_name(qid) + '__other') or '').split())
    if not text:
        return '', 'Please specify what "Other" means.'
    if len(text) > MAX_CHOICE:
        return '', 'Please keep "Other" under %d characters.' % MAX_CHOICE
    return text, None


def answer_text(question, value):
    """One answer as a single readable string (export cells, response list)."""
    if value is None or value == '' or value == [] or value == {}:
        return ''
    qtype = question.get('type')
    if qtype == 'checkbox' and isinstance(value, list):
        return '; '.join(value)
    if qtype == 'grid' and isinstance(value, dict):
        return '; '.join('%s: %s' % (r, value[r])
                         for r in question.get('rows', []) if r in value)
    if qtype == 'grid_multi' and isinstance(value, dict):
        return '; '.join('%s: %s' % (r, ', '.join(value[r]))
                         for r in question.get('rows', []) if r in value)
    if qtype == 'table' and isinstance(value, list):
        parts = []
        for n, cells in enumerate(value, start=1):
            if not isinstance(cells, dict):
                continue
            filled = ['%s=%s' % (c, cells[c])
                      for c in question.get('columns', []) if c in cells]
            if filled:
                parts.append('Row %d: %s' % (n, ', '.join(filled)))
        return '; '.join(parts)
    return str(value)


def table_rows(value):
    """A text-entry table answer as a list of row dicts, whatever was
    stored."""
    if isinstance(value, list):
        return [r for r in value if isinstance(r, dict)]
    return []


def posted_row_count(form, question):
    """How many rows to draw when a table is re-shown after an error: up to
    the last index that holds anything, at least one."""
    last = 0
    for r in range(MAX_ROWS):
        for c in range(len(question.get('columns', []))):
            if (form.get(field_name(question['id'], r, c)) or '').strip():
                last = r + 1
                break
    return max(1, last)
