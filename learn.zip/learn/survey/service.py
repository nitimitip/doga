"""
service.py - the Survey module's rules, kept out of the routes so they can be
tested without HTTP and read in one place.

Access
------
  * MANAGE MEMBERS      admins only.
  * BUILD SURVEYS       survey members and admins (``is_member``).
  * SEE A SURVEY, ITS
    RESPONSES, ITS
    EXCEL REPORT        the member who created it, and admins
                        (``can_manage``). Another survey member gets a 404, not
                        a 403 - they are not told the survey exists.
  * ANSWER A SURVEY     anyone with the public link while it is OPEN.

Retention
---------
A survey and its responses are deleted RETENTION_DAYS (30) after the survey
was created. Three layers, so the promise holds even when one of them is not
running:

  1. ``purge_expired`` - the daily scheduler job (scheduler.py, owned by the
     Windows service) physically deletes expired surveys and responses.
  2. ``maybe_purge`` - the module's own pages run the same purge, at most once
     every PURGE_THROTTLE_SECONDS per worker, so a deployment without the
     scheduler service still deletes on time-ish.
  3. Every lookup in this file filters out ``expires_at <= now``, so between
     the expiry instant and the next purge an expired survey is unreachable -
     no page, no link, no export.
"""

import json
import logging
import secrets
import threading
import time
from datetime import datetime

from sqlalchemy import func

from database import get_db_session
from models import User

from . import schema as S
from .models import (STATUS_CLOSED, STATUS_DRAFT, STATUS_OPEN, Survey,
                     SurveyMember, SurveyResponse)

logger = logging.getLogger(__name__)

# A public link is a write endpoint anyone holding it can reach; this caps how
# much one survey can be made to store.
MAX_RESPONSES = 10000

PURGE_THROTTLE_SECONDS = 600
_purge_lock = threading.Lock()
_last_purge = [0.0]


# ---------------------------------------------------------------------------
# Who may do what
# ---------------------------------------------------------------------------

def is_admin(user):
    return bool(user) and user.role == 'admin'


def is_member(db_session, user):
    """May build surveys: an admin, or on the survey member register."""
    if not user:
        return False
    if is_admin(user):
        return True
    return (db_session.query(SurveyMember.id)
            .filter(SurveyMember.user_id == user.id).first() is not None)


def can_manage(user, survey):
    """The creator and administrators - nobody else, not another member."""
    if not user or survey is None:
        return False
    return is_admin(user) or survey.owner_id == user.id


def _live(query, now=None):
    return query.filter(Survey.expires_at > (now or datetime.now()))


def visible_surveys(db_session, user, now=None):
    """The surveys this person may see, newest first. Expired ones excluded."""
    query = _live(db_session.query(Survey), now)
    if not is_admin(user):
        query = query.filter(Survey.owner_id == user.id)
    return query.order_by(Survey.created_at.desc(), Survey.id.desc()).all()


def get_managed(db_session, user, survey_id, now=None):
    """The survey if this person may manage it and it has not expired; else None.

    One answer for "does not exist", "expired" and "not yours", so a guessed id
    learns nothing.
    """
    survey = (_live(db_session.query(Survey), now)
              .filter(Survey.id == survey_id).first())
    if survey is None or not can_manage(user, survey):
        return None
    return survey


def get_public(db_session, token, now=None):
    """The survey behind a public link, or None if unknown or expired."""
    if not token or len(token) > 64:
        return None
    return (_live(db_session.query(Survey), now)
            .filter(Survey.token == token).first())


# ---------------------------------------------------------------------------
# Counts
# ---------------------------------------------------------------------------

def response_counts(db_session, survey_ids):
    """{survey_id: n} in one query for a list page."""
    ids = [i for i in survey_ids if i is not None]
    if not ids:
        return {}
    rows = (db_session.query(SurveyResponse.survey_id,
                             func.count(SurveyResponse.id))
            .filter(SurveyResponse.survey_id.in_(ids))
            .group_by(SurveyResponse.survey_id).all())
    return dict(rows)


def response_count(db_session, survey):
    return (db_session.query(func.count(SurveyResponse.id))
            .filter(SurveyResponse.survey_id == survey.id).scalar() or 0)


def is_locked(db_session, survey):
    """The questions are frozen once anybody has answered.

    Answers are stored against question ids and choice labels; changing the
    form under them would make the report misread what people said. To change
    a form that has responses, duplicate it.
    """
    return response_count(db_session, survey) > 0


# ---------------------------------------------------------------------------
# Writing surveys
# ---------------------------------------------------------------------------

def _new_token(db_session):
    while True:
        token = secrets.token_urlsafe(18)       # 24 URL-safe characters
        if not db_session.query(Survey.id).filter(
                Survey.token == token).first():
            return token


def clean_title(raw):
    title = S._line(raw, S.MAX_TITLE)
    if not title:
        raise S.SchemaError('Give the survey a title.')
    return title


def clean_description(raw):
    return S._clip(raw, S.MAX_DESCRIPTION)


def create_survey(db_session, user, title, description, form_schema,
                  now=None):
    """Save a new DRAFT survey. Validates; does NOT commit."""
    now = now or datetime.now()
    survey = Survey(
        owner_id=user.id,
        title=clean_title(title),
        description=clean_description(description),
        schema_json=S.dump(S.normalise(form_schema)),
        token=_new_token(db_session),
        status=STATUS_DRAFT,
        created_at=now,
        updated_at=now,
        expires_at=Survey.expiry_for(now),
    )
    db_session.add(survey)
    return survey


def update_survey(db_session, survey, title, description, form_schema):
    """Edit a survey. The questions only while nobody has answered.

    Returns True when the questions were saved, False when they were left as
    they were because the survey is locked. Does NOT commit.
    """
    survey.title = clean_title(title)
    survey.description = clean_description(description)
    if is_locked(db_session, survey):
        return False
    survey.schema_json = S.dump(S.normalise(form_schema))
    return True


def set_status(survey, status, now=None):
    """draft -> open, open -> closed, closed -> open. Does NOT commit."""
    if status not in (STATUS_OPEN, STATUS_CLOSED):
        raise ValueError(status)
    if status == STATUS_OPEN and survey.published_at is None:
        survey.published_at = now or datetime.now()
    survey.status = status


def duplicate_survey(db_session, user, survey, now=None):
    """A fresh DRAFT copy owned by ``user``, with its own link and 30 days."""
    title = 'Copy of ' + survey.title
    return create_survey(db_session, user, title[:S.MAX_TITLE],
                         survey.description, S.load(survey.schema_json),
                         now=now)


def delete_survey(db_session, survey):
    """Delete a survey and every response to it. Does NOT commit."""
    (db_session.query(SurveyResponse)
     .filter(SurveyResponse.survey_id == survey.id)
     .delete(synchronize_session=False))
    db_session.delete(survey)


# ---------------------------------------------------------------------------
# Retention
# ---------------------------------------------------------------------------

def purge_expired(db_session, now=None):
    """Delete every expired survey and its responses. Commits. Returns count.

    Bulk deletes, responses first: a query-level delete does not run the ORM
    cascade, and on SQL Server the FK would refuse the survey row while its
    responses still pointed at it.
    """
    now = now or datetime.now()
    ids = [row[0] for row in db_session.query(Survey.id)
           .filter(Survey.expires_at <= now).all()]
    if not ids:
        return 0
    # Chunked so an IN list never approaches SQL Server's parameter limit.
    for start in range(0, len(ids), 500):
        chunk = ids[start:start + 500]
        (db_session.query(SurveyResponse)
         .filter(SurveyResponse.survey_id.in_(chunk))
         .delete(synchronize_session=False))
        (db_session.query(Survey)
         .filter(Survey.id.in_(chunk))
         .delete(synchronize_session=False))
    db_session.commit()
    logger.info('Survey retention purge deleted %d expired survey(s).',
                len(ids))
    return len(ids)


def run_purge():
    """Scheduler entry point: own session, never raises."""
    db_session = get_db_session()
    try:
        return purge_expired(db_session)
    except Exception:
        db_session.rollback()
        logger.exception('Survey retention purge failed.')
        return 0
    finally:
        db_session.close()


def maybe_purge():
    """Run the purge from a page view, at most once per throttle window.

    Belt and braces for a deployment where the scheduler service is not
    running; the read-time filters above already hide anything expired.
    """
    now = time.monotonic()
    if now - _last_purge[0] < PURGE_THROTTLE_SECONDS:
        return
    if not _purge_lock.acquire(blocking=False):
        return
    try:
        if now - _last_purge[0] < PURGE_THROTTLE_SECONDS:
            return
        _last_purge[0] = now
        run_purge()
    finally:
        _purge_lock.release()


# ---------------------------------------------------------------------------
# Responses
# ---------------------------------------------------------------------------

DUPLICATE_EMAIL = ('A response has already been submitted with this email '
                   'address. Each person can answer this survey once.')


def email_taken(db_session, survey, email):
    """True when this survey already holds a response from this address."""
    key = S.email_key(email)
    if not key:
        return False
    return (db_session.query(SurveyResponse.id)
            .filter(SurveyResponse.survey_id == survey.id,
                    SurveyResponse.respondent_email == key)
            .first() is not None)


def submit_response(db_session, survey, answers, user=None, now=None):
    """Store a response. Returns (response, error). Does NOT commit.

    A form with the acknowledgement block takes ONE response per email
    address (error DUPLICATE_EMAIL). The check runs here, next to the insert,
    so no route can store a response without it.
    """
    if survey.status != STATUS_OPEN:
        return None, 'This survey is not accepting responses.'
    if response_count(db_session, survey) >= MAX_RESPONSES:
        return None, 'This survey has reached its response limit.'
    signed = answers.get(S.ACK_KEY)
    email = S.email_key(signed.get('email')) if isinstance(signed, dict) \
        else ''
    if email and email_taken(db_session, survey, email):
        return None, DUPLICATE_EMAIL
    response = SurveyResponse(
        survey_id=survey.id,
        answers_json=json.dumps(answers, ensure_ascii=True,
                                separators=(',', ':')),
        respondent_user_id=(user.id if user else None),
        respondent_email=email or None,
        submitted_at=now or datetime.now(),
    )
    db_session.add(response)
    return response, None


def load_answers(response):
    try:
        data = json.loads(response.answers_json or '{}')
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


def respondent_names(db_session, responses):
    """{user_id: "First Last (username)"} for signed-in respondents."""
    ids = {r.respondent_user_id for r in responses if r.respondent_user_id}
    if not ids:
        return {}
    out = {}
    for u in db_session.query(User).filter(User.id.in_(ids)).all():
        name = ' '.join(p for p in (u.firstname, u.lastname) if p).strip()
        out[u.id] = ('%s (%s)' % (name, u.username)) if name else u.username
    return out


def summarise(form_schema, responses):
    """Per-question aggregates for the Excel report's Summary sheet.

    Returns a list in FORM ORDER, sections included so the results read the
    way the form does:
      {'kind': 'section', 'q': section}
      {'q': question, 'number': n, 'answered': n, 'total': n,
       'kind': 'choice'|'grid'|'text'|'table',
       'counts': [(label, n, pct)], 'top': label|None   choice
       'reasons': [text, ...]                 choice, newest first
       'matrix': [(row, [n per column], answered_in_row)]   grid / grid_multi
       'totals': [{'yes','no'} | {'counts'} | {'filled'}]   table, per column
       'samples': [text, ...]                 text-like, newest first
      }
    """
    answers = [load_answers(r) for r in responses]
    total = len(answers)
    out = []
    number = 0
    for q in form_schema.get('questions', []):
        if q.get('type') == 'section':
            out.append({'kind': 'section', 'q': q})
            continue
        number += 1
        qid, qtype = q['id'], q['type']
        values = [a.get(qid) for a in answers if a.get(qid) not in
                  (None, '', [], {})]
        entry = {'q': q, 'number': number, 'answered': len(values),
                 'total': total}

        if qtype in S.CHOICE_TYPES:
            labels = list(q['options'])
            if q.get('allow_other'):
                labels.append('Other')
            tally = dict((o, 0) for o in labels)
            others = []
            for v in values:
                for pick in (v if isinstance(v, list) else [v]):
                    if pick in tally:
                        tally[pick] += 1
                    elif isinstance(pick, str) and \
                            pick.startswith(S.OTHER_PREFIX) and \
                            'Other' in tally:
                        tally['Other'] += 1
                        others.append(pick[len(S.OTHER_PREFIX):])
            base = len(values) or 1
            entry['kind'] = 'choice'
            entry['counts'] = [(o, tally[o], int(round(100.0 * tally[o] / base)))
                               for o in labels]
            entry['others'] = list(reversed(others))
            rkey = S.reason_key(qid)
            entry['reasons'] = [a[rkey] for a in reversed(answers)
                                if a.get(rkey)]
            best = max([n for _, n, _ in entry['counts']] or [0])
            leaders = [o for o, n, _ in entry['counts'] if n == best and n]
            entry['top'] = leaders[0] if len(leaders) == 1 else None

        elif qtype in ('grid', 'grid_multi'):
            matrix = []
            for row in q['rows']:
                counts = [0] * len(q['columns'])
                in_row = 0
                for v in values:
                    picked = v.get(row) if isinstance(v, dict) else None
                    if not picked:
                        continue
                    in_row += 1
                    for pick in (picked if isinstance(picked, list)
                                 else [picked]):
                        if pick in q['columns']:
                            counts[q['columns'].index(pick)] += 1
                matrix.append((row, counts, in_row))
            entry['kind'] = 'grid'
            entry['matrix'] = matrix

        elif qtype == 'table':
            # Participants add their own rows, so the summary is over EVERY
            # row entered: Yes / No totals for a Y/N column, how many rows
            # filled it for any other, and the latest rows themselves.
            types = q.get('column_types') or []
            col_opts = q.get('column_options') or []
            all_rows = []
            for v in reversed(values):          # newest response first
                all_rows.extend(S.table_rows(v))
            totals = []
            for c, col in enumerate(q['columns']):
                picked = [r.get(col) for r in all_rows if r.get(col)]
                ctype = types[c] if c < len(types) else 'text'
                if ctype == 'yesno':
                    totals.append({'yes': picked.count('Yes'),
                                   'no': picked.count('No')})
                elif ctype == 'choice':
                    opts = col_opts[c] if c < len(col_opts) else []
                    totals.append({'counts': [(o, picked.count(o))
                                              for o in opts]})
                else:
                    totals.append({'filled': len(picked)})
            entry['kind'] = 'table'
            entry['rows_total'] = len(all_rows)
            entry['totals'] = totals
            entry['recent_rows'] = all_rows[:10]
            entry['samples'] = [S.answer_text(q, v) for v in reversed(values)]

        else:
            entry['kind'] = 'text'
            entry['samples'] = [str(v) for v in reversed(values)]
        out.append(entry)
    return out






def respondent_label(answers, account_name=None):
    """Who answered: the name they signed with, else their account, else
    Anonymous."""
    ack = answers.get(S.ACK_KEY)
    if isinstance(ack, dict) and ack.get('name'):
        return ack['name']
    return account_name or 'Anonymous'


# ---------------------------------------------------------------------------
# Members
# ---------------------------------------------------------------------------

def member_rows(db_session):
    """The register for the members page: [{'member_id', 'user', 'added_at',
    'added_by', 'surveys'}], username-ordered. Orphans skipped."""
    members = db_session.query(SurveyMember).all()
    ids = {m.user_id for m in members} | {m.added_by for m in members
                                          if m.added_by}
    users = {}
    if ids:
        users = {u.id: u for u in db_session.query(User)
                 .filter(User.id.in_(ids)).all()}
    owned = dict(_live(db_session.query(Survey.owner_id, func.count(Survey.id)))
                 .group_by(Survey.owner_id).all())
    rows = []
    for m in members:
        u = users.get(m.user_id)
        if not u:
            continue
        adder = users.get(m.added_by)
        rows.append({'member_id': m.id, 'user': u, 'added_at': m.added_at,
                     'added_by': adder.username if adder else None,
                     'surveys': owned.get(u.id, 0)})
    rows.sort(key=lambda r: (r['user'].username or '').lower())
    return rows
