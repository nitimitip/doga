"""
Survey module (Support & Tools).

    An admin adds members -> a member builds a survey form -> publishing it
    gives a unique public link -> participants answer -> the member (and
    admins) read the results and download them as Excel -> 30 days after the
    survey was created, it and every response are deleted.

Three tables (models.py), the form/answer shapes (schema.py), the rules
(service.py), the Excel report (report_excel.py), ready-made forms
(templates_lib.py), the daily purge (scheduler.py) and one blueprint
(routes.py).
"""

from .routes import survey_bp, survey_public_bp

__all__ = ['survey_bp', 'survey_public_bp']
