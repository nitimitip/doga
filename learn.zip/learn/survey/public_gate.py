"""
public_gate.py - a deployment of the app that serves ONLY public surveys.

Why
---
A survey link goes to people outside the team. Served from the normal
App Assist address, anybody holding one can delete the end of the URL and
land on the App Assist home page and its login screen - they learn the
application exists, where it lives, and get a login form to try.

How
---
Run a SECOND IIS site that points at this same application folder, with

    SURVEY_PUBLIC_ONLY=true

in that site's web.config <appSettings> (wfastcgi hands appSettings to the
process as environment variables). That process then answers only:

    /f/<token>            the survey
    /f/<token>/thanks     its confirmation
    the handful of static files the survey page itself loads
    /health               IIS warm-up

Everything else - /, /index, /login, every module, every other static file -
gets a bare 404 with no branding and no link anywhere. The process itself
refuses, so a forged Host header gets nothing either: this is not a check on
which name the request arrived under.

On the MAIN site set

    SURVEY_PUBLIC_BASE_URL=https://<public survey address>

so the links members copy point at the public site. Without it, links use
the main site's own address (fine for internal-only surveys).

Neither variable set = today's behaviour; nothing here does anything.
"""

import os

from flask import request

_TRUE = ('1', 'true', 'yes', 'on')

PUBLIC_ONLY = (os.environ.get('SURVEY_PUBLIC_ONLY', '') or '').strip().lower() \
    in _TRUE
PUBLIC_BASE_URL = (os.environ.get('SURVEY_PUBLIC_BASE_URL', '') or '') \
    .strip().rstrip('/')

# The only endpoints a public-only process answers.
ALLOWED_ENDPOINTS = frozenset({
    'survey_public.respond',
    'survey_public.thanks',
    'health',
})

# The only static files the participant page loads (see _public_base.html):
# its fonts, the icon font and two stylesheets. Nothing else under /static -
# the app's own scripts and module stylesheets describe the application.
ALLOWED_STATIC = ('css/fonts.css', 'css/npg.css', 'css/survey.css',
                  'css/fontawesome/css/all.min.css')
ALLOWED_STATIC_PREFIXES = ('fonts/', 'css/fontawesome/webfonts/')

_NOT_FOUND = ('<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
              '<meta name="robots" content="noindex, nofollow">'
              '<title>Not available</title></head><body style="font-family:'
              'Segoe UI,Arial,sans-serif;color:#333;padding:40px;">'
              '<h1 style="font-size:20px;">Not available</h1>'
              '<p>This page is not available.</p></body></html>')


def _static_allowed(filename):
    name = (filename or '').replace('\\', '/')
    if '..' in name.split('/'):
        return False
    return name in ALLOWED_STATIC or name.startswith(ALLOWED_STATIC_PREFIXES)


def is_allowed(endpoint, view_args):
    """Would a public-only process answer this request? Pure, for tests."""
    if endpoint in ALLOWED_ENDPOINTS:
        return True
    if endpoint == 'static':
        return _static_allowed((view_args or {}).get('filename'))
    return False


def bare_not_found(code=404):
    return _NOT_FOUND, code, {'Content-Type': 'text/html; charset=utf-8',
                              'X-Robots-Tag': 'noindex, nofollow'}


def install(app, enabled=None):
    """Arm the gate on `app` when this process is the public-only site.

    Runs FIRST among the request hooks, so a blocked request never reaches
    the CSRF gate, a login redirect or a module. Also replaces the error
    pages: the normal one links to the App Assist home page.
    """
    if not (PUBLIC_ONLY if enabled is None else enabled):
        return False

    def _public_only_gate():
        if not is_allowed(request.endpoint, request.view_args):
            return bare_not_found()
        return None

    app.before_request_funcs.setdefault(None, []).insert(0, _public_only_gate)

    def _plain_error(exc):
        return bare_not_found(getattr(exc, 'code', None) or 500)

    for code in (400, 403, 404, 405, 413, 500):
        app.register_error_handler(code, _plain_error)
    return True
