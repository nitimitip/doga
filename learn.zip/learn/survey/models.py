"""
models.py - Survey module.

Three tables:

  survey_members    who may build surveys. Admin-managed register, the same
                    shape as software_group_members / security_group_members.
  surveys           one row per form. The questions live in ``schema_json``
                    (see schema.py) rather than in a question table, because a
                    form is always read and written whole - the builder posts
                    the entire form, the public page renders the entire form -
                    and a JSON document saves and loads in one statement.
  survey_responses  one row per submission, answers in ``answers_json`` keyed
                    by the question ids in the schema.

Retention
---------
Every survey carries ``expires_at`` = created_at + RETENTION_DAYS (30), set
once at creation and never moved. On that date the survey and every response
to it are deleted (service.purge_expired). Until the purge physically runs,
every read path treats an expired survey as already gone - see
``Survey.is_expired`` - so a stopped scheduler cannot keep a survey alive past
its 30 days.

Who sees a survey
-----------------
The member who created it (``owner_id``) and administrators. Nobody else, not
another survey member - service.can_manage is the one place that decides.
"""

from datetime import datetime, timedelta

from sqlalchemy import (
    Column, DateTime, ForeignKey, Index, Integer, String, Text,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database import Base

# Fixed by the requirement: forms and their responses are deleted 30 days after
# the form is created. Not an env setting on purpose - it is a data-retention
# promise made to the people answering, not a tuning knob.
RETENTION_DAYS = 30

STATUS_DRAFT = 'draft'
STATUS_OPEN = 'open'
STATUS_CLOSED = 'closed'
STATUSES = (STATUS_DRAFT, STATUS_OPEN, STATUS_CLOSED)


class SurveyMember(Base):
    """Who may build surveys. Admins are members implicitly and never listed.

    Managing the list stays with administrators - a group that can add itself
    is not a permission. ``user_id`` is UNIQUE: membership is a fact about a
    person, not something held twice.
    """
    __tablename__ = 'survey_members'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                     unique=True)
    added_by = Column(Integer, ForeignKey('users.id'))
    added_at = Column(DateTime, default=func.now())

    user = relationship('User', foreign_keys=[user_id])

    def __repr__(self):
        return '<SurveyMember user_id=%s>' % self.user_id


class Survey(Base):
    """One survey form. Owns its responses."""
    __tablename__ = 'surveys'

    id = Column(Integer, primary_key=True)
    owner_id = Column(Integer, ForeignKey('users.id'), nullable=False,
                      index=True)

    title = Column(String(200), nullable=False)
    description = Column(Text)
    # The form itself: {"questions": [...]} - validated by schema.normalise.
    schema_json = Column(Text, nullable=False, default='{"questions": []}')

    # The unguessable part of the public URL. Not the id: ids are sequential,
    # so /survey/s/41 would invite somebody to try 42.
    token = Column(String(64), nullable=False, unique=True)

    # draft (owner only, not answerable) -> open (answerable) <-> closed.
    status = Column(String(16), nullable=False, default=STATUS_DRAFT,
                    server_default=STATUS_DRAFT)

    created_at = Column(DateTime, default=datetime.now, nullable=False)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    published_at = Column(DateTime)
    # created_at + RETENTION_DAYS. Indexed: the purge asks "which have passed?"
    expires_at = Column(DateTime, nullable=False, index=True)

    responses = relationship(
        'SurveyResponse',
        back_populates='survey',
        cascade='all, delete-orphan',
        order_by='SurveyResponse.id',
    )

    owner = relationship('User', foreign_keys=[owner_id])

    @staticmethod
    def expiry_for(created_at):
        return created_at + timedelta(days=RETENTION_DAYS)

    def is_expired(self, now=None):
        return self.expires_at is not None and \
            self.expires_at <= (now or datetime.now())

    def days_left(self, now=None):
        """Whole days until deletion, never negative. 0 = deleted today."""
        if self.expires_at is None:
            return 0
        delta = self.expires_at - (now or datetime.now())
        return max(0, delta.days + (1 if delta.seconds else 0))

    @property
    def is_open(self):
        return self.status == STATUS_OPEN

    @property
    def is_draft(self):
        return self.status == STATUS_DRAFT

    def __repr__(self):
        return '<Survey %s %r>' % (self.id, self.title)


class SurveyResponse(Base):
    """One submission. Anonymous unless the participant was signed in."""
    __tablename__ = 'survey_responses'

    id = Column(Integer, primary_key=True)
    survey_id = Column(Integer, ForeignKey('surveys.id'), nullable=False)
    # {"<question id>": value} - see schema.validate_answers for the shapes.
    answers_json = Column(Text, nullable=False)
    # Recorded only when the participant happened to be signed in to the
    # dashboard; the public link itself never asks who you are.
    respondent_user_id = Column(Integer, ForeignKey('users.id'))
    # The acknowledgement's email address, lower-cased (schema.email_key).
    # One response per address per survey - checked in
    # service.submit_response. NOT a unique constraint: forms without the
    # acknowledgement store NULL here, and SQL Server lets a unique column
    # hold only one NULL, which would stop those forms after one response.
    respondent_email = Column(String(254))
    submitted_at = Column(DateTime, default=datetime.now, nullable=False)

    survey = relationship('Survey', back_populates='responses')

    __table_args__ = (
        Index('ix_survey_responses_survey', 'survey_id', 'id'),
        Index('ix_survey_responses_email', 'survey_id', 'respondent_email'),
    )

    def __repr__(self):
        return '<SurveyResponse %s survey=%s>' % (self.id, self.survey_id)
